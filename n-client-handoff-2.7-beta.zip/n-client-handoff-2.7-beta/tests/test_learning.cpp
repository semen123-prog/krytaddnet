#include <game/client/components/n_client_learning.h>
#include <game/client/components/laser_unfreeze_input.h>
#include <cassert>
#include <iostream>
#include <random>
int main()
{
 for(int Mask=0;Mask<8;++Mask)
  assert(NFeedbackAwaitingAck(Mask&1,Mask&2,(Mask&4)?123:-1) == ((Mask&1) && (Mask&2) && !(Mask&4)));
 CNClientLearning L;
 assert(L.Phase()==0 && L.Samples()==0);
 assert(!L.ObservePhase(-3) && !L.ObservePhase(4));
 for(int i=0;i<3;++i){assert(L.ObservePhase(1));assert(L.Phase()==0);}
 assert(L.ObservePhase(1));assert(L.Phase()==1);
 for(int i=0;i<16;++i)L.ObservePhase(2);assert(L.Phase()==2 && L.Samples()==16);
 L.Reset();for(int i=0;i<4;++i)L.ObservePhase(i%2 ? -2 : 3);assert(L.Phase()==0);
 L.Reset();for(int i=0;i<4;++i)L.ObservePhase(-1);assert(L.Phase()==-1);
 L.Reset();for(int i=0;i<100;++i){L.SearchTimeout();L.NoAngle();L.FrozenObserved();}
 assert(L.Budget(8)==8 && L.Angles(960)==960 && L.HitMargin(true)==6);
 for(int i=0;i<100;++i)L.ThawObserved();assert(L.HitMargin(true)==12);
 L.PositionError(20);assert(L.HitMargin(true)==8);
 L.PositionError(-1);L.PositionError(1000);assert(L.m_PositionError==20);
 L.Reset();assert(L.Budget(3)==3 && L.Angles(720)==720 && L.m_Unknown==0 && L.m_PositionError<0);
 int Outcomes=0;
 for(int Mask=0;Mask<64;++Mask)
 {
  const bool Changed=Mask&1, Manual=Mask&2, External=Mask&4, Freeze=Mask&8, Thaw=Mask&16, Frozen=Mask&32;
  auto O=NFeedbackOutcome(Changed,Manual,External,Freeze,Thaw,Frozen);
  if(Changed || Manual || External || !Freeze) assert(O==ENFeedbackOutcome::Unknown);
  else if(Frozen) assert(O==ENFeedbackOutcome::StillFrozen);
  else if(Thaw) assert(O==ENFeedbackOutcome::EarlyThaw);
  else assert(O==ENFeedbackOutcome::Unknown);
  ++Outcomes;
 }
 std::mt19937 Rng(4412);
 for(int i=0;i<10000;++i)
 {
  L.ObservePhase((int)(Rng()%40)-20);
  if(Rng()%2)L.SearchTimeout();else L.NoAngle();
  if(Rng()%2)L.FrozenObserved();else L.ThawObserved();
  assert(L.Phase()>=-2 && L.Phase()<=3);
  assert(L.Budget(2)==2 && L.Budget(12)==12 && L.Budget(3)==3);
  assert(L.Angles(180)==180 && L.Angles(1440)==1440 && L.Angles(500)==500);
  assert(L.HitMargin(true)>=6 && L.HitMargin(true)<=12);
 }
 CLaserUnfreezeInput Queue;CNetObj_PlayerInput I{};
 assert(Queue.Queue(400,200) && Queue.IsQueued());assert(Queue.Finalize(I));assert(!Queue.IsQueued());
 I.m_Fire=0;assert(!Queue.Finalize(I));assert(!Queue.NeedsSend());
 assert(Queue.Queue(300,200));I.m_Fire=1;assert(!Queue.Finalize(I));assert(!Queue.NeedsSend());
 // 0.7: input-change blocking rule, exhaustively over small tick ranges.
 int ChangeCases=0;
 for(int Hard=0;Hard<2;++Hard) for(int C=-1;C<=6;++C) for(int F=-1;F<=6;++F)
 {
  const bool B=NFeedbackInputChangeBlocks(Hard,C,F);
  bool Expect = Hard ? true : (C<0 ? false : (F<0 ? true : C<=F));
  assert(B==Expect); ++ChangeCases;
 }
 assert(!NFeedbackInputChangeBlocks(false,-1,-1));   // no change, no freeze yet
 assert(NFeedbackInputChangeBlocks(false,5,-1));     // changed, freeze unknown
 assert(NFeedbackInputChangeBlocks(false,5,5));      // same tick: still blocks
 assert(!NFeedbackInputChangeBlocks(false,6,5));     // after freeze seen: ignored
 assert(NFeedbackInputChangeBlocks(true,9,5));       // hard flag always blocks
 // A change after the freeze no longer makes a thaw ambiguous; a change before still does.
 assert(NFeedbackOutcome(NFeedbackInputChangeBlocks(false,9,5),false,false,true,true,false)==ENFeedbackOutcome::EarlyThaw);
 assert(NFeedbackOutcome(NFeedbackInputChangeBlocks(false,4,5),false,false,true,true,false)==ENFeedbackOutcome::Unknown);
 assert(NFeedbackOutcome(NFeedbackInputChangeBlocks(false,9,5),true,false,true,true,false)==ENFeedbackOutcome::Unknown); // manual still blocks
 std::cout<<"Input-change rule: "<<ChangeCases<<" exhaustive cases PASS\n";
 std::cout<<"Learning: phase calibration, outliers, reset, "<<Outcomes<<" outcome masks, 10000 bounded updates and manual cancellation PASS\n";
}
