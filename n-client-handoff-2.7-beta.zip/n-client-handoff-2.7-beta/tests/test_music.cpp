#include <game/client/components/n_music_core.h>
#include <cassert>
#include <iostream>
using namespace NMusic;
int main()
{
 assert(Rank(EStatus::PLAYING,false) > Rank(EStatus::PAUSED,true));
 assert(Rank(EStatus::PLAYING,true) > Rank(EStatus::PLAYING,false));
 assert(WindowTitle("notepad.exe","Artist - Track").m_Status == EStatus::NONE);
 assert(WindowTitle("chrome.exe","Artist - Track").m_Status == EStatus::NONE);
 assert(WindowTitle("chrome.exe","Яндекс Музыка - Google Chrome").m_Status == EStatus::NONE);
 assert(WindowTitle("Spotify.exe","Spotify Premium").m_Status == EStatus::NONE);
 auto A = WindowTitle("Spotify.exe","  Artist - Track - Spotify  ");
 assert(A.m_Status == EStatus::TITLE_ONLY && A.m_Title == "Artist - Track" && A.m_Artist.empty());
 auto B = WindowTitle("chrome.exe","Автор — Трек — Яндекс Музыка - Google Chrome");
 assert(B.m_Status == EStatus::TITLE_ONLY && B.m_Title == "Автор — Трек");
 assert(WindowTitle("YandexMusic.exe","Автор - Трек").m_Status == EStatus::TITLE_ONLY);
 assert(WindowTitle("Spotify.exe","Song without separator").m_Status == EStatus::NONE);
 assert(Clean("a\nb\tc") == "a b c");
 std::string Long(511,'a');Long += "Я";
 assert(Clean(Long).size() == 511);
 assert(Clean("   ").empty());
 using namespace std::chrono_literals;
 std::atomic<bool> Stop{false}; bool Canceled = false;
 auto Start = std::chrono::steady_clock::now();
 assert(!Await([] { return EAsync::RUNNING; }, [&] { Canceled = true; }, Stop, Start + 60ms));
 assert(Canceled && std::chrono::steady_clock::now() - Start < 150ms);
 Canceled = false;
 assert(Await([] { return EAsync::DONE; }, [&] { Canceled = true; }, Stop, std::chrono::steady_clock::now() + 60ms));
 assert(!Canceled);
 assert(!Await([] { return EAsync::FAILED; }, [&] { Canceled = true; }, Stop, std::chrono::steady_clock::now() + 60ms));
 std::thread CancelThread([&] { std::this_thread::sleep_for(30ms); Stop = true; });
 Start = std::chrono::steady_clock::now();
 assert(!Await([] { return EAsync::RUNNING; }, [&] { Canceled = true; }, Stop, Start + 1200ms));
 CancelThread.join(); assert(Canceled && std::chrono::steady_clock::now() - Start < 150ms);
 std::cout << "Music rank, conservative fallback, browser filtering and UTF-8 limits passed\n";
}
