#include <game/client/components/n_music_core.h>
#include <cassert>
#include <iostream>
using namespace NMusic;
int main()
{
 for(float Width : {100.f, 400.f, 533.333f, 711.111f})
 {
  const float Card = std::min(170.f, Width);
  for(int x : {-10, 0, 20, 500, 1000, 1500})
   for(int y : {-20, 0, 20, 150, 300, 500})
   {
    auto P = Position(x,y,Width,Card,34);
    assert(P.m_X >= 0 && P.m_X + Card <= Width + 0.001f);
    assert(P.m_Y >= 0 && P.m_Y + 34 <= 300);
    int SavedX, SavedY; SavePosition(P.m_X,P.m_Y,Width,Card,34,SavedX,SavedY);
    auto After = Position(SavedX,SavedY,Width,Card,34);
    assert(std::abs(P.m_X-After.m_X) < .6 && std::abs(P.m_Y-After.m_Y) <= .5);
   }
  int X,Y; SavePosition(-100,-200,Width,Card,34,X,Y); assert(X==0 && Y==0);
  SavePosition(10000,10000,Width,Card,34,X,Y);assert(Y==266);assert(X==(Width>Card?1000:0));
 }
 STrack Track;Track.m_Status=EStatus::PLAYING;Track.m_SessionToken=3;
 Track.m_Previous=Track.m_Play=Track.m_Pause=Track.m_Next=true;
 for(auto Action : {EAction::PREVIOUS,EAction::PLAY,EAction::PAUSE,EAction::NEXT}) assert(CanControl(Track,Action));
 assert(!CanControl(Track,EAction::NONE));
 Track.m_Pause=false;assert(!CanControl(Track,EAction::PAUSE));Track.m_Pause=true;
 Track.m_Pending=true;assert(!CanControl(Track,EAction::NEXT));Track.m_Pending=false;
 Track.m_Status=EStatus::TITLE_ONLY;assert(!CanControl(Track,EAction::PLAY));
 Track.m_Status=EStatus::NONE;assert(!CanControl(Track,EAction::NEXT));
 Track.m_Status=EStatus::PAUSED;Track.m_SessionToken=0;assert(!CanControl(Track,EAction::PLAY));
 assert(Matches({EAction::NEXT,3},3));assert(!Matches({EAction::NEXT,3},4));
 assert(!Matches({EAction::NONE,3},3));assert(!Matches({EAction::NEXT,0},0));
 std::cout<<"Music: screen bounds/position round trip/narrow screens, capability/pending/fallback gates and stale-session tokens PASS\n";
}
