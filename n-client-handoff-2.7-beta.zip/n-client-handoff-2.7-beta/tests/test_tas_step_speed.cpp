#include <game/client/components/n_tas_core.h>
#include <cassert>
#include <iostream>
using NTas::CStepRepeat;
int main()
{
 for(int Direction : {-1, 1}) for(int Speed : {1,5,25,50,100}) for(int Fps : {30,60,144,240})
 {
  CStepRepeat R; R.Begin(Direction,0); assert(R.Direction()==Direction);
  int Count=0;
  for(int Frame=1;Frame<=Fps*2;++Frame) Count+=R.Update((double)Frame/Fps,Speed);
  assert(Count==Speed*2); // + one immediate tap handled by OnInput, not by the clock
  R.Reset(); assert(!R.Direction() && !R.Update(100,Speed));
 }
 CStepRepeat R;
 R.Begin(-1,10); assert(!R.Update(10.02,25)); assert(R.Update(10.04,25)==1);
 // Direction switch discards the old fraction; first repeat waits a full interval.
 R.Update(10.07,25); R.Begin(1,10.07); assert(R.Direction()==1); assert(!R.Update(10.09,25)); assert(R.Update(10.11,25)==1);
 // Slow/fast slider values take effect immediately, without affecting direction.
 R.Begin(1,0); assert(!R.Update(.01,1)); assert(R.Update(.03,100)==2); assert(R.Direction()==1);
 // CPU guard: a hitch does not generate hundreds of steps or a catch-up queue.
 R.Begin(-1,0); assert(R.Update(10,100)==4); assert(R.Update(10.001,100)<=1);
 // Backwards clock adjustment never applies a negative step.
 R.Begin(1,20); assert(R.Update(19,25)==0);
 // Out-of-range console inputs are defensively clamped too.
 R.Begin(1,0); assert(R.Update(.1,500)==4);
 R.Begin(1,0); assert(R.Update(.1,-5)==0);
 std::cout << "TAS step speed: both directions, 1-100 ticks/s at 30/60/144/240 FPS, switch/reset, slider changes and hitch cap PASS\n";
}
