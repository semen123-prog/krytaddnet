#include <cstdarg>
#include <cstdio>
#include <cstdlib>
// Only the logger/assert handler is replaced; collision/core/character/laser are native.
extern "C" void dbg_assert_imp(const char *pFile, int Line, const char *pFormat, ...)
{
 std::fprintf(stderr,"DDNet assertion %s:%d: ",pFile,Line);
 va_list Args;va_start(Args,pFormat);std::vfprintf(stderr,pFormat,Args);va_end(Args);std::abort();
}
