#include <algorithm>
#include <array>
#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <base/str.h>
#include <cassert>
#include <chrono>
#include <thread>
#include <game/mapitems.h>
#define private public
#include <game/collision.h>
#undef private
#include <game/mapbugs.h>
#include <engine/shared/config.h>
#include <game/client/prediction/gameworld.h>
#include <game/client/prediction/entities/character.h>
#include <game/client/components/laser_unfreeze.cpp>
CConfig g_Config;
int main() {
 #define MACRO_CONFIG_INT(Name, ScriptName, Def, Min, Max, Flags, Desc) g_Config.m_##Name=Def;
 #define MACRO_CONFIG_COL(Name, ScriptName, Def, Flags, Desc) g_Config.m_##Name=Def;
 #define MACRO_CONFIG_STR(Name, ScriptName, Len, Def, Flags, Desc) str_copy(g_Config.m_##Name,Def);
 #include <engine/shared/config_variables.h>
 #undef MACRO_CONFIG_INT
 #undef MACRO_CONFIG_COL
 #undef MACRO_CONFIG_STR
 CCollision Col; std::vector<CTile> Tiles(64*32);Col.m_Width=64;Col.m_Height=32;Col.m_pTiles=Tiles.data();
 for(int Y=0;Y<32;++Y){Tiles[Y*64+20].m_Index=TILE_SOLID;Tiles[Y*64+11].m_Index=TILE_FREEZE;}
 std::array<CTuningParams,256> Tuning; CMapBugs Bugs; CGameWorld W;W.Init(&Col,Tuning.data(),&Bugs);W.m_GameTick=100;W.m_LocalClientId=0;W.m_WorldConfig={};W.m_WorldConfig.m_IsDDRace=true;W.m_WorldConfig.m_PredictDDRace=true;W.m_WorldConfig.m_PredictTiles=true;W.m_WorldConfig.m_PredictFreeze=1;
 CNetObj_Character Snap{};Snap.m_X=300;Snap.m_Y=300;Snap.m_VelX=12*256;Snap.m_VelY=-2*256;Snap.m_HookState=HOOK_GRABBED;Snap.m_HookX=640;Snap.m_HookY=180;Snap.m_HookedPlayer=-1;Snap.m_Weapon=WEAPON_LASER;Snap.m_Tick=100;
 auto *C=new CCharacter(&W,0,&Snap);W.InsertEntity(C);C->GiveWeapon(WEAPON_LASER);C->SetWeapon(WEAPON_LASER);
 CNetObj_PlayerInput Past{};Past.m_Direction=1;Past.m_Hook=1;Past.m_TargetX=1000;Past.m_TargetY=-200;Past.m_PlayerFlags=PLAYERFLAG_PLAYING;
 C->OnPredictedInput(&Past);CGameWorld Early;Early.CopyWorld(&W,false);Early.m_LocalClientId=0;
 C->OnDirectInput(&Past);++W.m_GameTick;C->OnPredictedInput(&Past);W.Tick();C=W.GetCharacterById(0);
 CNetObj_PlayerInput Held=Past;Held.m_Hook=0;
 const vec2 Before=C->GetPos();const int BeforeTick=W.GameTick();const auto BeforeInput=C->GetPredictionInput();
 CGameWorld LinkedChild;LinkedChild.CopyWorld(&W);assert(W.m_pChild==&LinkedChild);

 SLaserUnfreezeAim Aim;ENLaserStatus Status;int Freeze=-1;
 bool Found=FindTutorialUnfreezeAim(W,0,Held,3,3,6,Aim,&Status,&Freeze,true,&Early);
 std::cout<<"current x="<<C->GetPos().x<<" vx="<<C->Core()->m_Vel.x<<" hook="<<C->Core()->m_HookState<<" Found="<<Found<<" Status="<<NLaserStatusText(Status)<<" Freeze="<<Freeze<<" aim="<<Aim.m_Target.x<<","<<Aim.m_Target.y<<"\n";
 assert(Found);assert(W.m_pChild==&LinkedChild && LinkedChild.m_IsValidCopy);
 assert(W.GameTick()==BeforeTick&&C->GetPos()==Before&&C->GetPredictionInput().m_Hook==BeforeInput.m_Hook);
 if(Found) {int Return=-1;SLaserUnfreezeAim Verified;ENLaserStatus Reason;
  const bool Good=Verify(W,0,Held,Aim.m_Target,W.GetTuning(0)->m_LaserReach,64,time_get_impl()+time_freq()/10,0,2,16,Return,Verified,Reason,2,true);
  assert(Good);std::cout<<"normal native thaw return="<<Return<<"\n";
  int EarlyReturn=-1;SLaserUnfreezeAim Earlier;
  const bool EarlyGood=Verify(Early,0,Held,Aim.m_Target,W.GetTuning(0)->m_LaserReach,64,time_get_impl()+time_freq()/10,0,2,16,EarlyReturn,Earlier,Reason,2,true,0,&C->GetPredictionInput());
  assert(EarlyGood);assert(Earlier.m_Forecast.size()>1 && distance(Earlier.m_Forecast[1].m_Pos,Before)<.02f);std::cout<<"historical early native thaw return="<<EarlyReturn<<"\n";
 }
 // Repeat at the user's normal 6 ms budget with the client clock cached.
 for(int Run=0;Run<20;++Run) { set_new_tick();time_get();SLaserUnfreezeAim Again;int First=-1;assert(FindTutorialUnfreezeAim(W,0,Held,3,3,6,Again,&Status,&First,true,&Early));assert(W.m_pChild==&LinkedChild&&LinkedChild.m_IsValidCopy&&C->GetPos()==Before); }
 std::cout<<"20 cached-client-clock native post-unhook searches at 6 ms; source-world isolation PASS\n";
 // Real cached game clock must NOT defeat the solver's CPU deadline.
 Tuning[0].m_Gravity=0;C->SetRawVelocity(vec2(0,0));C->ResetHook();
 CNetObj_PlayerInput Neutral=Held;Neutral.m_Direction=0;Neutral.m_Hook=0;C->OnPredictedInput(&Neutral);
 set_new_tick();const auto Cached=time_get();std::this_thread::sleep_for(std::chrono::milliseconds(4));assert(time_get()==Cached);assert(time_get_impl()>Cached);
 int Return=-1;SLaserUnfreezeAim Long;ENLaserStatus Reason=ENLaserStatus::NoAngle;
 const auto Begin=time_get_impl();const auto Deadline=Begin+time_freq()*2/1000;
 bool Good=Verify(W,0,Neutral,ivec2(1000,0),W.GetTuning(0)->m_LaserReach,100000,Deadline,0,2,16,Return,Long,Reason);
 const double Elapsed=(time_get_impl()-Begin)*1000.0/time_freq();
 assert(!Good&&Reason==ENLaserStatus::BudgetExpired&&Elapsed<100);assert(time_get()==Cached);
 std::cout<<"cached-clock native deadline: elapsed "<<Elapsed<<" ms, status "<<NLaserStatusText(Reason)<<" PASS\n";
}
