#include <game/client/components/laser_unfreeze.h>
#include <game/client/components/laser_unfreeze_input.h>
#include <cassert>
#include <iostream>
int main()
{
 CNetObj_PlayerInput Old{};Old.m_Hook=1;Old.m_Direction=1;Old.m_TargetX=700;Old.m_TargetY=-200;
 auto Released=Old;Released.m_Hook=0;
 assert(NLaserPathNeedsRefresh(100,100,2,Released,Old));
 assert(NLaserShouldSolve(100,100,3,false,Released,Old));
 assert(!NLaserPathNeedsRefresh(100,100,2,Old,Old));
 assert(!NLaserShouldSolve(100,100,1,true,Old,Old));
 assert(!NLaserShouldSolve(0,-1,1,true,Released,Old));
 assert(!NLaserShouldSolve(101,100,3,false,Released,Released));
 assert(NLaserShouldSolve(101,100,3,true,Released,Released));
 assert(NLaserShouldSolve(103,100,3,false,Released,Released));
 auto Changed=Released;Changed.m_Direction=-1;assert(NLaserShouldSolve(100,100,3,false,Changed,Released));
 Changed=Released;Changed.m_Jump=1;assert(NLaserPathNeedsRefresh(100,100,2,Changed,Released));
 Changed=Old;Changed.m_TargetY=100;assert(NLaserPathNeedsRefresh(100,100,2,Changed,Old));
 Changed=Released;Changed.m_TargetY=100;assert(!NLaserPathNeedsRefresh(100,100,2,Changed,Released));
 // No hand-reset of physical movement: the early first tick uses real history.
 Old.m_Fire=7;Old.m_WantedWeapon=5;Old.m_NextWeapon=2;
 for(int Step=1;Step<=5;++Step)
 {
  const auto I=NLaserVerificationStepInput(Released,ivec2(-900,100),Step,2,&Old);
  assert(I.m_Direction==1);
  if(Step==1) { assert(I.m_Hook==1 && I.m_TargetX==700 && I.m_TargetY==-200 && !(I.m_Fire&1)); assert(!I.m_WantedWeapon&&!I.m_NextWeapon&&!I.m_PrevWeapon); }
  else { assert(!I.m_Hook); assert(I.m_TargetX==(Step<=3?-900:Released.m_TargetX)); }
  const auto Normal=NLaserVerificationStepInput(Released,ivec2(-900,100),Step,2,nullptr);
  assert(!Normal.m_Hook && Normal.m_Direction==1 && Normal.m_TargetX==(Step<=2?-900:Released.m_TargetX));
 }
 // 2.1 guard remains active: a release AFTER solving cancels an unsent shot.
 CLaserUnfreezeInput Q;auto Expected=Old;Expected.m_Fire=0;assert(Q.Queue(-900,100,&Expected));auto Wire=Expected;Wire.m_Hook=0;
 assert(!Q.Finalize(Wire)&&!Q.NeedsSend()&&Wire.m_Fire==0&&Wire.m_Direction==1&&Wire.m_Hook==0&&Wire.m_TargetX==700);
 std::cout<<"Unhook input: same-tick invalidation, solve scheduling, known historical hook/aim, two wire-aim ticks and stale-shot cancellation PASS\n";
}
