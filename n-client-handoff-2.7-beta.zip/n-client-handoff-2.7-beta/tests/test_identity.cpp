#include <engine/shared/n_client_identity.h>
#include <engine/shared/packer.h>
#include <engine/message.h>
#include <engine/shared/protocol_ex.h>
#include <array>
#include <cassert>
#include <cstring>
#include <iostream>
using namespace NIdentity;
int main()
{
 const char *Real = "DDNet 20.1 (c9d208138f85755521f16a0096b6fe036c5c8698)";
 const char *Hash = "82d946145072e18f9513ba2427538971";
 auto Off = Build(false,"TClient 10.8.6",Hash,19080,Real,"DDNet 20.1","c9d208138f85755521f16a0096b6fe036c5c8698",20010);
 assert(!Off.m_Applied && !Off.m_pError && !strcmp(Off.m_aVersion,Real) && Off.m_Number==20010);
 auto On = Build(true,"TClient 10.8.6",Hash,19080,Real,"DDNet 20.1","c9d208138f85755521f16a0096b6fe036c5c8698",20010);
 assert(On.m_Applied && On.m_Number==19080 && !strcmp(On.m_aVersion,"TClient 10.8.6 (82d946145072e18f9513ba2427538971)"));
 auto Empty = Build(true,"","",0,Real,"DDNet 20.1","c9d208138f85755521f16a0096b6fe036c5c8698",20010);
 assert(Empty.m_Number==20010 && !strcmp(Empty.m_aVersion,Real));
 for(const char *Bad : {"random hash","12","123456\n", "gggggggggg", "../hash"})
 {
  auto P=Build(true,"TClient 10.8.6",Bad,19080,Real,"DDNet 20.1","c9d208138f85755521f16a0096b6fe036c5c8698",20010);
  assert(P.m_pError && !P.m_Applied && P.m_Number==20010 && !strcmp(P.m_aVersion,Real));
 }
 for(const char *Bad : {"fake\nversion","bad\tname","TClient 1.0 (1234567)","\xff"})
 {
  auto P=Build(true,Bad,Hash,19080,Real,"DDNet 20.1","1234567",20010);
  assert(P.m_pError && !P.m_Applied && P.m_Number==20010 && !strcmp(P.m_aVersion,Real));
 }
 std::string Long(127,'A');auto TooLong=Build(true,Long.c_str(),Hash,19080,Real,"DDNet 20.1","1234567",20010);
 assert(TooLong.m_pError && !TooLong.m_Applied);
 for(int Bad : {-1,100000}) assert(Build(true,"TClient",Hash,Bad,Real,"DDNet 20.1","1234567",20010).m_pError);
 auto WithoutGit=Build(true,"Custom","",0,"DDNet 20.1","DDNet 20.1",nullptr,20010);assert(!strcmp(WithoutGit.m_aVersion,"Custom"));
 std::array<unsigned char,16> Uuid{};for(unsigned i=0;i<Uuid.size();++i)Uuid[i]=(unsigned char)i;
 CMsgPacker Message(NETMSG_CLIENTVER,true);
 Message.AddRaw(Uuid.data(),Uuid.size()); Message.AddInt(On.m_Number);Message.AddString(On.m_aVersion);
 assert(!Message.Error()); CUnpacker Unpacker;Unpacker.Reset(Message.Data(),Message.Size());
 const void *Received=Unpacker.GetRaw(16);assert(!memcmp(Received,Uuid.data(),16));
 assert(Unpacker.GetInt()==19080);assert(!strcmp(Unpacker.GetString(),On.m_aVersion));assert(!Unpacker.Error());
 CMsgPacker Baseline(NETMSG_CLIENTVER,true), Disabled(NETMSG_CLIENTVER,true);
 Baseline.AddRaw(Uuid.data(),16);Baseline.AddInt(20010);Baseline.AddString(Real);
 Disabled.AddRaw(Uuid.data(),16);Disabled.AddInt(Off.m_Number);Disabled.AddString(Off.m_aVersion);
 assert(Baseline.Size()==Disabled.Size() && !memcmp(Baseline.Data(),Disabled.Data(),Baseline.Size()));
 // Two independent frozen connection snapshots; editing config cannot mutate sent copies.
 std::array<SProfile,2> Connections{On,Off};On=Empty;
 assert(Connections[0].m_Number==19080 && Connections[1].m_Number==20010);
 std::cout<<"Identity: opt-in/fallback/hash/string bounds and UTF8 checks, actual CPacker round-trip with unchanged UUID, main/dummy frozen profiles PASS\n";
}
