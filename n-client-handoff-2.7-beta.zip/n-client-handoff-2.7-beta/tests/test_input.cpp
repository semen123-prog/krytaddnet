#include <game/client/components/laser_unfreeze_input.h>
#include <cassert>
#include <iostream>
int Presses(int Old,int New) { int N=0; while(Old!=New) {Old=(Old+1)&INPUT_STATE_MASK; if(Old&1)++N;} return N; }
int main()
{
 int Cases=0;
 for(int Base=0;Base<=INPUT_STATE_MASK;Base+=2)
 {
  CLaserUnfreezeInput A; CNetObj_PlayerInput I{}; I.m_Fire=Base; I.m_TargetX=17; I.m_TargetY=23;
  assert(!A.Queue(0,0));assert(A.Queue(1000,-50));assert(!A.Queue(999,0));A.Finalize(I);
  int Last=I.m_Fire;assert(Presses(Base,Last)==1);assert(Last&1);assert(I.m_TargetX==1000&&I.m_TargetY==-50);assert(A.NeedsSend());
  I.m_Fire=Base;A.Finalize(I);assert(!(I.m_Fire&1));assert(Presses(Last,I.m_Fire)==0);assert(!A.NeedsSend());Last=I.m_Fire;
  I.m_Fire=(Base+1)&INPUT_STATE_MASK;A.Finalize(I);assert(Presses(Last,I.m_Fire)==1);Last=I.m_Fire;
  I.m_Fire=(Base+2)&INPUT_STATE_MASK;A.Finalize(I);assert(Presses(Last,I.m_Fire)==0);++Cases;
  CLaserUnfreezeInput B;assert(B.Queue(-1000,0));I={};I.m_Fire=(Base+1)&INPUT_STATE_MASK;I.m_TargetX=7;B.Finalize(I);
  assert(I.m_Fire==((Base+1)&INPUT_STATE_MASK));assert(I.m_TargetX==7);assert(!B.NeedsSend());++Cases;
  CLaserUnfreezeInput C;I={};I.m_Fire=Base;assert(C.Queue(500,500));C.Finalize(I);Last=I.m_Fire;
  I.m_Fire=(Base+1)&INPUT_STATE_MASK;C.Finalize(I);assert(I.m_Fire&1);assert(Presses(Last,I.m_Fire)==1);++Cases;
 }
 CLaserUnfreezeInput A;CNetObj_PlayerInput I{};int Last=0;
 for(int j=0;j<10000;++j) {assert(A.Queue(1,j%50));I.m_Fire=0;A.Finalize(I);assert(Presses(Last,I.m_Fire)==1);Last=I.m_Fire;I.m_Fire=0;A.Finalize(I);assert(Presses(Last,I.m_Fire)==0);Last=I.m_Fire;}
 std::cout<<"Input counter OK: "<<Cases<<" edge cases + 10000 press/release cycles\n";
}
