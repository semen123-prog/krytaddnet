#include <game/client/components/n_tas_core.h>
#include <cassert>
#include <cstring>
#include <iostream>
using namespace NTas;
int Presses(int Prev, int Cur) { int N = 0; for(int I = Prev & MASK; I != (Cur & MASK);) { I = (I+1)&MASK; if(I&1) ++N; } return N; }
struct FakeWorld { int m_GameTick = 100; std::vector<int> m_Events; void Tick() { m_Events.push_back(999); } };
struct FakeChar {
 FakeWorld &W; int Id; CNetObj_PlayerInput Input{};
 int GetCid() const { return Id; }
 void OnDirectInput(const CNetObj_PlayerInput *I) { assert(W.m_GameTick==100); W.m_Events.push_back(Id); Input=*I; }
 void OnPredictedInput(const CNetObj_PlayerInput *I) { assert(W.m_GameTick==101); W.m_Events.push_back(Id+100); assert(!std::memcmp(&Input,I,sizeof(Input))); }
};
SRecording Pair(int Conn) {
 SRecording R; R.m_HasDummy=true; R.m_MainConnection=Conn;
 for(int Role=0;Role<2;++Role) {
  STrack &T=Role?R.m_Dummy:static_cast<STrack&>(R);
  T.m_HasStart=T.m_HasLoadout=true; T.m_StartX=Role?512:100; T.m_StartY=200;
  T.m_Lead=0; T.m_Active=Role?0:4; T.m_GotMask=Role?3:31;
  for(int I=0;I<300;++I) { SFrame F; F.m_Direction=Role?-1:1; F.m_Jump=I%17==0; F.m_Hook=I%19<3; F.m_TargetX=Role?-800:123; F.m_TargetY=Role?150:-450; F.m_Fire=I/2; F.m_Next=I/31; F.m_Prev=I/71; F.m_Weapon=I%23==0?Role+1:0; T.m_vFrames.push_back(F); T.m_vPos.push_back({I,I*(Role?-3:2),200}); }
 }
 return R;
}
int main() {
 // The same helper used by AdvanceSim: sorted direct input before tick, ONE shared world tick.
 for(int DummyId : {2,9,-1}) {
  FakeWorld W; FakeChar Main{W,5},Dummy{W,DummyId}; CNetObj_PlayerInput A{},B{};
  A.m_Direction=1; A.m_TargetX=123; B.m_Direction=-1; B.m_TargetX=-800;
  ApplyPairTick(W,&Main,A,DummyId<0?nullptr:&Dummy,B);
  assert(W.m_GameTick==101);
  const std::vector<int> Expected=DummyId<0?std::vector<int>{5,105,999}:DummyId<5?std::vector<int>{2,5,105,102,999}:std::vector<int>{5,9,105,109,999};
  assert(W.m_Events==Expected);
 }
 for(int Conn=0;Conn<2;++Conn) {
  const SRecording Original=Pair(Conn); const std::string Text=Serialize(Original); SRecording R;
  assert(Parse(Text,R)); assert(R.m_HasDummy && R.m_MainConnection==Conn && R.m_Dummy.m_StartX==512 && R.m_Dummy.m_Active==0);
  assert(Serialize(R)==Text);
  CEngine Engines[2]; int Last[2]{};
  for(int Role=0;Role<2;++Role) { CNetObj_PlayerInput In{}; In.m_Fire=Role?60:14; In.m_NextWeapon=Role?22:4; Engines[Role].Apply(In,10); SRecording Track; static_cast<STrack&>(Track)=Role?R.m_Dummy:static_cast<const STrack&>(R); Engines[Role].BeginPrep(false,&Track); Engines[Role].SetAnchor(500); }
  for(int Idx=0;Idx<300;++Idx) {
   // Caller order changes as selected connection changes; never swap track ownership.
   const int Selected=(Idx/7)%2;
   for(int D=0;D<2;++D) { const int PhysicalConn=Selected^D, Role=PhysicalConn^Conn; CNetObj_PlayerInput In{}; In.m_TargetX=1; In.m_Fire=2; assert(Engines[Role].Apply(In,500+Idx)); const SFrame &F=(Role?R.m_Dummy:R).m_vFrames[Idx]; assert(In.m_Direction==F.m_Direction && In.m_Hook==F.m_Hook && In.m_Jump==F.m_Jump && In.m_TargetX==F.m_TargetX && In.m_TargetY==F.m_TargetY && In.m_WantedWeapon==F.m_Weapon); assert(In.m_Fire==((Engines[Role].F0()+F.m_Fire)&MASK)); Last[Role]=In.m_Fire;
    CNetObj_PlayerInput Gap{}; assert(Engines[Role].FrameInput(500+Idx,In,Gap)); assert(!std::memcmp(&Gap,&In,sizeof(In))); }
  }
  for(int Role=0;Role<2;++Role) { CNetObj_PlayerInput In{}; In.m_TargetX=1; In.m_Fire=2; Engines[Role].Apply(In,800); assert(!Engines[Role].Overriding()); assert(Presses(Last[Role],In.m_Fire)==0); }
  SRecording Bad=R; Bad.m_Dummy.m_vFrames.pop_back(); assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_Dummy.m_Lead=3; assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_MainConnection=2; assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_Dummy.m_GotMask=99; assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_Dummy.m_Active=6; assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_Dummy.m_vPos[1].m_Idx=-1; assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_Dummy.m_vFrames[0].m_TargetX=Bad.m_Dummy.m_vFrames[0].m_TargetY=0; assert(!Parse(Serialize(Bad),Bad));
  Bad=R; Bad.m_Dummy.m_HasLoadout=false; assert(!Parse(Serialize(Bad),Bad));
  for(size_t Cut : {size_t(0),Text.size()/2,Text.size()-8}) { Bad=R; assert(!Parse(Text.substr(0,Cut),Bad)); assert(Bad.m_MainConnection==R.m_MainConnection && Bad.m_vFrames.size()==R.m_vFrames.size()); }
  assert(!Parse(Text+"unexpected\n",Bad));
 }
 // Paused planning emits neutral packets even when dummy raw input was empty/held.
 CEngine E[2]; for(int Role=0;Role<2;++Role) { CNetObj_PlayerInput I{}; I.m_Fire=Role?63:15; E[Role].Apply(I,1); E[Role].BeginPrep(true,nullptr); I.m_Hook=I.m_Jump=1; I.m_Direction=1; E[Role].Apply(I,2); assert(!I.m_Hook&&!I.m_Jump&&!I.m_Direction&&!(I.m_Fire&1)); int Last=I.m_Fire; E[Role].RequestStop(); I.m_Fire=0; E[Role].Apply(I,3); assert(!E[Role].Overriding()&&Presses(Last,I.m_Fire)==0); }
 // Each track retains its own auto-shot, aim and fire counters.
 SFrame A,B; assert(AddLaserAutoShot(B,0,-500,200)); assert(A.m_Fire==0&&A.m_TargetX==1&&B.m_Fire==1&&B.m_TargetX==-500); assert(!AddLaserAutoShot(B,0,200,400));
 std::cout<<"Dummy TAS: paired NTAS4/physical ownership/two-engine playback/gap packets/neutral-stop/auto-shot isolation/shared tick order PASS\n";
}
