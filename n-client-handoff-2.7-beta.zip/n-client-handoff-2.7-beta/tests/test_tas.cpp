#include <game/client/components/n_tas_core.h>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace NTas;
static int Presses(int Prev, int Cur){int n=0;Prev&=MASK;Cur&=MASK;int i=Prev;while(i!=Cur){i=(i+1)&MASK;if(i&1)n++;}return n;}
struct SRaw{CNetObj_PlayerInput In;};
static CNetObj_PlayerInput RandomRaw(int Seed,int Tick,int &FireCounter,int &Next)
{
 CNetObj_PlayerInput I;memset(&I,0,sizeof(I));
 srand(Seed*100003+Tick);
 I.m_Direction=(rand()%3)-1;I.m_Jump=rand()%2;I.m_Hook=(rand()%7==0);
 if(rand()%9==0)FireCounter=(FireCounter+1+(rand()%4==0))&MASK;
 I.m_Fire=FireCounter;I.m_WantedWeapon=(rand()%20==0)?(1+rand()%5):0;
 if(rand()%40==0)Next=(Next+1)&MASK;I.m_NextWeapon=Next;
 I.m_TargetX=rand()%400-200;I.m_TargetY=rand()%400-200;I.m_PlayerFlags=PLAYERFLAG_PLAYING;
 return I;
}
int main()
{
 // --- record ---
 CEngine Rec;int Fire=7,Next=3;
 // pretend previous traffic made the last sent values odd (key held)
 {CNetObj_PlayerInput I=RandomRaw(1,0,Fire,Next);I.m_Fire=9;Fire=9;Rec.Apply(I,10);}
 Rec.BeginPrep(true,nullptr);
 int Tick=500;
 for(;Tick<503;++Tick){CNetObj_PlayerInput I=RandomRaw(1,Tick,Fire,Next);Rec.Apply(I,Tick);assert(I.m_Direction==0&&I.m_Jump==0&&I.m_Hook==0&&I.m_WantedWeapon==0);assert((I.m_Fire&1)==0);}
 Rec.SetAnchor(500);assert(Rec.Mode()==CEngine::EMode::Recording);
 std::vector<CNetObj_PlayerInput> Sent;
 const int RecTicks=300;
 for(int t=503;t<500+RecTicks;++t){CNetObj_PlayerInput I=RandomRaw(1,t,Fire,Next);Rec.Apply(I,t);Sent.push_back(I);}
 Rec.RequestStop();
 {CNetObj_PlayerInput I=RandomRaw(1,999,Fire,Next);Rec.Apply(I,999);assert(Rec.Mode()==CEngine::EMode::Idle);}
 SRecording R=Rec.Recording();
 printf("recorded %zu frames lead=%d\n",R.m_vFrames.size(),R.m_Lead);
 assert((int)R.m_vFrames.size()==RecTicks);
 R.m_vPos.push_back({5,10,20});R.m_HasStart=true;R.m_StartX=-123;R.m_StartY=456;
 SRecording P;assert(Parse(Serialize(R),P));assert(P.m_vFrames.size()==R.m_vFrames.size()&&P.m_vPos.size()==1&&P.m_Lead==R.m_Lead);assert(P.m_HasStart&&P.m_StartX==-123&&P.m_StartY==456);
 for(size_t i=0;i<P.m_vFrames.size();++i)assert(!memcmp(&P.m_vFrames[i],&R.m_vFrames[i],sizeof(SFrame)));
 {SRecording Old;assert(Parse("NTAS 1\nlead 10\nframes 1\n0 0 0 0 0 0 0 1 0\npositions 0\n",Old)&&!Old.m_HasStart);}
 {SRecording L=R;L.m_HasLoadout=true;L.m_Active=4;L.m_GotMask=31;SRecording Q;assert(Parse(Serialize(L),Q)&&Q.m_HasLoadout&&Q.m_Active==4&&Q.m_GotMask==31&&Q.m_vFrames.size()==R.m_vFrames.size()&&Q.m_HasStart);assert(!Parse("NTAS 3\nstart 0 0 0\nloadout 1 99\nlead 10\nframes 0\npositions 0\n",Q));}
 assert(!Parse("garbage",P));assert(!Parse("NTAS 1\nlead 10\nframes 2\n0 0 0 0 0 0 0 1 0\n",P));
 // --- replay with different raw traffic and late start of 4 ticks ---
 CEngine Play;int Fire2=21,Next2=40;
 {CNetObj_PlayerInput I=RandomRaw(2,0,Fire2,Next2);I.m_Fire=22;Fire2=22;Play.Apply(I,10);}
 Play.BeginPrep(false,&P);
 int T2=700;int Anchor=700;
 for(;T2<704;++T2){CNetObj_PlayerInput I=RandomRaw(2,T2,Fire2,Next2);Play.Apply(I,T2);}
 Play.SetAnchor(Anchor);
 std::vector<CNetObj_PlayerInput> Out(RecTicks);std::vector<bool> Have(RecTicks,false);
 int Last=-1;bool Done=false;
 for(;T2<Anchor+RecTicks+20&&!Done;++T2)
 {
  CNetObj_PlayerInput I=RandomRaw(2,T2,Fire2,Next2);I.m_Fire=Fire2;Play.Apply(I,T2);
  const int Idx=T2-Anchor;
  if(Play.Mode()==CEngine::EMode::Idle){Done=true;assert(Idx==RecTicks);
    // continuity: the first idle packet must not create a press versus the last replayed one
    assert(Presses(Last,I.m_Fire)==0 || (Fire2&1)!=0);
    printf("end continuity last=%d idle=%d raw=%d\n",Last,I.m_Fire,Fire2);
    CNetObj_PlayerInput J=RandomRaw(2,T2+1,Fire2,Next2);Play.Apply(J,T2+1);
    break;}
  Out[Idx]=I;Have[Idx]=true;Last=I.m_Fire;
 }
 assert(Done);
 // Compare against what was sent in the recording from the lead onwards
 int Checked=0;
 for(int Idx=R.m_Lead;Idx<RecTicks;++Idx)
 {
  const CNetObj_PlayerInput &A=Sent[Idx-3],&B=Out[Idx];
  assert(A.m_Direction==B.m_Direction&&A.m_Jump==B.m_Jump&&A.m_Hook==B.m_Hook&&A.m_WantedWeapon==B.m_WantedWeapon);
  assert(A.m_TargetX==B.m_TargetX&&A.m_TargetY==B.m_TargetY);
  if(Idx>R.m_Lead){const CNetObj_PlayerInput &A0=Sent[Idx-4],&B0=Out[Idx-1];
   assert(Presses(A0.m_Fire,A.m_Fire)==Presses(B0.m_Fire,B.m_Fire));assert((A.m_Fire&1)==(B.m_Fire&1));
   assert(((A.m_NextWeapon-A0.m_NextWeapon)&MASK)==((B.m_NextWeapon-B0.m_NextWeapon)&MASK));}
  ++Checked;
 }
 printf("compared %d ticks OK\n",Checked);
 // lead ticks are neutral in replay
 for(int Idx=0;Idx<R.m_Lead;++Idx){assert(Out[Idx].m_Direction==0&&Out[Idx].m_Jump==0&&Out[Idx].m_Hook==0&&Out[Idx].m_WantedWeapon==0);}
 // --- end continuity with released raw fire, many counter offsets ---
 for(int Base=0;Base<64;Base+=2){CEngine E;CNetObj_PlayerInput I;memset(&I,0,sizeof(I));I.m_Fire=Base;E.Apply(I,1);E.BeginPrep(false,&P);int Tk=800;E.SetAnchor(800);int LastOut=-1;for(;;++Tk){CNetObj_PlayerInput J;memset(&J,0,sizeof(J));J.m_Fire=(Base*7+2)&MASK&~1;J.m_TargetX=1;E.Apply(J,Tk);if(E.Mode()==CEngine::EMode::Idle){assert(Presses(LastOut,J.m_Fire)==0);break;}LastOut=J.m_Fire;}}
 // --- no-respawn replay: anchor = next tick, frames from index 0 ---
 {SRecording Q;for(int i=0;i<40;++i){SFrame F;F.m_Direction=(i%7<3)?1:0;F.m_Jump=(i==10);F.m_Fire=(i>=20)?((i<25)?1:2):0;F.m_TargetX=10+i;F.m_TargetY=-i;Q.m_vFrames.push_back(F);}
  CEngine E;CNetObj_PlayerInput I;memset(&I,0,sizeof(I));I.m_Fire=13;E.Apply(I,1);E.BeginPrep(false,&Q);E.SetAnchor(101);
  int PrevFire=-1;for(int t=100;t<145;++t){CNetObj_PlayerInput J;memset(&J,0,sizeof(J));J.m_Fire=13;J.m_TargetX=1;E.Apply(J,t);const int Idx=t-101;if(t==100){assert(J.m_Direction==0);continue;}
   if(Idx>=0&&Idx<40){assert(J.m_Direction==Q.m_vFrames[Idx].m_Direction&&J.m_Jump==Q.m_vFrames[Idx].m_Jump&&J.m_TargetX==10+Idx);assert(((J.m_Fire-E.F0())&MASK)==Q.m_vFrames[Idx].m_Fire);}
   PrevFire=J.m_Fire;}
  assert(E.Mode()==CEngine::EMode::Idle);(void)PrevFire;}
 // --- stop during prep keeps counters continuous ---
 {CEngine E;int F=5,N=1;CNetObj_PlayerInput I=RandomRaw(3,0,F,N);I.m_Fire=6;E.Apply(I,1);
  E.BeginPrep(true,nullptr);CNetObj_PlayerInput J=I;E.Apply(J,2);const int Neutral=J.m_Fire;E.RequestStop();
  CNetObj_PlayerInput K=I;K.m_Fire=6;E.Apply(K,3);assert(E.Mode()==CEngine::EMode::Idle);assert(Presses(Neutral,K.m_Fire)==1||Presses(Neutral,K.m_Fire)==0);
  CNetObj_PlayerInput L=I;L.m_Fire=6;E.Apply(L,4);assert(L.m_Fire==K.m_Fire);}
 // --- addresses ---
 assert(IsLocalIpv4(127,0)&&IsLocalIpv4(192,168)&&IsLocalIpv4(10,3)&&IsLocalIpv4(172,20)&&!IsLocalIpv4(172,40)&&!IsLocalIpv4(8,8)&&!IsLocalIpv4(185,10));
 uint8_t lo[16]={};lo[15]=1;assert(IsLocalIpv6(lo));uint8_t pub[16]={0x20,0x01};assert(!IsLocalIpv6(pub));
 uint8_t m[16]={};m[10]=m[11]=0xff;m[12]=192;m[13]=168;assert(IsLocalIpv6(m));m[12]=8;m[13]=8;assert(!IsLocalIpv6(m));
 printf("ALL OK\n");
}
