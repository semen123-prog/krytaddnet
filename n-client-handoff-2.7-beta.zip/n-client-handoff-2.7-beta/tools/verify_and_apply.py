#!/usr/bin/env python3
"""Verify handoff files, apply 2.7 to a clean official checkout, install verified fonts."""
from pathlib import Path
import subprocess, hashlib, json, zipfile, sys
here = Path(__file__).resolve().parent.parent
base = 'c9d208138f85755521f16a0096b6fe036c5c8698'
manifest = json.loads((here / 'MANIFEST-SHA256.json').read_text())
for name, expected in manifest.items():
    path = here / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit('Integrity check failed: ' + name)
print('Handoff manifest verified:', len(manifest), 'files')
if len(sys.argv) < 2:
    print('To apply: python3 tools/verify_and_apply.py /path/to/clean/ddnet'); sys.exit(0)
repo = Path(sys.argv[1]).resolve()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
if head != base: raise SystemExit('Wrong base commit: ' + head)
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip():
    raise SystemExit('Checkout is not clean. Use a fresh checkout; nothing was reset or deleted.')
patch = (here / 'n-client-2.7-beta.patch').read_bytes()
subprocess.run(['git', 'apply', '--check', '--whitespace=nowarn', '-'], cwd=repo, input=patch, check=True)
subprocess.run(['git', 'apply', '--whitespace=nowarn', '-'], cwd=repo, input=patch, check=True)
fonts = json.loads((here / 'font-hashes.json').read_text())
with zipfile.ZipFile(here / 'n-client-fonts.zip') as archive:
    for name, expected in fonts.items():
        data = archive.read(name)
        if hashlib.sha256(data).hexdigest() != expected: raise SystemExit('Font hash failed: ' + name)
        (repo / 'data' / 'fonts' / name).write_bytes(data)
for name in (here / 'changed-files.txt').read_text().splitlines():
    if (repo / name).read_bytes() != (here / 'source-snapshot' / name).read_bytes():
        raise SystemExit('Applied source differs: ' + name)
print('2.7 applied; sources and 8 fonts verified. Full build/runtime is not tested by this script.')
