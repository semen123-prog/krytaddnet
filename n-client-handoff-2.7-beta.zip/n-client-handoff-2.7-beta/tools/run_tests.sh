#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
REPO=$(realpath "${1:?Usage: run_tests.sh /path/to/patched/ddnet [--native]}")
OUT=${NCLIENT_TEST_OUT:-"$HERE/.test-build"}
mkdir -p "$OUT/generated" "$OUT/unit" "$OUT/native"
OUT=$(realpath "$OUT")
cd "$REPO"
python3 datasrc/compile.py network_header > "$OUT/generated/protocol.h"
python3 datasrc/compile.py content_types_header > "$OUT/generated/data_types.h"
python3 datasrc/compile.py client_content_header > "$OUT/generated/client_data.h"
python3 datasrc/compile.py client_content_source > "$OUT/generated/client_data.cpp"
python3 -m datasrc.seven.compile network_header > "$OUT/generated/protocol7.h"
python3 -m datasrc.seven.compile content_types_header > "$OUT/generated/data_types7.h"
python3 -m datasrc.seven.compile client_content_header > "$OUT/generated/client_data7.h"
python3 datasrc/crosscompile.py map_header > "$OUT/generated/protocolglue.h"
COMMON=(-std=c++20 -pthread -ffunction-sections -fdata-sections -I"$OUT" -Isrc -Isrc/engine/external)
DEBUG=(-D_GLIBCXX_ASSERTIONS -D_GLIBCXX_DEBUG)
for n in tas tas_dummy tas_step_speed input learning unhook_input music music_controls; do
  g++ "${COMMON[@]}" "${DEBUG[@]}" "$HERE/tests/test_$n.cpp" -o "$OUT/unit/test_$n"
  "$OUT/unit/test_$n"
done
g++ "${COMMON[@]}" -O2 "$HERE/tests/test_identity.cpp" src/engine/shared/packer.cpp src/engine/shared/compression.cpp src/base/str.cpp src/base/mem.cpp "$HERE/tests/native/assert_support.cpp" -Wl,--gc-sections -o "$OUT/unit/test_identity"
"$OUT/unit/test_identity"
if [[ ${2:-} == --native ]]; then
  sources=(src/game/client/prediction/gameworld.cpp src/game/client/prediction/entity.cpp src/game/client/prediction/entities/*.cpp src/game/gamecore.cpp src/game/collision.cpp src/game/teamscore.cpp src/game/mapbugs.cpp src/game/client/laser_data.cpp src/game/client/projectile_data.cpp src/game/client/pickup_data.cpp src/base/mem.cpp src/base/str.cpp src/base/time.cpp src/base/hash.cpp src/game/prng.cpp "$OUT/generated/client_data.cpp" "$HERE/tests/native/probe.cpp" "$HERE/tests/native/assert_support.cpp")
  objects=()
  for i in "${!sources[@]}"; do
    obj="$OUT/native/part-$i.o"; objects+=("$obj")
    g++ "${COMMON[@]}" -O2 -c "${sources[$i]}" -o "$obj"
  done
  g++ -pthread -Wl,--gc-sections "${objects[@]}" -o "$OUT/native/probe"
  "$OUT/native/probe"
fi
printf '\nAll requested local tests completed. This is not a Windows or live-server test.\n'
