// n-client settings; Russian labels for the requested custom features.
#include "menus.h"
#include <engine/shared/config.h>
#include <engine/shared/n_client_identity.h>
#include <game/version.h>
#include <engine/textrender.h>
#include <game/client/ui.h>
#include <game/client/gameclient.h>

void CMenus::RenderSettingsNClient(CUIRect MainView)
{
	CUIRect Row;
	MainView.HSplitTop(28.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, "n-client 2.7 beta", 24.0f, TEXTALIGN_ML);
	MainView.HSplitTop(6.0f, nullptr, &MainView);
	static int s_Page = 0;
	{
		CUIRect Tabs, Cells[4];
		MainView.HSplitTop(22.0f, &Tabs, &MainView);
		for(int i = 0; i < 4; ++i) Cells[i] = {Tabs.x + i * Tabs.w / 4.0f, Tabs.y, Tabs.w / 4.0f - 5.0f, Tabs.h};
		static CButtonContainer s_Tabs[4];
		const char *Labels[4] = {"Лазер", "TAS", "Интерфейс", "Сеть"};
		for(int i = 0; i < 4; ++i) if(DoButton_Menu(&s_Tabs[i], Labels[i], s_Page == i, &Cells[i])) s_Page = i;
		MainView.HSplitTop(6.0f, nullptr, &MainView);
	}
	if(s_Page == 1)
	{
		RenderSettingsNTas(MainView);
		return;
	}
	if(s_Page == 3)
	{
		MainView.HSplitTop(22.0f, &Row, &MainView);
		if(DoButton_CheckBox(&g_Config.m_SpoofVersion, "Подмена отправляемых метаданных", g_Config.m_SpoofVersion, &Row)) g_Config.m_SpoofVersion ^= 1;
		static CLineInput s_Name(g_Config.m_SpoofVersionStr, sizeof(g_Config.m_SpoofVersionStr));
		static CLineInput s_Hash(g_Config.m_SpoofGitHash, sizeof(g_Config.m_SpoofGitHash));
		const auto Edit = [&](const char *pLabel, CLineInput &Input) {
			MainView.HSplitTop(24.0f, &Row, &MainView); CUIRect Label, Box;
			Row.VSplitLeft(140.0f, &Label, &Box);
			Ui()->DoLabel(&Label, pLabel, 14.0f, TEXTALIGN_ML);
			Ui()->DoEditBox(&Input, &Box, 14.0f);
			MainView.HSplitTop(4.0f, nullptr, &MainView);
		};
		Edit("Имя и версия", s_Name); Edit("Git hash", s_Hash);
		MainView.HSplitTop(22.0f, &Row, &MainView);
		Ui()->DoScrollbarOption(&g_Config.m_SpoofDDNetVersion, &g_Config.m_SpoofDDNetVersion, &Row, "Номер DDNet (0 = настоящий)", 0, 99999, &CUi::ms_LinearScrollbarScale);
		MainView.HSplitTop(26.0f, &Row, &MainView); CUIRect A, B; Row.VSplitMid(&A, &B, 6.0f);
		static CButtonContainer s_Tater, s_Real;
		if(DoButton_Menu(&s_Tater, "Профиль TClient 10.8.6", 0, &A))
		{
			str_copy(g_Config.m_SpoofVersionStr, "TClient 10.8.6");
			str_copy(g_Config.m_SpoofGitHash, "82d946145072e18f9513ba2427538971");
			g_Config.m_SpoofDDNetVersion = 19080;
			s_Name.SetBuffer(g_Config.m_SpoofVersionStr, sizeof(g_Config.m_SpoofVersionStr));
			s_Hash.SetBuffer(g_Config.m_SpoofGitHash, sizeof(g_Config.m_SpoofGitHash));
		}
		if(DoButton_Menu(&s_Real, "Настоящие данные", 0, &B))
		{
			g_Config.m_SpoofVersion = 0; g_Config.m_SpoofDDNetVersion = 0;
			g_Config.m_SpoofVersionStr[0] = g_Config.m_SpoofGitHash[0] = 0;
			s_Name.SetBuffer(g_Config.m_SpoofVersionStr, sizeof(g_Config.m_SpoofVersionStr));
			s_Hash.SetBuffer(g_Config.m_SpoofGitHash, sizeof(g_Config.m_SpoofGitHash));
		}
		const auto Profile = NIdentity::Build(g_Config.m_SpoofVersion != 0, g_Config.m_SpoofVersionStr, g_Config.m_SpoofGitHash,
			g_Config.m_SpoofDDNetVersion, GameClient()->DDNetVersionStr(), GAME_NAME " " GAME_RELEASE_VERSION, GIT_SHORTREV_HASH, DDNET_VERSION_NUMBER);
		MainView.HSplitTop(28.0f, &Row, &MainView); Ui()->DoLabel(&Row, Profile.m_aVersion, 13.0f, TEXTALIGN_ML);
		MainView.HSplitTop(22.0f, &Row, &MainView); char aNumber[160];
		str_format(aNumber, sizeof(aNumber), "Отправляемый номер DDNet: %d", Profile.m_Number); Ui()->DoLabel(&Row, aNumber, 13.0f, TEXTALIGN_ML);
		const char *Notes[] = {Profile.m_pError ? Profile.m_pError : "Изменения применяются при новом подключении главного / дамми.",
			"NETVERSION, 0.7-протокол и ConnectionID остаются настоящими.",
			"Меняются только строка CLIENTVER и согласованный номер DDNet.",
			"Это не полная эмуляция Tater и не гарантия обхода bad client.",
			"Дополнительные проверки сервера и ответы checksum не подменяются.",
			"Точный номер можно задать в F1: spoof_ddnet_version 19080"};
		for(const char *pNote : Notes) { MainView.HSplitTop(20.0f, &Row, &MainView); Ui()->DoLabel(&Row, pNote, 11.0f, TEXTALIGN_ML); }
		return;
	}
	if(s_Page == 2)
	{
		MainView.HSplitTop(20.0f, &Row, &MainView);
		if(DoButton_CheckBox(&g_Config.m_ClNMusic, "Показывать текущий трек сверху", g_Config.m_ClNMusic, &Row)) g_Config.m_ClNMusic ^= 1;
		MainView.HSplitTop(20.0f, &Row, &MainView);
		if(DoButton_CheckBox(&g_Config.m_ClNMusicFallback, "Резерв: заголовок Spotify / Яндекс Музыки", g_Config.m_ClNMusicFallback, &Row)) g_Config.m_ClNMusicFallback ^= 1;
		MainView.HSplitTop(22.0f, &Row, &MainView);
		static CButtonContainer s_EditMusic, s_ResetMusic;
		CUIRect EditMusic, ResetMusic;
		Row.VSplitRight(126.0f, &EditMusic, &ResetMusic);
		EditMusic.w -= 6.0f;
		if(DoButton_Menu(&s_EditMusic, "Переместить / управление", 0, &EditMusic))
		{
			g_Config.m_ClNMusic = 1;
			g_Config.m_ClNMusicEdit = 1;
		}
		if(DoButton_Menu(&s_ResetMusic, "Сброс позиции", 0, &ResetMusic))
		{
			g_Config.m_ClNMusicX = 20;
			g_Config.m_ClNMusicY = 20;
		}
		MainView.HSplitTop(18.0f, &Row, &MainView);
		const auto Track = GameClient()->m_NMusic.Snapshot();
		Ui()->DoLabel(&Row, g_Config.m_ClNMusic ? NMusic::StatusText(Track.m_Status) : "Музыкальная карточка выключена", 12.0f, TEXTALIGN_ML);
		MainView.HSplitTop(28.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, Track.m_Detail.c_str(), 10.0f, TEXTALIGN_ML);
		MainView.HSplitTop(24.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, "Шрифт всего клиента", 18.0f, TEXTALIGN_ML);
		static const char *const apFonts[] = {"DejaVu Sans", "Arimo", "Cabin", "Montserrat", "Nunito Black", "Pacifico", "Rubik", "Rubik Broken Fax", "Rubik Doodle Shadow", "Comic Sans MS", "Google Sans", "Minecraft"};
		static CButtonContainer s_aFonts[12];
		for(int i = 0; i < 12; i += 2)
		{
			MainView.HSplitTop(22.0f, &Row, &MainView);
			CUIRect Cells[2]; Row.VSplitMid(&Cells[0], &Cells[1], 6.0f);
			for(int j = 0; j < 2; ++j)
			{
				const int Index = i + j;
				if(TextRender()->HasFont(apFonts[Index]))
				{
					if(DoButton_Menu(&s_aFonts[Index], apFonts[Index], str_comp(g_Config.m_ClNClientFont, apFonts[Index]) == 0, &Cells[j]))
						str_copy(g_Config.m_ClNClientFont, apFonts[Index]);
				}
				else
				{
					char aMissing[128]; str_format(aMissing, sizeof(aMissing), "%s (нет файла)", apFonts[Index]);
					Ui()->DoLabel(&Cells[j], aMissing, 12.0f, TEXTALIGN_MC);
				}
			}
			MainView.HSplitTop(3.0f, nullptr, &MainView);
		}
		MainView.HSplitTop(22.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, "Пример: Съешь ещё этих мягких булок · Aa 0123456789", 13.0f, TEXTALIGN_ML);
		MainView.HSplitTop(18.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, "Меню, чат, HUD и консоль. Выбор сохраняется; перезапуск не нужен.", 11.0f, TEXTALIGN_ML);
		MainView.HSplitTop(18.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, "Личные шрифты: data/fonts/custom. После добавления файла перезапусти клиент.", 10.0f, TEXTALIGN_ML);
		return;
	}
	auto Check = [&](int &Value, const char *pLabel) {
		MainView.HSplitTop(18.0f, &Row, &MainView);
		if(DoButton_CheckBox(&Value, pLabel, Value, &Row)) Value ^= 1;
		MainView.HSplitTop(2.0f, nullptr, &MainView);
	};
	Check(g_Config.m_ClLaserAutoUnfreeze, "Laser Auto Unfreeze");
	Check(g_Config.m_ClUnfreezeBeta, "Beta 2.4: точность после анхука (выключить = 1.8)");
	Check(g_Config.m_ClNClientLearn, "1.8: адаптация по серверным результатам");
	Check(g_Config.m_ClNClientFeedbackLog, "Локальный журнал выстрелов nclient-feedback-08.csv");
	Check(g_Config.m_ClNClientStatus, "Показывать причину отказа / статус поиска");
	Check(g_Config.m_ClNClientPrediction, "Показывать линию движения по зажатым кнопкам");
	Check(g_Config.m_ClNClientStrict, "1.8: строгая проверка выстрела");
	Check(g_Config.m_ClNClientOptimize, "1.8: кэш и ограничение частоты расчётов");
	auto Slider = [&](int &Value, const char *pLabel, int Min, int Max, const char *pSuffix) {
		MainView.HSplitTop(20.0f, &Row, &MainView);
		Ui()->DoScrollbarOption(&Value, &Value, &Row, pLabel, Min, Max, &CUi::ms_LinearScrollbarScale, 0u, pSuffix);
		MainView.HSplitTop(3.0f, nullptr, &MainView);
	};
	Slider(g_Config.m_ClUnfreezeBetaAngleStep, "Beta: шаг угла", 1, 15, " град.");
	Slider(g_Config.m_ClUnfreezeBetaMaxBounces, "Beta: максимум отражений", 1, 8, "");
	Slider(g_Config.m_ClNClientPredictionTicks, "Длина предикта", 8, 64, " тиков");
	Slider(g_Config.m_ClNClientPredictionAlpha, "Прозрачность линии", 10, 100, "%");
	Slider(g_Config.m_ClLaserAutoUnfreezeSamples, "1.8: качество поиска угла", 180, 1440, "");
	Slider(g_Config.m_ClLaserAutoUnfreezeBudget, "Бюджет расчёта выстрела", 2, 12, " мс");
	Slider(g_Config.m_ClNClientSearchInterval, "1.8: интервал поиска при оптимизации", 1, 6, " тиков");
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	MainView.HSplitTop(24.0f, &Row, &MainView);
	static CButtonContainer s_Preset;
	if(DoButton_Menu(&s_Preset, "Поиск: 500 / 6 мс / 3 тика; Beta: 3 град. / 3 отраж.", 0, &Row))
	{
		g_Config.m_ClNClientOptimize = 1;
		g_Config.m_ClLaserAutoUnfreezeSamples = 500;
		g_Config.m_ClLaserAutoUnfreezeBudget = 6;
		g_Config.m_ClUnfreezeBetaAngleStep = 3;
		g_Config.m_ClUnfreezeBetaMaxBounces = 3;
		g_Config.m_ClNClientSearchInterval = 3;
	}
	MainView.HSplitTop(20.0f, &Row, &MainView);
	static CButtonContainer s_ResetLearn;
	if(DoButton_Menu(&s_ResetLearn, "Сбросить адаптацию текущей карты", 0, &Row)) GameClient()->m_Controls.ResetNLearning();
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, NLaserStatusText(GameClient()->m_Controls.NLaserStatus(g_Config.m_ClDummy)), 12.0f, TEXTALIGN_ML);
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	const char *apNotes[] = {
		"Голубая линия — движение. Красная — ожидаемая заморозка.",
		"Beta 2.4: запас точности; после анхука проверяются варианты тайминга.",
		"Нужен выбранный лазер, cl_predict 1 и cl_predict_freeze 1.",
		"Обучение локальное, сбрасывается при смене карты/подключения.",
		"Выстрел до freeze. Новый хук запускается первым. Пинг влияет.",
	};
	for(const char *pNote : apNotes)
	{
		MainView.HSplitTop(16.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, pNote, 12.0f, TEXTALIGN_ML);
	}
}

void CMenus::RenderSettingsNTas(CUIRect MainView)
{
	CUIRect Row;
	MainView.HSplitTop(18.0f, &Row, &MainView);
	if(DoButton_CheckBox(&g_Config.m_ClNTas, "Включить TAS", g_Config.m_ClNTas, &Row)) g_Config.m_ClNTas ^= 1;
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	MainView.HSplitTop(18.0f, &Row, &MainView);
	if(DoButton_CheckBox(&g_Config.m_ClLaserAutoUnfreeze, "Авто-анфриз в плане TAS (общий переключатель лазера)", g_Config.m_ClLaserAutoUnfreeze, &Row)) g_Config.m_ClLaserAutoUnfreeze ^= 1;
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	static CButtonContainer s_aReader[5], s_aClear[5];
	auto KeyRow = [&](int Index, int &Key, const char *pLabel) {
		CUIRect Label, KeyRect;
		MainView.HSplitTop(20.0f, &Row, &MainView);
		MainView.HSplitTop(3.0f, nullptr, &MainView);
		Row.VSplitLeft(260.0f, &Label, &KeyRect);
		Ui()->DoLabel(&Label, pLabel, 12.0f, TEXTALIGN_ML);
		KeyRect.VSplitLeft(170.0f, &KeyRect, nullptr);
		const CKeyBinder::CKeyReaderResult Result = GameClient()->m_KeyBinder.DoKeyReader(&s_aReader[Index], &s_aClear[Index], &KeyRect, CBindSlot(Key, KeyModifier::NONE), false);
		if(!Result.m_Aborted && Result.m_Bind.m_Key != Key) Key = Result.m_Bind.m_Key;
	};
	KeyRow(0, g_Config.m_ClNTasKeyRecord, "Начать / закончить TAS-сессию (план)");
	KeyRow(1, g_Config.m_ClNTasKeyPlay, "Проиграть запись в игре");
	KeyRow(2, g_Config.m_ClNTasKeyStop, "Пауза / пуск плана; стоп проигрывания");
	KeyRow(3, g_Config.m_ClNTasKeyBack, "Шаг назад (можно удерживать)");
	KeyRow(4, g_Config.m_ClNTasKeyStep, "Шаг вперёд (можно удерживать)");
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoScrollbarOption(&g_Config.m_ClNTasSlot, &g_Config.m_ClNTasSlot, &Row, "Слот записи", 1, 9, &CUi::ms_LinearScrollbarScale, 0u, "");
	MainView.HSplitTop(3.0f, nullptr, &MainView);
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoScrollbarOption(&g_Config.m_ClNTasSpeed, &g_Config.m_ClNTasSpeed, &Row, "Скорость плана", 5, 100, &CUi::ms_LinearScrollbarScale, 0u, "%");
	MainView.HSplitTop(3.0f, nullptr, &MainView);
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoScrollbarOption(&g_Config.m_ClNTasStepSpeed, &g_Config.m_ClNTasStepSpeed, &Row, "Скорость шагов назад / вперёд", 1, 100, &CUi::ms_LinearScrollbarScale, 0u, " тиков/с");
	MainView.HSplitTop(8.0f, nullptr, &MainView);
	MainView.HSplitTop(24.0f, &Row, &MainView);
	CUIRect ButtonA, ButtonB, ButtonC;
	Row.VSplitLeft(Row.w / 3.0f, &ButtonA, &Row);
	Row.VSplitMid(&ButtonB, &ButtonC);
	static CButtonContainer s_Session, s_Play, s_Stop;
	const bool Planning = GameClient()->m_Tas.Planning();
	if(DoButton_Menu(&s_Session, Planning ? "Закончить сессию" : "Начать сессию", Planning, &ButtonA))
	{
		GameClient()->m_Tas.ToggleSession();
		if(GameClient()->m_Tas.Overriding()) SetActive(false);
	}
	if(DoButton_Menu(&s_Play, "Проиграть", 0, &ButtonB))
	{
		GameClient()->m_Tas.StartPlay();
		if(GameClient()->m_Tas.Overriding()) SetActive(false);
	}
	if(DoButton_Menu(&s_Stop, "Стоп", 0, &ButtonC)) GameClient()->m_Tas.Stop();
	MainView.HSplitTop(8.0f, nullptr, &MainView);
	MainView.HSplitTop(16.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, GameClient()->m_Tas.Status()[0] ? GameClient()->m_Tas.Status() : "Статус: ожидание", 12.0f, TEXTALIGN_ML);
	MainView.HSplitTop(6.0f, nullptr, &MainView);
	const char *apNotes[] = {
		"1) Встань неподвижно на земле (хук убран), начни сессию: делается копия мира.",
		"2) Играй в копии (полупрозрачный тий): пауза, шаг вперёд/назад, замедление.",
		"3) Настоящие тии стоят. С dummy переключай тия обычной кнопкой dummy.",
		"4) Проиграть: оба повторят ввод. Оба старта и оружия должны совпадать.",
		"Dummy: cl_predict_dummy 1; copy moves / control / hammer выключены.",
		"Авто-анфриз: выбери лазер в плане. Выстрел записывается и повторяется.",
		"Позиции сверяются по кадрам, при разнице появится РАССИНХРОН.",
		"Фильтра адресов нет. Соблюдай правила сервера; возможен рассинхрон.",
		"Записи: nclient-tas-1..9.txt, журнал: nclient-tas.log (папка настроек).",
	};
	for(const char *pNote : apNotes)
	{
		MainView.HSplitTop(16.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, pNote, 12.0f, TEXTALIGN_ML);
	}
}
