// n-client 0.4: conservative laser assistance and held-input prediction.
#ifndef GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_H
#define GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_H
#include <base/vmath.h>
#include <generated/protocol.h>
#include <vector>
class CGameWorld;
enum class ENLaserStatus
{
 Disabled, Pending, Paused, PredictionDisabled, DummyMode, ManualFire,
 SelectLaser, WeaponSwitch, Waiting, HistoryUnavailable, BudgetExpired,
 Reloading, AlreadyFrozen, UnsupportedMap, UnsupportedTuning,
 NoFreezeAhead, NoAngle, VerificationFailed, ShotQueued, HookStarting, SuperMode, WaitingAck, NativeNoHit, NativeEarlyHit, NativeOffCenter, NativeRefreeze, NativeShortWindow, NativeLateTick, NativeEarlyTick, BetaNoExit, BetaWaiting, BetaShotQueued, BetaHookUncertain
};
const char *NLaserStatusText(ENLaserStatus Status);
// Match the wire aim lifetime; normal assistance includes its release packet, TAS defaults to one frame.
inline CNetObj_PlayerInput NLaserShotStepInput(CNetObj_PlayerInput Held, ivec2 Aim, int Step, int AimTicks = 1)
{
	if(Step >= 1 && Step <= AimTicks) { Held.m_TargetX = Aim.x; Held.m_TargetY = Aim.y; }
	return Held;
}
// Motion/key changes invalidate a forecast immediately, including within a
// single prediction tick. A released hook must not reuse the held-hook path.
inline bool NLaserMotionChanged(const CNetObj_PlayerInput &A, const CNetObj_PlayerInput &B)
{
	return A.m_Direction != B.m_Direction || A.m_Jump != B.m_Jump || A.m_Hook != B.m_Hook ||
		(A.m_Hook && (A.m_TargetX != B.m_TargetX || A.m_TargetY != B.m_TargetY));
}
inline bool NLaserPathNeedsRefresh(int Tick, int LastTick, int Interval,
	const CNetObj_PlayerInput &Held, const CNetObj_PlayerInput &Previous)
{
	return LastTick < 0 || Tick < LastTick || NLaserMotionChanged(Held, Previous) || Tick - LastTick >= Interval;
}
inline bool NLaserShouldSolve(int Tick, int LastTick, int Interval, bool NearFreeze,
	const CNetObj_PlayerInput &Held, const CNetObj_PlayerInput &Previous)
{
	const bool Changed = NLaserMotionChanged(Held, Previous);
	return Tick > 0 && (Tick != LastTick || Changed) &&
		(Changed || NearFreeze || LastTick < 0 || Tick < LastTick || Tick - LastTick >= Interval);
}
// An early direct shot can precede the scheduled release by one physics tick.
// Replay that tick's KNOWN input (including its old hook aim), then apply the
// new shot/release wire aim for two ticks. Never reset hook/velocity by hand.
inline CNetObj_PlayerInput NLaserVerificationStepInput(CNetObj_PlayerInput Held, ivec2 Aim,
	int Step, int AimTicks, const CNetObj_PlayerInput *pFirstPhysicsInput)
{
	if(pFirstPhysicsInput && Step == 1)
	{
		CNetObj_PlayerInput Past = *pFirstPhysicsInput;
		if(Past.m_Fire & 1) Past.m_Fire = (Past.m_Fire + 1) & INPUT_STATE_MASK;
		Past.m_WantedWeapon = Past.m_NextWeapon = Past.m_PrevWeapon = 0;
		return Past;
	}
	return NLaserShotStepInput(Held, Aim, Step - (pFirstPhysicsInput ? 1 : 0), AimTicks);
}

struct SNPredictionPoint
{
	vec2 m_Pos;
	bool m_Frozen;
	int m_Tick = 0;
};
struct SLaserUnfreezeAim
{
	ivec2 m_Target = ivec2(1, 0);
	int m_ReturnTick = 0;
	int m_LaunchTick = 0;
	std::vector<SNPredictionPoint> m_Forecast;
};
bool BuildNPredictionPath(CGameWorld &Source, int ClientId, const CNetObj_PlayerInput &Input,
	int Ticks, int BudgetMs, std::vector<SNPredictionPoint> &Path);
bool FindLaserUnfreezeAim(CGameWorld &Source, int ClientId,
	const CNetObj_PlayerInput &Input, int Samples, int BudgetMs, SLaserUnfreezeAim &Result,
	bool Strict = true, ivec2 CachedAim = ivec2(0, 0), ENLaserStatus *pStatus = nullptr, float HitMargin = 0.0f, int *pFirstFrozenStep = nullptr, int AimTicks = 1, CGameWorld *pEarlySource = nullptr);
bool FindTutorialUnfreezeAim(CGameWorld &Source, int ClientId,
 const CNetObj_PlayerInput &Input, int AngleStep, int MaxBounces, int BudgetMs,
 SLaserUnfreezeAim &Result, ENLaserStatus *pStatus = nullptr, int *pFirstFrozenStep = nullptr, bool RecentHookRelease = false, CGameWorld *pEarlySource = nullptr);
#endif
