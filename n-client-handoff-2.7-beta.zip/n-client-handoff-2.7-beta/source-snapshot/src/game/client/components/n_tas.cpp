// n-client 2.3 beta: paired TAS. Both connections plan in one private world and replay their own inputs on shared tick labels.
#include "n_tas.h"
#include <base/io.h>
#include <base/mem.h>
#include <base/str.h>
#include <base/time.h>
#include <engine/graphics.h>
#include <engine/shared/config.h>
#include <engine/storage.h>
#include <engine/textrender.h>
#include <game/client/animstate.h>
#include <game/client/gameclient.h>
#include <game/client/prediction/entities/character.h>
#include <game/client/prediction/entities/laser.h>
#include <game/client/prediction/entities/projectile.h>
#include <game/client/projectile_data.h>
#include <game/client/render.h>
#include <cmath>

namespace
{
bool IsFrozenChar(const CCharacter *pChar)
{
	return pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen;
}
const char *const gs_apWeaponNames[NUM_WEAPONS] = {"Молоток", "Пистолет", "Дробовик", "Гранатомёт", "Лазер", "Ниндзя"};
} // namespace

int CNTas::GotMask(const CCharacter *pChar)
{
	int Mask = 0;
	for(int w = 0; w < NUM_WEAPONS; ++w)
		if(pChar->Core()->m_aWeapons[w].m_Got) Mask |= 1 << w;
	return Mask;
}

void CNTas::SetStatus(const char *pText, int Seconds)
{
	str_copy(m_aStatus, pText, sizeof(m_aStatus));
	m_StatusUntil = time_get() + (int64_t)Seconds * time_freq();
}

void CNTas::Log(const char *pEvent, const char *pDetail)
{
	IOHANDLE File = Storage()->OpenFile("nclient-tas.log", IOFLAG_APPEND, IStorage::TYPE_SAVE);
	if(!File) return;
	if(io_length(File) < 256 * 1024)
	{
		char aLine[400];
		str_format(aLine, sizeof(aLine), "%lld,%s,%s\n", (long long)(time_get() / time_freq()), pEvent, pDetail);
		io_write(File, aLine, str_length(aLine));
	}
	io_close(File);
}

bool CNTas::Save(int Slot)
{
	char aPath[64];
	str_format(aPath, sizeof(aPath), "nclient-tas-%d.txt", Slot);
	IOHANDLE File = Storage()->OpenFile(aPath, IOFLAG_WRITE, IStorage::TYPE_SAVE);
	if(!File) return false;
	const std::string Text = NTas::Serialize(m_Plan);
	const bool Ok = io_write(File, Text.data(), Text.size()) == Text.size();
	io_close(File);
	return Ok;
}

void CNTas::BuildPlanPos()
{
	for(int Role = 0; Role < 2; ++Role)
	{
		auto &Positions = m_aActors[Role].m_PlanPos;
		Positions.clear();
		for(const NTas::SPos &P : Track(Role).m_vPos) Positions[P.m_Idx] = {P.m_X, P.m_Y};
	}
}

bool CNTas::Load(int Slot)
{
	char aPath[64];
	str_format(aPath, sizeof(aPath), "nclient-tas-%d.txt", Slot);
	IOHANDLE File = Storage()->OpenFile(aPath, IOFLAG_READ, IStorage::TYPE_SAVE);
	if(!File) return false;
	char *pText = io_read_all_str(File);
	io_close(File);
	if(!pText) return false;
	NTas::SRecording R;
	const bool Ok = NTas::Parse(pText, R);
	free(pText);
	if(!Ok || R.m_vFrames.empty()) return false;
	m_Plan = std::move(R);
	BuildPlanPos();
	return true;
}

bool CNTas::CanStart()
{
	if(!g_Config.m_ClNTas)
	{
		SetStatus("TAS выключен: включи галочку в Settings -> n-client -> TAS.");
		return false;
	}
	if(Client()->State() != IClient::STATE_ONLINE || GameClient()->m_Snap.m_SpecInfo.m_Active || !GameClient()->m_Snap.m_pLocalCharacter)
	{
		SetStatus("TAS: нужно быть живым на сервере и не в наблюдателе.");
		return false;
	}
	if(Client()->DummyConnected())
	{
		if(!GameClient()->PredictDummy())
		{
			SetStatus("TAS dummy: включи cl_predict_dummy 1; оба тия должны быть живы и не в паузе.");
			return false;
		}
		if(g_Config.m_ClDummyCopyMoves || g_Config.m_ClDummyControl || g_Config.m_ClDummyHammer)
		{
			SetStatus("TAS dummy: выключи copy moves, dummy control и hammer. Управление — обычным переключением тия.");
			return false;
		}
	}
	return true;
}

int CNTas::ActiveRole() const
{
	return m_WithDummy ? (g_Config.m_ClDummy ^ m_MainConn) : 0;
}

void CNTas::SelectMainConnection(int Conn)
{
	if(Conn == m_MainConn) return;
	// Actor state follows its actual network connection, even between sessions.
	std::swap(m_aActors[0], m_aActors[1]);
	m_MainConn = Conn;
}

CNetObj_PlayerInput CNTas::LiveInput(int Role) const
{
	const int Conn = Connection(Role);
	CNetObj_PlayerInput In = Conn == g_Config.m_ClDummy ?
		GameClient()->m_Controls.NClientHeldInput(Conn) : GameClient()->m_DummyInput;
	if(!In.m_TargetX && !In.m_TargetY) In.m_TargetX = 1;
	return In;
}

bool CNTas::CheckActors()
{
	if(!Overriding()) return true;
	if((bool)Client()->DummyConnected() != m_WithDummy || (!m_WithDummy && g_Config.m_ClDummy != m_MainConn))
	{
		Abort("TAS остановлен: подключение dummy изменилось.");
		return false;
	}
	if(m_WithDummy && (!GameClient()->PredictDummy() || g_Config.m_ClDummyCopyMoves || g_Config.m_ClDummyControl || g_Config.m_ClDummyHammer))
	{
		Abort("TAS остановлен: предикт dummy выключен или включён автоматический режим dummy.");
		return false;
	}
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		const int Id = m_aActors[Role].m_LocalId;
		if(Id < 0 || Id >= MAX_CLIENTS || GameClient()->m_aLocalIds[Connection(Role)] != Id || !GameClient()->m_Snap.m_aCharacters[Id].m_Active || GameClient()->m_aClients[Id].m_Paused)
		{
			Abort("TAS остановлен: один из настоящих тиев умер, в паузе или сменил ID.");
			return false;
		}
	}
	return true;
}

void CNTas::OnDummySwap()
{
	// DDNet reassigns the fire counters on a swap. Do not interpret that
	// reassignment as dozens of fresh presses in the planning recording.
	if(m_Planning) for(int Role = 0; Role < ActorCount(); ++Role) ResyncLive(Role);
}

bool CNTas::AtRest(int Conn, vec2 *pPos) const
{
	const CCharacter *pChar = GameClient()->m_PredictedWorld.GetCharacterById(GameClient()->m_aLocalIds[Conn]);
	if(!pChar) return false;
	if(pPos) *pPos = pChar->GetPos();
	const vec2 Vel = pChar->Core()->m_Vel;
	return std::abs(Vel.x) < 0.02f && std::abs(Vel.y) < 0.02f && pChar->Core()->m_HookState == HOOK_IDLE;
}

void CNTas::FreeSim()
{
	ResetStepRepeat();
	m_pSim.reset();
	m_vKeys.clear();
}

CNetObj_PlayerInput CNTas::InputFromFrame(const NTas::SFrame &F, int Role) const
{
	CNetObj_PlayerInput In;
	mem_zero(&In, sizeof(In));
	In.m_Direction = F.m_Direction;
	In.m_Jump = F.m_Jump;
	In.m_Hook = F.m_Hook;
	In.m_Fire = (m_aActors[Role].m_Engine.F0() + F.m_Fire) & NTas::MASK;
	In.m_NextWeapon = (m_aActors[Role].m_Engine.N0() + F.m_Next) & NTas::MASK;
	In.m_PrevWeapon = (m_aActors[Role].m_Engine.P0() + F.m_Prev) & NTas::MASK;
	In.m_WantedWeapon = F.m_Weapon;
	In.m_TargetX = F.m_TargetX;
	In.m_TargetY = F.m_TargetY;
	In.m_PlayerFlags = PLAYERFLAG_PLAYING;
	return In;
}

void CNTas::ResyncLive(int Role)
{
	const CNetObj_PlayerInput L = LiveInput(Role);
	m_aActors[Role].m_LiveFire = L.m_Fire & NTas::MASK;
	m_aActors[Role].m_LiveNext = L.m_NextWeapon & NTas::MASK;
	m_aActors[Role].m_LivePrev = L.m_PrevWeapon & NTas::MASK;
}

NTas::SFrame CNTas::FrameFromLive(int Role)
{
	const CNetObj_PlayerInput L = LiveInput(Role); // input belongs to the physical connection, not the currently selected tee
	NTas::SFrame F;
	F.m_Direction = std::clamp(L.m_Direction, -1, 1);
	F.m_Jump = L.m_Jump ? 1 : 0;
	F.m_Hook = L.m_Hook ? 1 : 0;
	F.m_Weapon = L.m_WantedWeapon;
	F.m_TargetX = L.m_TargetX;
	F.m_TargetY = L.m_TargetY;
	if(!F.m_TargetX && !F.m_TargetY) F.m_TargetX = 1;
	m_aActors[Role].m_Aim = vec2((float)F.m_TargetX, (float)F.m_TargetY);
	int DFire = (L.m_Fire - m_aActors[Role].m_LiveFire) & NTas::MASK;
	if((((m_aActors[Role].m_CumFire + DFire) & 1) != (L.m_Fire & 1))) DFire += 1; // keep "pressed" in the plan equal to "pressed" on the keyboard
	m_aActors[Role].m_CumFire += DFire;
	const int DNext = (L.m_NextWeapon - m_aActors[Role].m_LiveNext) & NTas::MASK;
	const int DPrev = (L.m_PrevWeapon - m_aActors[Role].m_LivePrev) & NTas::MASK;
	m_aActors[Role].m_CumNext += DNext;
	m_aActors[Role].m_CumPrev += DPrev;
	ResyncLive(Role);
	F.m_Fire = m_aActors[Role].m_CumFire;
	F.m_Next = m_aActors[Role].m_CumNext;
	F.m_Prev = m_aActors[Role].m_CumPrev;
	// Only solve while creating a new plan frame. Rewind re-simulation and
	// replay use the stored fire/aim verbatim, never a new wall-clock search.
	m_aActors[Role].m_PlanLaserStatus = ENLaserStatus::Disabled;
	if(g_Config.m_ClLaserAutoUnfreeze && m_Planning && m_pSim && !m_SimDead)
	{
		if((L.m_Fire & 1) || DFire > 0)
			m_aActors[Role].m_PlanLaserStatus = ENLaserStatus::ManualFire;
		else if(DNext || DPrev)
			m_aActors[Role].m_PlanLaserStatus = ENLaserStatus::WeaponSwitch;
		else
		{
			SLaserUnfreezeAim Aim;
			const CNetObj_PlayerInput Held = InputFromFrame(F, Role);
			// The planning world is already at the pre-input launch tick.
			// No live-world reconstruction, server feedback or learning here.
			if(FindLaserUnfreezeAim(*m_pSim, m_aActors[Role].m_LocalId, Held,
				g_Config.m_ClLaserAutoUnfreezeSamples, g_Config.m_ClLaserAutoUnfreezeBudget,
				Aim, g_Config.m_ClNClientStrict, ivec2(0, 0), &m_aActors[Role].m_PlanLaserStatus) &&
				NTas::AddLaserAutoShot(F, m_aActors[Role].m_Engine.F0(), Aim.m_Target.x, Aim.m_Target.y))
			{
				m_aActors[Role].m_CumFire = F.m_Fire;
				char aBuf[100];
				str_format(aBuf, sizeof(aBuf), "frame=%d role=%d aim=%d,%d", (int)m_Plan.m_vFrames.size(), Role, Aim.m_Target.x, Aim.m_Target.y);
				Log("plan_auto_unfreeze", aBuf);
			}
		}
	}
	return F;
}

bool CNTas::AdvanceSim(const NTas::SFrame &F, const NTas::SFrame &D, bool Record)
{
	if(!m_pSim) return false;
	CCharacter *apChars[2] = {};
	CNetObj_PlayerInput aInputs[2] = {};
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		apChars[Role] = m_pSim->GetCharacterById(m_aActors[Role].m_LocalId);
		if(!apChars[Role]) { m_SimDead = true; return false; }
		aInputs[Role] = InputFromFrame(Role ? D : F, Role);
	}
	NTas::ApplyPairTick(*m_pSim, apChars[0], aInputs[0], m_WithDummy ? apChars[1] : nullptr, aInputs[1]);
	const int Idx = (int)m_Plan.m_vFrames.size();
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &A = m_aActors[Role];
		A.m_SimPrev = A.m_SimCur;
		if(const CCharacter *pChar = m_pSim->GetCharacterById(A.m_LocalId)) A.m_SimCur = pChar->GetPos();
		else m_SimDead = true;
		const auto &Frame = Role ? D : F;
		A.m_Aim = vec2((float)Frame.m_TargetX, (float)Frame.m_TargetY);
		if(Record)
		{
			Track(Role).m_vFrames.push_back(Frame);
			Track(Role).m_vPos.push_back({Idx, round_to_int(A.m_SimCur.x), round_to_int(A.m_SimCur.y)});
		}
	}
	if(Record && (Idx + 1) % KEY_INTERVAL == 0 && (int)m_vKeys.size() == (Idx + 1) / KEY_INTERVAL)
	{
		m_vKeys.push_back(std::make_unique<CGameWorld>());
		m_vKeys.back()->CopyWorld(m_pSim.get(), false);
	}
	return true;
}

void CNTas::StepLive()
{
	if((int)m_Plan.m_vFrames.size() >= MAX_PLAN_TICKS)
	{
		m_Paused = true;
		SetStatus("Достигнут предел сессии (2 мин). Заверши сессию и начни новую.");
		return;
	}
	const NTas::SFrame F = FrameFromLive(0);
	const NTas::SFrame D = m_WithDummy ? FrameFromLive(1) : NTas::SFrame();
	AdvanceSim(F, D, true);
	if(m_SimDead)
	{
		m_Paused = true;
		SetStatus("TAS-тий умер. Шаг назад (кнопка назад) отменит последние тики.", 10);
	}
}

void CNTas::RewindTo(int Tick)
{
	if(!m_Planning || !m_pSim) return;
	Tick = std::clamp(Tick, 0, (int)m_Plan.m_vFrames.size());
	if(Tick == (int)m_Plan.m_vFrames.size()) return;
	const size_t Key = std::min<size_t>(Tick / KEY_INTERVAL, m_vKeys.size() - 1);
	m_pSim->CopyWorld(m_vKeys[Key].get(), false);
	m_SimDead = false;
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &A = m_aActors[Role];
		if(const CCharacter *pChar = m_pSim->GetCharacterById(A.m_LocalId)) A.m_SimCur = A.m_SimPrev = pChar->GetPos();
	}
	for(int i = (int)Key * KEY_INTERVAL; i < Tick; ++i)
		AdvanceSim(m_Plan.m_vFrames[i], m_WithDummy ? m_Plan.m_Dummy.m_vFrames[i] : NTas::SFrame(), false);
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &T = Track(Role);
		auto &A = m_aActors[Role];
		T.m_vFrames.resize(Tick);
		T.m_vPos.resize(Tick);
		A.m_CumFire = Tick > 0 ? T.m_vFrames.back().m_Fire : 0;
		A.m_CumNext = Tick > 0 ? T.m_vFrames.back().m_Next : 0;
		A.m_CumPrev = Tick > 0 ? T.m_vFrames.back().m_Prev : 0;
		if(Tick > 0) A.m_Aim = vec2((float)T.m_vFrames.back().m_TargetX, (float)T.m_vFrames.back().m_TargetY);
		A.m_SimPrev = A.m_SimCur;
		A.m_PlanLaserStatus = ENLaserStatus::Disabled;
		ResyncLive(Role);
	}
	m_vKeys.resize(std::min<size_t>(m_vKeys.size(), Tick / KEY_INTERVAL + 1));
	m_Accum = 0.0f;
}

void CNTas::ToggleSession()
{
	if(m_Planning) { EndSession("Сессия закончена."); return; }
	if(Overriding()) { SetStatus("TAS уже работает: нажми Стоп."); return; }
	if(!CanStart()) return;
	SelectMainConnection(g_Config.m_ClDummy);
	m_WithDummy = Client()->DummyConnected();
	vec2 aPos[2];
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		if(!AtRest(Connection(Role), &aPos[Role]))
		{
			SetStatus(m_WithDummy ? "Встаньте обоими тиями неподвижно на земле (оба хука убраны) и повтори." : "Встань неподвижно на земле (хук убран) и повтори.");
			return;
		}
		m_aActors[Role].m_LocalId = GameClient()->m_aLocalIds[Connection(Role)];
	}
	m_pSim = std::make_unique<CGameWorld>();
	m_pSim->CopyWorld(&GameClient()->m_PredictedWorld, false);
	m_pSim->m_LocalClientId = GameClient()->m_PredictedWorld.m_LocalClientId;
	m_pSim->m_WorldConfig.m_PredictFreeze = 1;
	m_pSim->m_WorldConfig.m_PredictTiles = true;
	m_pSim->m_WorldConfig.m_PredictDDRace = true;
	m_pSim->m_WorldConfig.m_PredictWeapons = true;
	m_pSim->m_WorldConfig.m_PredictEvents = false;
	m_pSim->m_PredictedEvents.clear();
	for(CCharacter *pChar = (CCharacter *)m_pSim->FindFirst(CGameWorld::ENTTYPE_CHARACTER); pChar; pChar = (CCharacter *)pChar->TypeNext()) pChar->m_CanMoveInFreeze = false;
	m_Plan = NTas::SRecording();
	m_Plan.m_HasDummy = m_WithDummy;
	m_Plan.m_MainConnection = m_MainConn;
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &A = m_aActors[Role];
		const CCharacter *pChar = m_pSim->GetCharacterById(A.m_LocalId);
		if(!pChar) { FreeSim(); SetStatus("Нет предикта одного из тиев: проверь cl_predict 1 и cl_predict_dummy 1."); return; }
		auto &T = Track(Role);
		T.m_Lead = 0;
		T.m_HasStart = T.m_HasLoadout = true;
		T.m_StartX = round_to_int(aPos[Role].x); T.m_StartY = round_to_int(aPos[Role].y);
		T.m_Active = std::clamp(pChar->Core()->m_ActiveWeapon, 0, NUM_WEAPONS - 1);
		T.m_GotMask = GotMask(pChar);
		A.m_PlanPos.clear();
		A.m_HaveRaw = false;
		A.m_Engine.BeginPrep(true, nullptr);
		A.m_CumFire = A.m_CumNext = A.m_CumPrev = 0;
		A.m_PlanLaserStatus = ENLaserStatus::Disabled;
		ResyncLive(Role);
		A.m_SimPrev = A.m_SimCur = aPos[Role];
	}
	m_vKeys.clear();
	m_vKeys.push_back(std::make_unique<CGameWorld>());
	m_vKeys.back()->CopyWorld(m_pSim.get(), false);
	m_SavedSlot = g_Config.m_ClNTasSlot;
	m_Planning = true; m_Paused = true; m_SimDead = false;
	m_PlayDonePending = false; m_Accum = 0.0f;
	SetStatus(m_WithDummy ? "TAS: оба тия в плане. Переключай тия обычной кнопкой dummy; шаги и откат общие. Настоящие тии стоят." : "TAS-сессия: пауза. Шаг '.', назад ','. Огонь/оружие пишутся в план.", 15);
	char aBuf[100];
	str_format(aBuf, sizeof(aBuf), "start=%d,%d dummy=%d conn=%d", m_Plan.m_StartX, m_Plan.m_StartY, m_WithDummy, m_MainConn);
	Log("session_start", aBuf);
}

void CNTas::EndSession(const char *pWhy)
{
	char aBuf[220];
	const int Frames = (int)m_Plan.m_vFrames.size();
	if(Frames >= 5)
	{
		if(Save(m_SavedSlot))
			str_format(aBuf, sizeof(aBuf), "%s Сохранено: слот %d, %d кадров (%.1f с). Проиграть: кнопка воспроизведения.", pWhy, m_SavedSlot, Frames, Frames / 50.0f);
		else
			str_format(aBuf, sizeof(aBuf), "%s НЕ УДАЛОСЬ СОХРАНИТЬ запись!", pWhy);
	}
	else
		str_format(aBuf, sizeof(aBuf), "%s Слишком коротко, не сохранено.", pWhy);
	SetStatus(aBuf, 10);
	Log("session_end", aBuf);
	m_Planning = false;
	FreeSim();
	for(auto &A : m_aActors) A.m_Engine.RequestStop();
}

void CNTas::Abort(const char *pWhy)
{
	m_PlayDonePending = false;
	m_Planning = false;
	FreeSim();
	for(auto &A : m_aActors) A.m_Engine.RequestStop();
	SetStatus(pWhy, 8);
	Log("abort", pWhy);
}

void CNTas::StartPlay()
{
	if(!CanStart()) return;
	if(Playing()) { SetStatus("Уже проигрывается: нажми Стоп."); return; }
	if(!m_Planning && Overriding()) { SetStatus("Дождись остановки предыдущей сессии."); return; }
	if(m_Planning)
	{
		if(!CheckActors()) return;
		if(m_Plan.m_vFrames.size() < 5) { SetStatus("Слишком мало кадров для проигрывания."); return; }
		Save(m_SavedSlot);
	}
	else
	{
		if(!Load(g_Config.m_ClNTasSlot)) { SetStatus("В слоте нет записи или файл повреждён."); return; }
		SelectMainConnection(m_Plan.m_HasDummy ? m_Plan.m_MainConnection : g_Config.m_ClDummy);
		m_WithDummy = m_Plan.m_HasDummy;
	}
	if(m_Plan.m_HasDummy != (bool)Client()->DummyConnected())
	{
		SetStatus(m_Plan.m_HasDummy ? "Запись с dummy: подключи живого dummy." : "Запись одного тия: отключи dummy перед проигрыванием.");
		return;
	}
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &A = m_aActors[Role];
		A.m_LocalId = GameClient()->m_aLocalIds[Connection(Role)];
		const auto &T = Track(Role);
		if(A.m_LocalId < 0 || A.m_LocalId >= MAX_CLIENTS || !GameClient()->m_Snap.m_aCharacters[A.m_LocalId].m_Active || GameClient()->m_aClients[A.m_LocalId].m_Paused)
		{
			SetStatus("Оба тия должны быть живы, видимы в предикте и не в паузе."); return;
		}
		const CNetObj_Character &Snap = GameClient()->m_Snap.m_aCharacters[A.m_LocalId].m_Cur;
		const CCharacter *pReal = GameClient()->m_PredictedWorld.GetCharacterById(A.m_LocalId);
		if(!pReal) { SetStatus("Нет предикта тия. Проверь cl_predict и cl_predict_dummy."); return; }
		if(T.m_HasStart)
		{
			const float dx = (float)(Snap.m_X - T.m_StartX), dy = (float)(Snap.m_Y - T.m_StartY);
			const float Dist = std::sqrt(dx * dx + dy * dy);
			if(Dist > 1.5f || std::abs(Snap.m_VelX) > 6 || std::abs(Snap.m_VelY) > 6 || Snap.m_HookState != HOOK_IDLE)
			{
				char aBuf[220];
				str_format(aBuf, sizeof(aBuf), "Тий %d: встань неподвижно на старт x %d, y %d (откл. %.1f px), убери хук.", Role + 1, T.m_StartX, T.m_StartY, Dist);
				SetStatus(aBuf, 10); return;
			}
		}
		if(T.m_HasLoadout && (GotMask(pReal) != T.m_GotMask || pReal->Core()->m_ActiveWeapon != T.m_Active))
		{
			char aBuf[220];
			str_format(aBuf, sizeof(aBuf), "Тий %d: оружие не совпало. Возьми %s; нужен набор %d.", Role + 1, gs_apWeaponNames[T.m_Active], T.m_GotMask);
			SetStatus(aBuf, 10); return;
		}
	}
	BuildPlanPos();
	m_Planning = false;
	FreeSim();
	const int Anchor = Client()->PredGameTick(g_Config.m_ClDummy) + 1;
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &A = m_aActors[Role];
		NTas::SRecording Playback;
		static_cast<NTas::STrack &>(Playback) = Track(Role);
		A.m_HaveRaw = false;
		A.m_Engine.BeginPrep(false, &Playback);
		A.m_Engine.SetAnchor(Anchor);
		A.m_FirstDesync = -1; A.m_LastLabel = 0;
		A.m_Dev = A.m_MaxDev = 0.0f; A.m_LastCmpTick = -1;
	}
	m_FilledGaps = 0; m_FirstGapIdx = -1; m_LastIdx = 0; m_PlayDonePending = false;
	Log("play_start", m_WithDummy ? "paired" : "single");
	SetStatus(m_WithDummy ? "ПРОИГРЫВАНИЕ. Оба ввода по общим тикам. Не нажимай кнопки." : "ПРОИГРЫВАНИЕ. Не нажимай кнопки.", 5);
}

void CNTas::Stop()
{
	if(m_Planning)
		EndSession("Сессия остановлена.");
	else if(Playing())
	{
		char aBuf[100];
		str_format(aBuf, sizeof(aBuf), "Проигрывание остановлено на кадре %d.", m_LastIdx);
		Abort(aBuf);
	}
}

void CNTas::TogglePause()
{
	if(!m_Planning) return;
	ResetStepRepeat();
	m_Paused = !m_Paused;
	m_Accum = 0.0f;
	if(!m_Paused) for(int Role = 0; Role < ActorCount(); ++Role) ResyncLive(Role);
	SetStatus(m_Paused ? "Пауза." : "Идёт.", 2);
}

void CNTas::Step(int Direction)
{
	if(!m_Planning || !m_pSim) return;
	m_Paused = true;
	if(Direction < 0)
		RewindTo((int)m_Plan.m_vFrames.size() - 1);
	else if(!m_SimDead)
		StepLive();
}

void CNTas::OverrideLocalPos(vec2 &Pos) const
{
	if(!m_Planning || !m_pSim) return;
	const float t = m_Paused ? 1.0f : std::clamp(m_Accum, 0.0f, 1.0f);
	const auto &A = m_aActors[ActiveRole()];
	Pos = mix(A.m_SimPrev, A.m_SimCur, t);
}

void CNTas::OnReset()
{
	m_Planning = false;
	FreeSim();
	for(auto &A : m_aActors) { A.m_Engine.HardReset(); A.m_HaveRaw = false; A.m_LocalId = -1; }
	m_WithDummy = false; m_PlayDonePending = false;
}

void CNTas::OnStateChange(int NewState, int /*OldState*/)
{
	if(NewState != IClient::STATE_ONLINE) OnReset();
}

void CNTas::OnNewSnapshot()
{
	if(!Overriding() || m_aActors[0].m_Engine.Closing()) return;
	if(!CheckActors()) return;
	if(GameClient()->m_Snap.m_SpecInfo.m_Active) { Abort("TAS остановлен: наблюдатель."); return; }
	if(m_Planning || !Playing()) return;
	m_LastIdx = std::max(0, Client()->GameTick(g_Config.m_ClDummy) - m_aActors[0].m_Engine.Anchor());
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		auto &A = m_aActors[Role];
		const auto &Snap = GameClient()->m_Snap.m_aCharacters[A.m_LocalId].m_Cur;
		if(Snap.m_Tick <= 0 || Snap.m_Tick == A.m_LastCmpTick) continue;
		A.m_LastCmpTick = Snap.m_Tick;
		const int Idx = Snap.m_Tick - A.m_Engine.Anchor();
		const auto It = A.m_PlanPos.find(Idx);
		if(Idx < 0 || It == A.m_PlanPos.end()) continue;
		const float dx = (float)(Snap.m_X - It->second.first), dy = (float)(Snap.m_Y - It->second.second);
		A.m_Dev = std::sqrt(dx * dx + dy * dy);
		A.m_MaxDev = std::max(A.m_MaxDev, A.m_Dev);
		if(A.m_FirstDesync < 0 && A.m_Dev > 1.5f)
		{
			A.m_FirstDesync = Idx;
			char aBuf[100];
			str_format(aBuf, sizeof(aBuf), "role=%d frame=%d dev=%.1f", Role, Idx, A.m_Dev);
			Log("desync", aBuf);
		}
	}
}

int CNTas::Process(int *pData, int Size, bool Dummy)
{
	const int Conn = g_Config.m_ClDummy ^ (int)Dummy;
	// Idle engines also track both protocol baselines; when a session starts
	// with the dummy selected, counters must belong to that connection.
	int Role = Conn ^ m_MainConn;
	if(!m_WithDummy && Role != 0 && !m_aActors[Role].m_Engine.Overriding())
	{
		if(Size == (int)sizeof(CNetObj_PlayerInput))
		{
			CNetObj_PlayerInput In;
			mem_copy(&In, pData, sizeof(In));
			m_aActors[Role].m_Engine.Apply(In, Client()->PredGameTick(g_Config.m_ClDummy));
			mem_copy(pData, &In, sizeof(In));
		}
		return Size;
	}
	if(Overriding() && !m_aActors[Role].m_Engine.Closing()) CheckActors();
	auto &A = m_aActors[Role];
	if(Size == (int)sizeof(CNetObj_PlayerInput))
	{
		mem_copy(&A.m_LastRaw, pData, sizeof(A.m_LastRaw));
		A.m_HaveRaw = true;
	}
	else if(!A.m_Engine.Overriding()) return Size;
	CNetObj_PlayerInput In = A.m_HaveRaw ? A.m_LastRaw : LiveInput(Role);
	// SendInput labels BOTH connections with the selected connection's tick.
	// PredGameTick(Conn) is stale for the inactive connection: never use it.
	const int Label = Client()->PredGameTick(g_Config.m_ClDummy);
	if(A.m_Engine.Mode() == NTas::CEngine::EMode::Playing && !A.m_Engine.Closing())
	{
		if(A.m_LastLabel > 0 && Label > A.m_LastLabel + 1 && Label - A.m_LastLabel <= 6)
		{
			for(int L = A.m_LastLabel + 1; L < Label; ++L)
			{
				CNetObj_PlayerInput Extra;
				if(!A.m_Engine.FrameInput(L, In, Extra)) continue;
				Client()->SendInputAtTick(Conn, L, (const int *)&Extra, sizeof(Extra));
				++m_FilledGaps;
				if(m_FirstGapIdx < 0) m_FirstGapIdx = L - A.m_Engine.Anchor();
				char aBuf[80];
				str_format(aBuf, sizeof(aBuf), "role=%d frame=%d", Role, L - A.m_Engine.Anchor());
				Log("label_gap_filled", aBuf);
			}
		}
		A.m_LastLabel = Label;
	}
	const bool Force = A.m_Engine.Apply(In, Label);
	if(Size == 0 && !Force) return 0;
	mem_copy(pData, &In, sizeof(In));
	return sizeof(In);
}

bool CNTas::OnInput(const IInput::CEvent &Event)
{
	// Release must clear the hold even if a menu/console opened or TAS was
	// disabled while the key was held. SDL repeat also carries FLAG_PRESS.
	const bool Press = (Event.m_Flags & IInput::FLAG_PRESS) && !(Event.m_Flags & IInput::FLAG_REPEAT);
	if((Event.m_Flags & IInput::FLAG_RELEASE) && Event.m_Key == m_StepKey)
	{
		ResetStepRepeat();
		if(!Press) return true;
	}
	if(!g_Config.m_ClNTas || Event.m_Key == KEY_UNKNOWN || !(Event.m_Flags & (IInput::FLAG_PRESS | IInput::FLAG_REPEAT))) return false;
	if(Client()->State() != IClient::STATE_ONLINE) return false;
	if(GameClient()->m_Chat.IsActive() || GameClient()->m_Menus.IsActive() || GameClient()->m_GameConsole.IsActive() || GameClient()->m_KeyBinder.IsActive())
		return false;
	if(m_Planning && (Event.m_Key == g_Config.m_ClNTasKeyBack || Event.m_Key == g_Config.m_ClNTasKeyStep))
	{
		// Consume OS repeats without applying more steps: UpdateStepRepeat
		// alone determines the hold rate, independently of FPS/OS settings.
		if(Press)
		{
			ResetStepRepeat();
			const int Direction = Event.m_Key == g_Config.m_ClNTasKeyBack ? -1 : 1;
			Step(Direction);
			if(!(Event.m_Flags & IInput::FLAG_RELEASE))
			{
				m_StepKey = Event.m_Key;
				m_StepRepeat.Begin(Direction, (double)time_get() / time_freq());
			}
		}
		return true;
	}
	if(!Press) return false;
	if(Event.m_Key == g_Config.m_ClNTasKeyRecord)
	{
		ToggleSession();
		return true;
	}
	if(Event.m_Key == g_Config.m_ClNTasKeyPlay)
	{
		StartPlay();
		return true;
	}
	if(Event.m_Key == g_Config.m_ClNTasKeyStop)
	{
		if(m_Planning) TogglePause();
		else Stop();
		return true;
	}
	return false;
}

void CNTas::ResetStepRepeat()
{
	m_StepRepeat.Reset();
	m_StepKey = KEY_UNKNOWN;
}

void CNTas::UpdateStepRepeat()
{
	const int Direction = m_StepRepeat.Direction();
	if(!Direction) return;
	if(!m_Planning || !m_pSim || !g_Config.m_ClNTas || !Input()->KeyIsPressed(m_StepKey) ||
		m_StepKey != (Direction < 0 ? g_Config.m_ClNTasKeyBack : g_Config.m_ClNTasKeyStep) ||
		GameClient()->m_Menus.IsActive() || GameClient()->m_Chat.IsActive() || GameClient()->m_GameConsole.IsActive() || GameClient()->m_KeyBinder.IsActive())
	{
		ResetStepRepeat();
		return;
	}
	if(!CheckActors()) { ResetStepRepeat(); return; }
	const int Steps = m_StepRepeat.Update((double)time_get() / time_freq(), g_Config.m_ClNTasStepSpeed);
	for(int i = 0; i < Steps; ++i)
	{
		if((Direction < 0 && m_Plan.m_vFrames.empty()) ||
			(Direction > 0 && (m_SimDead || (int)m_Plan.m_vFrames.size() >= MAX_PLAN_TICKS)))
		{
			ResetStepRepeat();
			break;
		}
		Step(Direction);
	}
}

void CNTas::UpdatePlanning()
{
	if(!m_Planning || !m_pSim || !CheckActors() || m_Paused || m_SimDead) return;
	if(GameClient()->m_Menus.IsActive() || GameClient()->m_Chat.IsActive()) return;
	m_Accum += Client()->RenderFrameTime() * 50.0f * g_Config.m_ClNTasSpeed / 100.0f;
	int Steps = 0;
	while(m_Accum >= 1.0f && Steps < 4 && !m_Paused && !m_SimDead)
	{
		m_Accum -= 1.0f;
		StepLive();
		++Steps;
	}
	if(m_Accum > 1.0f) m_Accum = 1.0f;
}

void CNTas::DrawSimWeapons()
{
	// Lines only: projectiles with a short trail, lasers, and the aim direction of the planned tee.
	const int Tick = m_pSim->GameTick(), TickSpeed = m_pSim->GameTickSpeed();
	for(CEntity *pEnt = m_pSim->FindFirst(CGameWorld::ENTTYPE_PROJECTILE); pEnt; pEnt = pEnt->TypeNext())
	{
		CProjectile *pProj = static_cast<CProjectile *>(pEnt);
		const int Type = pProj->GetData().m_Type;
		if(Type == WEAPON_GRENADE) Graphics()->SetColor(0.3f, 1.0f, 0.3f, 0.95f);
		else if(Type == WEAPON_SHOTGUN) Graphics()->SetColor(1.0f, 0.6f, 0.2f, 0.95f);
		else Graphics()->SetColor(1.0f, 1.0f, 0.3f, 0.95f);
		const float Pt = (float)(Tick - pProj->GetStartTick()) / (float)TickSpeed;
		const vec2 Pos = pProj->GetPos(Pt), Old = pProj->GetPos(std::max(0.0f, Pt - 0.06f));
		const IGraphics::CLineItem aLines[3] = {
			IGraphics::CLineItem(Old.x, Old.y, Pos.x, Pos.y),
			IGraphics::CLineItem(Pos.x - 4.0f, Pos.y, Pos.x + 4.0f, Pos.y),
			IGraphics::CLineItem(Pos.x, Pos.y - 4.0f, Pos.x, Pos.y + 4.0f)};
		Graphics()->LinesDraw(aLines, 3);
	}
	Graphics()->SetColor(0.4f, 0.9f, 1.0f, 0.95f);
	for(CEntity *pEnt = m_pSim->FindFirst(CGameWorld::ENTTYPE_LASER); pEnt; pEnt = pEnt->TypeNext())
	{
		CLaser *pLaser = static_cast<CLaser *>(pEnt);
		const IGraphics::CLineItem Line(pLaser->GetFrom().x, pLaser->GetFrom().y, pLaser->GetPos().x, pLaser->GetPos().y);
		Graphics()->LinesDraw(&Line, 1);
	}
	if(const CCharacter *pChar = m_pSim->GetCharacterById(m_aActors[ActiveRole()].m_LocalId))
	{
		if(length(m_aActors[ActiveRole()].m_Aim) > 0.001f)
		{
			const vec2 Dir = normalize(m_aActors[ActiveRole()].m_Aim), From = mix(m_aActors[ActiveRole()].m_SimPrev, m_aActors[ActiveRole()].m_SimCur, 1.0f);
			Graphics()->SetColor(1.0f, 1.0f, 1.0f, 0.35f);
			const IGraphics::CLineItem Line(From.x, From.y, From.x + Dir.x * 90.0f, From.y + Dir.y * 90.0f);
			Graphics()->LinesDraw(&Line, 1);
		}
		(void)pChar;
	}
}

void CNTas::DrawPlanning()
{
	if(!m_Planning || !m_pSim || Client()->State() != IClient::STATE_ONLINE) return;
	const CScreenRect Saved = Graphics()->GetScreen();
	const auto &Camera = GameClient()->m_Camera;
	Graphics()->MapScreen(Graphics()->MapScreenToWorld(Camera.m_Center.x, Camera.m_Center.y,
		100.0f, 100.0f, 100.0f, 0.0f, 0.0f, Graphics()->ScreenAspect(), Camera.m_Zoom));
	Graphics()->TextureClear();
	Graphics()->LinesBegin();
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		Graphics()->SetColor(Role ? 0.35f : 1.0f, Role ? 0.9f : 0.85f, Role ? 1.0f : 0.25f, 0.8f);
		const auto &Positions = Track(Role).m_vPos;
		const size_t From = Positions.size() > 400 ? Positions.size() - 400 : 0;
		for(size_t i = From + 1; i < Positions.size(); ++i)
		{
			const IGraphics::CLineItem Line((float)Positions[i - 1].m_X, (float)Positions[i - 1].m_Y, (float)Positions[i].m_X, (float)Positions[i].m_Y);
			Graphics()->LinesDraw(&Line, 1);
		}
		if(const CCharacter *pChar = m_pSim->GetCharacterById(m_aActors[Role].m_LocalId))
		{
			const auto *pCore = pChar->Core();
			if(pCore->m_HookState == HOOK_FLYING || pCore->m_HookState == HOOK_GRABBED)
			{
				const IGraphics::CLineItem Hook(pCore->m_Pos.x, pCore->m_Pos.y, pCore->m_HookPos.x, pCore->m_HookPos.y);
				Graphics()->LinesDraw(&Hook, 1);
			}
		}
	}
	DrawSimWeapons();
	Graphics()->LinesEnd();
	Graphics()->SetColor(1.0f, 1.0f, 1.0f, 1.0f);
	for(int Role = 0; Role < ActorCount(); ++Role)
	{
		const auto &A = m_aActors[Role];
		if(!m_pSim->GetCharacterById(A.m_LocalId)) continue;
		const float t = m_Paused ? 1.0f : std::clamp(m_Accum, 0.0f, 1.0f);
		const vec2 Pos = mix(A.m_SimPrev, A.m_SimCur, t);
		CTeeRenderInfo Info = GameClient()->m_aClients[A.m_LocalId].m_RenderInfo;
		vec2 Dir = Role == ActiveRole() ? GameClient()->m_Controls.m_aMousePos[Connection(Role)] : A.m_Aim;
		if(length(Dir) > 0.001f) Dir = normalize(Dir);
		RenderTools()->RenderTee(CAnimState::GetIdle(), &Info, EMOTE_NORMAL, Dir, Pos, Role == ActiveRole() ? 0.8f : 0.55f);
	}
	Graphics()->MapScreen(Saved);
}

void CNTas::DrawHud()
{
	const int64_t Now = time_get();
	if(!m_Planning && m_aActors[ActiveRole()].m_Engine.Mode() == NTas::CEngine::EMode::Idle && Now > m_StatusUntil) return;
	if(GameClient()->m_Menus.IsActive()) return;
	char aText[260] = "";
	if(m_Planning)
	{
		bool Frozen = false;
		if(const CCharacter *pChar = m_pSim ? m_pSim->GetCharacterById(m_aActors[ActiveRole()].m_LocalId) : nullptr) Frozen = IsFrozenChar(pChar);
		str_format(aText, sizeof(aText), "TAS ПЛАН  тик %d (%.2f с)  %s  x%d%%%s%s", (int)m_Plan.m_vFrames.size(), m_Plan.m_vFrames.size() / 50.0f,
			m_Paused ? "ПАУЗА" : "ИДЁТ", g_Config.m_ClNTasSpeed, Frozen ? "  FREEZE" : "", m_SimDead ? "  ТИЙ УМЕР" : "");
	}
	else if(m_aActors[ActiveRole()].m_Engine.Mode() == NTas::CEngine::EMode::Playing)
		str_format(aText, sizeof(aText), "TAS ПРОИГРЫВАНИЕ  кадр %d/%d  откл. %.0f px%s", m_LastIdx, (int)m_Plan.m_vFrames.size(), m_aActors[ActiveRole()].m_Dev, (m_aActors[0].m_FirstDesync >= 0 || (m_WithDummy && m_aActors[1].m_FirstDesync >= 0)) ? "  РАССИНХРОН" : "");
	if(m_WithDummy)
	{
		char aPair[100];
		str_format(aPair, sizeof(aPair), "  Тий %d/2  откл. %.1f/%.1f", ActiveRole() + 1, m_aActors[0].m_Dev, m_aActors[1].m_Dev);
		str_append(aText, aPair);
	}
	const CScreenRect SavedScreen = Graphics()->GetScreen();
	const auto SavedColor = TextRender()->GetTextColor();
	Graphics()->MapScreenToSize(300.0f * Graphics()->ScreenAspect(), 300.0f);
	const float CenterX = 150.0f * Graphics()->ScreenAspect();
	char aWeapon[200] = "";
	if(m_Planning && m_pSim)
	{
		if(const CCharacter *pChar = m_pSim->GetCharacterById(m_aActors[ActiveRole()].m_LocalId))
		{
			const int Active = pChar->Core()->m_ActiveWeapon;
			char aGot[40] = "";
			for(int w = 0; w < NUM_WEAPONS; ++w)
			{
				if(!pChar->Core()->m_aWeapons[w].m_Got) continue;
				char aOne[8];
				str_format(aOne, sizeof(aOne), w == Active ? " [%d]" : " %d", w + 1);
				str_append(aGot, aOne);
			}
			const int Ammo = Active >= 0 && Active < NUM_WEAPONS ? pChar->Core()->m_aWeapons[Active].m_Ammo : 0;
			const auto &Frames = Track(ActiveRole()).m_vFrames;
			const int Shots = Frames.empty() ? 0 : (Frames.back().m_Fire + 1) / 2;
			str_format(aWeapon, sizeof(aWeapon), "Оружие: %s  патронов %d  перезарядка %d  выстрелов в плане %d  Есть:%s",
				Active >= 0 && Active < NUM_WEAPONS ? gs_apWeaponNames[Active] : "?", Ammo, pChar->GetReloadTimer(), Shots, aGot);
		}
	}
	TextRender()->TextColor(1.0f, 0.85f, 0.35f, 1.0f);
	float Y = 24.0f;
	if(aText[0])
	{
		const float W = TextRender()->TextWidth(7.0f, aText, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 7.0f, aText);
		Y += 9.0f;
	}
	if(aWeapon[0])
	{
		const float W = TextRender()->TextWidth(6.0f, aWeapon, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 6.0f, aWeapon);
		Y += 8.0f;
	}
	if(m_Planning && g_Config.m_ClLaserAutoUnfreeze)
	{
		char aLaser[180];
		str_format(aLaser, sizeof(aLaser), "TAS авто-анфриз: %s", NLaserStatusText(m_aActors[ActiveRole()].m_PlanLaserStatus));
		const float W = TextRender()->TextWidth(6.0f, aLaser, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 6.0f, aLaser);
		Y += 8.0f;
	}
	if(m_aStatus[0] && Now <= m_StatusUntil)
	{
		const float W = TextRender()->TextWidth(6.0f, m_aStatus, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 6.0f, m_aStatus);
	}
	TextRender()->TextColor(SavedColor);
	Graphics()->MapScreen(SavedScreen);
}

void CNTas::OnRender()
{
	if(Client()->State() != IClient::STATE_ONLINE) return;
	if(Overriding() && !m_aActors[0].m_Engine.Closing()) CheckActors();
	UpdateStepRepeat();
	UpdatePlanning();
	// A disconnected transport cannot send the final release packet. Reset
	// only that transport; the connected tee still exits with counter shifting.
	if(!Client()->DummyConnected())
		for(int Role = 0; Role < 2; ++Role)
			if(Connection(Role) == 1) { m_aActors[Role].m_Engine.HardReset(); m_aActors[Role].m_HaveRaw = false; }
	bool Stopped = false;
	for(auto &A : m_aActors)
	{
		const auto End = A.m_Engine.TakeEnd();
		if(End == NTas::CEngine::EEnd::PlayDone) m_PlayDonePending = true;
		else if(End == NTas::CEngine::EEnd::Stopped) Stopped = true;
	}
	if(Stopped) m_PlayDonePending = false;
	if(m_PlayDonePending && !Playing() && !Overriding())
	{
		char aBuf[220];
		const auto &A = m_aActors[0];
		const auto &D = m_aActors[1];
		if(m_WithDummy)
			str_format(aBuf, sizeof(aBuf), "TAS окончен. Тий 1: макс. %.1f px, рассинхрон %d; тий 2: %.1f px, рассинхрон %d. Дослано пакетов: %d.", A.m_MaxDev, A.m_FirstDesync, D.m_MaxDev, D.m_FirstDesync, m_FilledGaps);
		else
			str_format(aBuf, sizeof(aBuf), "TAS окончен. Макс. %.1f px, кадр рассинхрона %d (-1 = нет). Дослано пакетов: %d.", A.m_MaxDev, A.m_FirstDesync, m_FilledGaps);
		SetStatus(aBuf, 12);
		Log("play_done", aBuf);
		m_PlayDonePending = false;
	}
	DrawPlanning();
	DrawHud();
}

