// Experimental DDNet 20.1 self-unfreeze assist. Not an authoritative server simulation.
#include "laser_unfreeze.h"
#include "laser_unfreeze_beta.h"
#include <numeric>
#include <base/math.h>
#include <base/time.h>
#include <game/client/prediction/entities/character.h>
#include <game/client/prediction/entities/laser.h>
#include <game/client/prediction/gameworld.h>
#include <game/collision.h>
#include <game/mapitems.h>
#include <algorithm>
#include <cmath>
#include <vector>

namespace
{
// time_get() is cached by the main client loop. It does NOT advance inside
// a search and therefore cannot enforce a CPU deadline. Use the uncached
// steady clock for every search/reconstruction/verification budget check.
struct SFutureFrame
{
	vec2 m_Pos;
	bool m_Frozen;
};
struct SCandidate
{
	ivec2 m_Target;
	float m_Score;
};
void SetupCopy(CGameWorld &World, CGameWorld &Source)
{
	// Never replace Source's prediction child or borrow entity parent pointers.
	World.CopyWorld(&Source, false);
	World.m_LocalClientId = Source.m_LocalClientId;
	World.m_WorldConfig.m_PredictFreeze = 1;
	World.m_WorldConfig.m_PredictTiles = true;
	World.m_WorldConfig.m_PredictDDRace = true;
	// Existing projectiles still tick, but don't create unrelated future shots.
	World.m_WorldConfig.m_PredictWeapons = false;
	World.m_WorldConfig.m_PredictEvents = false;
	World.m_PredictedEvents.clear();
	for(CCharacter *pChar = (CCharacter *)World.FindFirst(CGameWorld::ENTTYPE_CHARACTER); pChar; pChar = (CCharacter *)pChar->TypeNext())
		pChar->m_CanMoveInFreeze = false;
}
CNetObj_PlayerInput QuietInput(CNetObj_PlayerInput Input)
{
	if(Input.m_Fire & 1)
		Input.m_Fire = (Input.m_Fire + 1) & INPUT_STATE_MASK;
	Input.m_WantedWeapon = 0;
	Input.m_NextWeapon = 0;
	Input.m_PrevWeapon = 0;
	return Input;
}
bool UsableFrozen(CCharacter *pChar)
{
	return pChar && pChar->m_FreezeTime > 0 &&
		!pChar->Core()->m_DeepFrozen && !pChar->Core()->m_LiveFrozen;
}
// Geometry is only a fast candidate filter. The native CLaser verifies the hit.
bool GeometryCandidate(CCollision *pCollision, vec2 Origin, vec2 Direction,
	float Energy, float BounceCost, int BounceNum, int DelayTicks,
	float Radius, const std::vector<SFutureFrame> &vFrames, float &Score)
{
	vec2 Pos = Origin;
	int Step = 0;
	int Bounces = 0;
	bool ZeroLast = false;
	while(Energy >= 0.0f && Step < (int)vFrames.size())
	{
		vec2 CollisionPos;
		vec2 To = Pos + Direction * Energy;
		const int Res = pCollision->IntersectLineTeleWeapon(Pos, To, &CollisionPos, &To);
		if(Bounces > 0 && vFrames[Step].m_Frozen && distance(Pos, To) > 0.001f)
		{
			const vec2 Delta = To - Pos;
			const float Along = std::clamp(dot(vFrames[Step].m_Pos - Pos, Delta) / dot(Delta, Delta), 0.0f, 1.0f);
			const float Miss = distance(Pos + Delta * Along, vFrames[Step].m_Pos);
			if(Miss < Radius)
			{
				Score = Miss + Step * 0.1f;
				return true;
			}
		}
		if(!Res)
			return false;
		const vec2 From = Pos;
		Pos = To;
		vec2 TempDir = Direction * 4.0f;
		int Tile = 0;
		if(Res == -1)
		{
			Tile = pCollision->GetTile(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y));
			pCollision->SetCollisionAt(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y), TILE_SOLID);
		}
		pCollision->MovePoint(&Pos, &TempDir, 1.0f, nullptr);
		if(Res == -1)
			pCollision->SetCollisionAt(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y), Tile);
		if(length(TempDir) < 0.001f)
			return false;
		Direction = normalize(TempDir);
		const float Travel = distance(From, Pos);
		if(Travel == 0.0f && ZeroLast)
			return false;
		Energy -= Travel + BounceCost;
		ZeroLast = Travel == 0.0f;
		if(++Bounces > BounceNum)
			return false;
		Step += DelayTicks;
	}
	return false;
}
ivec2 NAimFromAngle(float Angle)
{
	return ivec2(round_to_int(std::cos(Angle) * 1000.0f), round_to_int(std::sin(Angle) * 1000.0f));
}
// Local angle refinement: halve the angle step and keep any move that lowers the
// geometric miss. Only a candidate filter; native verification still decides.
float RefineGeometryAngle(CCollision *pCollision, vec2 Origin, float &Angle, float Score,
	float Energy, float BounceCost, int BounceNum, int DelayTicks, float Radius,
	const std::vector<SFutureFrame> &vFrames, int64_t Deadline)
{
	float Step = 0.02f;
	for(int Iteration = 0; Iteration < 10 && time_get_impl() < Deadline; ++Iteration, Step *= 0.5f)
		for(int Move = 0; Move < 4; ++Move)
		{
			bool Improved = false;
			for(int Sign = -1; Sign <= 1 && !Improved; Sign += 2)
			{
				const ivec2 TryAim = NAimFromAngle(Angle + Sign * Step);
				float TryScore;
				if(GeometryCandidate(pCollision, Origin, normalize(vec2(TryAim.x, TryAim.y)), Energy, BounceCost,
					   BounceNum, DelayTicks, Radius, vFrames, TryScore) &&
					TryScore < Score)
				{
					Score = TryScore;
					Angle += Sign * Step;
					Improved = true;
				}
			}
			if(!Improved)
				break;
		}
	return Score;
}
bool Verify(CGameWorld &Source, int ClientId, const CNetObj_PlayerInput &Input,
	ivec2 Aim, float Reach, int Horizon, int64_t Deadline, int ShotDelay, int AimTicks, float MaxMiss, int &ReturnTick, SLaserUnfreezeAim &Details, ENLaserStatus &Reason, int RequiredClearTicks = 3, bool StopOnEarlyHit = false, int HookReleaseLagTicks = 0, const CNetObj_PlayerInput *pFirstPhysicsInput = nullptr)
{
	int OwnerUnfreezeTick = -1, OwnerHitTick = -1;
	auto Fail = [&](ENLaserStatus Status) { Reason = Status; return false; };
	float HitDistance = 1000.0f;
	CGameWorld World;
	SetupCopy(World, Source);
	CNetObj_PlayerInput Future = QuietInput(Input);
	// Restore physical mouse aim after the recorded shot/release packets.
	CCharacter *pChar = World.GetCharacterById(ClientId);
	if(!pChar)
		return Fail(ENLaserStatus::HistoryUnavailable);
	pChar->SetInput(&Future);
	for(int Tick = 0; Tick < ShotDelay; ++Tick)
	{
		if(time_get_impl() >= Deadline)
			return Fail(ENLaserStatus::BudgetExpired);
		++World.m_GameTick;
		pChar->OnPredictedInput(&Future);
		World.Tick();
		pChar = World.GetCharacterById(ClientId);
		if(!pChar)
			return Fail(ENLaserStatus::HistoryUnavailable);
	}
	// The delayed shot must still be physically possible, not shot from freeze.
	if(pChar->m_FreezeTime != 0 || pChar->GetReloadTimer() != 0 ||
		pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen)
		return Fail(ENLaserStatus::AlreadyFrozen);
	new CLaser(&World, pChar->GetPos(), normalize(vec2(Aim.x, Aim.y)), Reach,
		ClientId, WEAPON_LASER, &OwnerUnfreezeTick, &HitDistance, &OwnerHitTick);
	const int Start = World.GameTick();
	std::vector<SNPredictionPoint> Forecast;
	Forecast.reserve(Horizon+4);
	Forecast.push_back({pChar->GetPos(), false, Start});
	int ClearTicks = 0;
	for(int Step = 1; Step <= Horizon + 3; ++Step)
	{
		if(time_get_impl() >= Deadline)
			return Fail(ENLaserStatus::BudgetExpired);
		pChar = World.GetCharacterById(ClientId);
		if(!pChar)
			return Fail(ENLaserStatus::HistoryUnavailable);
		World.m_GameTick = Start + Step;
		CNetObj_PlayerInput StepInput = NLaserVerificationStepInput(Future, Aim, Step, std::max(1, AimTicks - ShotDelay), pFirstPhysicsInput);
		// Sensitivity branch only: the old attached hook persists one more tick.
		// Do not mutate the source world or actually delay the user's release.
		if(HookReleaseLagTicks > 0 && !Future.m_Hook && Step <= HookReleaseLagTicks) StepInput.m_Hook = 1;
		pChar->OnPredictedInput(&StepInput);
		World.Tick();
		pChar = World.GetCharacterById(ClientId);
		if(!pChar) return Fail(ENLaserStatus::HistoryUnavailable);
		Forecast.push_back({pChar->GetPos(), pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen, World.GameTick()});
		if(StopOnEarlyHit && OwnerHitTick >= 0 && OwnerUnfreezeTick < 0)
			return Fail(ENLaserStatus::NativeEarlyHit);
		if(OwnerUnfreezeTick >= 0)
		{
			pChar = World.GetCharacterById(ClientId);
			if(HitDistance > MaxMiss) return Fail(ENLaserStatus::NativeOffCenter);
			if(!pChar) return Fail(ENLaserStatus::HistoryUnavailable);
			if(pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen)
				return Fail(ENLaserStatus::NativeRefreeze);
			// Reject hits which only clear freeze momentarily before immediate refreeze.
			if(++ClearTicks >= RequiredClearTicks)
			{
				ReturnTick = OwnerUnfreezeTick;
				Details.m_LaunchTick = Start;
				Details.m_Forecast = std::move(Forecast);
				return true;
			}
		}
	}
	return Fail(OwnerUnfreezeTick >= 0 ? ENLaserStatus::NativeShortWindow :
		OwnerHitTick >= 0 ? ENLaserStatus::NativeEarlyHit : ENLaserStatus::NativeNoHit);
}
}

bool FindLaserUnfreezeAim(CGameWorld &Source, int ClientId,
	const CNetObj_PlayerInput &Input, int Samples, int BudgetMs, SLaserUnfreezeAim &Result,
	bool Strict, ivec2 CachedAim, ENLaserStatus *pStatus, float HitMargin, int *pFirstFrozenStep, int AimTicks, CGameWorld *pEarlySource)
{
	auto Fail = [&](ENLaserStatus Status) { if(pStatus) *pStatus = Status; return false; };
	if(pFirstFrozenStep) *pFirstFrozenStep = -1;
	CCharacter *pOwner = Source.GetCharacterById(ClientId);
	if(!pOwner || !Source.Collision()) return Fail(ENLaserStatus::HistoryUnavailable);
	if(pOwner->IsSuper() || pOwner->Core()->m_Invincible) return Fail(ENLaserStatus::SuperMode);
	if(!Source.m_WorldConfig.m_IsDDRace || Source.m_WorldConfig.m_OldLaser)
		return Fail(ENLaserStatus::UnsupportedMap);
	if(pOwner->GetActiveWeapon() != WEAPON_LASER || !pOwner->GetWeaponGot(WEAPON_LASER) || pOwner->GetWeaponAmmo(WEAPON_LASER) == 0)
		return Fail(ENLaserStatus::SelectLaser);
	if(pOwner->m_FreezeTime != 0 || pOwner->Core()->m_DeepFrozen || pOwner->Core()->m_LiveFrozen)
		return Fail(ENLaserStatus::AlreadyFrozen);
	if(pOwner->GetReloadTimer() != 0) return Fail(ENLaserStatus::Reloading);
	if(Input.m_Fire & 1) return Fail(ENLaserStatus::ManualFire);
	if(Input.m_WantedWeapon && Input.m_WantedWeapon != WEAPON_LASER + 1)
		return Fail(ENLaserStatus::WeaponSwitch);
	// Rifle and a NEW hook share one protocol aim. Allow the user's hook to
	// launch first; a flying/grabbed/retracted held hook never blocks the search.
	if(Input.m_Hook && pOwner->Core()->m_HookState == HOOK_IDLE)
		return Fail(ENLaserStatus::HookStarting);
	const int64_t Deadline = time_get_impl() + time_freq() * std::clamp(BudgetMs, 1, 20) / 1000;
	const int Zone = Source.m_WorldConfig.m_UseTuneZones ? Source.Collision()->IsTune(Source.Collision()->GetMapIndex(pOwner->GetPos())) : 0;
	const CTuningParams *pTune = Source.GetTuning(Zone);
	const float Reach = Source.GetTuning(pOwner->GetOverriddenTuneZone())->m_LaserReach;
	const int Bounces = std::clamp((int)(float)pTune->m_LaserBounceNum, 0, 8);
	const float DelayMs = pTune->m_LaserBounceDelay;
	if(Bounces == 0 || Reach <= 0.0f || DelayMs < 0.0f || DelayMs > 2000.0f)
		return Fail(ENLaserStatus::UnsupportedTuning);
	const int DelayTicks = (int)std::floor((float)SERVER_TICK_SPEED * DelayMs / 1000.0f) + 1;
	const int Horizon = std::min(96, DelayTicks * Bounces);
	const float MaxMiss = HitMargin > 0.0f ? std::clamp(HitMargin, 6.0f, Strict ? 12.0f : 20.0f) : (Strict ? 12.0f : 20.0f);
	ENLaserStatus LastReason = ENLaserStatus::NativeNoHit;
	auto Validate = [&](ivec2 Aim, int &ReturnTick) {
		// Verify the actual launch. A second hypothetical shot one tick later
		// was rejecting the last usable pre-freeze tick even on a local server.
		if(!Verify(Source, ClientId, Input, Aim, Reach, Horizon, Deadline, 0, AimTicks, MaxMiss, ReturnTick, Result, LastReason))
			return false;
		// Input can also be executed one tick EARLIER. Validate against the
		// saved historical world, not a translated tee or a fabricated offset.
		// TAS passes no early source and retains its recorded one-frame timing.
		if(pEarlySource && pEarlySource->GameTick() + 1 == Source.GameTick())
		{
			CCharacter *pEarlyOwner = pEarlySource->GetCharacterById(ClientId);
			if(!pEarlyOwner || pEarlyOwner->GetActiveWeapon() != WEAPON_LASER ||
				!pEarlyOwner->GetWeaponGot(WEAPON_LASER) || pEarlyOwner->GetWeaponAmmo(WEAPON_LASER) == 0 ||
				(Input.m_Hook && pEarlyOwner->Core()->m_HookState == HOOK_IDLE))
			{
				LastReason = ENLaserStatus::NativeEarlyTick;
				return false;
			}
			int EarlyReturn = 0;
			SLaserUnfreezeAim Early;
			ENLaserStatus EarlyReason = ENLaserStatus::NativeNoHit;
			const float EarlyReach = pEarlySource->GetTuning(pEarlyOwner->GetOverriddenTuneZone())->m_LaserReach;
			const CNetObj_PlayerInput PreviousPhysicsInput = pOwner->GetPredictionInput();
			if(!Verify(*pEarlySource, ClientId, Input, Aim, EarlyReach, Horizon, Deadline, 0,
				AimTicks, MaxMiss, EarlyReturn, Early, EarlyReason, 3, false, 0, &PreviousPhysicsInput))
			{
				LastReason = EarlyReason == ENLaserStatus::BudgetExpired ? EarlyReason : ENLaserStatus::NativeEarlyTick;
				return false;
			}
		}
		// The server may execute the same input one tick later (about 30% of shots
		// in a real log). Require the shot to also work with a 1 tick later launch.
		int LateReturn = 0; SLaserUnfreezeAim Late; ENLaserStatus LateReason = ENLaserStatus::NativeNoHit;
		if(Verify(Source, ClientId, Input, Aim, Reach, Horizon, Deadline, 1, AimTicks, MaxMiss, LateReturn, Late, LateReason))
			return true;
		// Last chance: next tick the character is already frozen, so waiting is pointless.
		if(LateReason == ENLaserStatus::AlreadyFrozen)
			return true;
		LastReason = LateReason == ENLaserStatus::BudgetExpired ? LateReason : ENLaserStatus::NativeLateTick;
		return false;
	};
	// A cached angle is never trusted blindly: it must pass fresh native checks.
	if(CachedAim.x != 0 || CachedAim.y != 0)
	{
		int ReturnTick;
		if(Validate(CachedAim, ReturnTick))
		{
			Result.m_Target = CachedAim; Result.m_ReturnTick = ReturnTick;
			if(pStatus) *pStatus = ENLaserStatus::ShotQueued;
			return true;
		}
	}
	std::vector<SFutureFrame> vFrames(Horizon + 1);
	bool FrozenSoon = false;
	{
		CGameWorld FutureWorld;
		SetupCopy(FutureWorld, Source);
		const CNetObj_PlayerInput FutureInput = QuietInput(Input);
		if(CCharacter *pFuture = FutureWorld.GetCharacterById(ClientId))
			pFuture->SetInput(&FutureInput);
		const int Start = FutureWorld.GameTick();
		vFrames[0] = {pOwner->GetPos(), false};
		for(int Step = 1; Step <= Horizon; ++Step)
		{
			if(time_get_impl() >= Deadline)
				return Fail(ENLaserStatus::BudgetExpired);
			CCharacter *pFuture = FutureWorld.GetCharacterById(ClientId);
			if(!pFuture)
				return Fail(ENLaserStatus::HistoryUnavailable);
			// Laser entities tick before characters: use the PRE-tick position.
			vFrames[Step] = {pFuture->GetPos(), UsableFrozen(pFuture)};
			if(vFrames[Step].m_Frozen && !FrozenSoon && pFirstFrozenStep) *pFirstFrozenStep = Step;
			FrozenSoon |= vFrames[Step].m_Frozen;
			FutureWorld.m_GameTick = Start + Step;
			pFuture->OnPredictedInput(&FutureInput);
			FutureWorld.Tick();
		}
	}
	if(!FrozenSoon)
		return Fail(ENLaserStatus::NoFreezeAhead);
	Samples = std::clamp(Samples, 90, 1440);
	const float BaseAngle = std::atan2((float)Input.m_TargetY, (float)Input.m_TargetX);
	std::vector<SCandidate> vCandidates;
	// Reserve half of the remaining budget for verification, even on big maps.
	// The coarse sweep gets 70% of the geometry half, local refinement the rest.
	const int64_t GeometryStart = time_get_impl();
	const int64_t GeometryHalf = (Deadline - GeometryStart) / 2;
	const int64_t CoarseDeadline = GeometryStart + GeometryHalf * 7 / 10;
	const int64_t GeometryDeadline = GeometryStart + GeometryHalf;
	// 0.8: a wider net than the real miss limit. A coarse (or time-truncated) angle
	// sweep can step over a narrow solution; local refinement then narrows it and the
	// native verification still enforces the true MaxMiss on every candidate.
	const float BaseRadius = std::min(pOwner->GetProximityRadius(), MaxMiss);
	const float NetRadius = std::min(BaseRadius * 2.0f, 48.0f);
	for(int Sample = 0; Sample < Samples; ++Sample)
	{
		if(time_get_impl() >= CoarseDeadline)
			break;
		// Low-discrepancy order covers ALL directions early instead of stopping
		// after only a contiguous sector when the budget is small.
		unsigned Bits = (unsigned)Sample + 1;
		float Fraction = 0.0f, Weight = 0.5f;
		while(Bits) { Fraction += (Bits & 1u) * Weight; Bits >>= 1; Weight *= 0.5f; }
		const float Angle = BaseAngle + 2.0f * pi * Fraction;
		const ivec2 Aim = NAimFromAngle(Angle);
		const vec2 Dir = normalize(vec2(Aim.x, Aim.y));
		float Score;
		if(GeometryCandidate(Source.Collision(), pOwner->GetPos(), Dir, Reach, pTune->m_LaserBounceCost,
			Bounces, DelayTicks, NetRadius, vFrames, Score))
			vCandidates.push_back({Aim, Score});
	}
	std::sort(vCandidates.begin(), vCandidates.end(), [](const SCandidate &A, const SCandidate &B) { return A.m_Score < B.m_Score; });
	// Refine the best geometric candidates: shrink the angle step and keep any move
	// that lowers the geometric miss. Cheap compared to one native verification.
	for(size_t Index = 0; Index < std::min<size_t>(vCandidates.size(), 8); ++Index)
	{
		float Angle = std::atan2((float)vCandidates[Index].m_Target.y, (float)vCandidates[Index].m_Target.x);
		const float Best = RefineGeometryAngle(Source.Collision(), pOwner->GetPos(), Angle, vCandidates[Index].m_Score,
			Reach, pTune->m_LaserBounceCost, Bounces, DelayTicks, NetRadius, vFrames, GeometryDeadline);
		vCandidates[Index].m_Target = NAimFromAngle(Angle);
		vCandidates[Index].m_Score = Best;
	}
	std::sort(vCandidates.begin(), vCandidates.end(), [](const SCandidate &A, const SCandidate &B) { return A.m_Score < B.m_Score; });
	vCandidates.erase(std::unique(vCandidates.begin(), vCandidates.end(), [](const SCandidate &A, const SCandidate &B) { return A.m_Target == B.m_Target; }), vCandidates.end());
	for(size_t Index = 0; Index < std::min<size_t>(vCandidates.size(), 16); ++Index)
	{
		if(time_get_impl() >= Deadline)
			return Fail(ENLaserStatus::BudgetExpired);
		int ReturnTick;
		if(Validate(vCandidates[Index].m_Target, ReturnTick))
		{
			Result.m_Target = vCandidates[Index].m_Target;
			Result.m_ReturnTick = ReturnTick;
			if(pStatus) *pStatus = ENLaserStatus::ShotQueued;
			return true;
		}
	}
	if(time_get_impl() >= Deadline) return Fail(ENLaserStatus::BudgetExpired);
	return Fail(vCandidates.empty() ? ENLaserStatus::NoAngle : LastReason);
}


bool BuildNPredictionPath(CGameWorld &Source, int ClientId, const CNetObj_PlayerInput &Input,
	int Ticks, int BudgetMs, std::vector<SNPredictionPoint> &Path)
{
	Path.clear();
	if(!Source.Collision() || !Source.GetCharacterById(ClientId))
		return false;
	const int64_t Deadline = time_get_impl() + time_freq() * std::clamp(BudgetMs, 1, 6) / 1000;
	CGameWorld Future;
	SetupCopy(Future, Source);
	CNetObj_PlayerInput Held = QuietInput(Input);
	CCharacter *pChar = Future.GetCharacterById(ClientId);
	pChar->SetInput(&Held);
	Ticks = std::clamp(Ticks, 8, 64);
	Path.reserve(Ticks + 1);
	Path.push_back({pChar->GetPos(), pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen});
	for(int Step = 0; Step < Ticks && time_get_impl() < Deadline; ++Step)
	{
		pChar = Future.GetCharacterById(ClientId);
		if(!pChar)
			break;
		++Future.m_GameTick;
		pChar->OnPredictedInput(&Held);
		Future.Tick();
		pChar = Future.GetCharacterById(ClientId);
		if(!pChar)
			break;
		Path.push_back({pChar->GetPos(), pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen});
	}
	return Path.size() > 1;
}

const char *NLaserStatusText(ENLaserStatus Status)
{
	static const char *apTexts[] = {
		"Отключено",
		"Отправка выстрела / отпускание огня",
		"Пауза: меню, чат или наблюдение",
		"Нужны cl_predict 1 и cl_predict_freeze 1",
		"Отключите специальные режимы dummy",
		"Ручной огонь имеет приоритет",
		"Нужен выбранный лазер с патронами",
		"Смена оружия",
		"Ожидание следующего тика поиска",
		"Недоступна история предикта",
		"Исчерпан CPU-бюджет поиска",
		"Лазер перезаряжается",
		"Уже заморожен: выстрел невозможен",
		"Не поддерживается режим карты / old laser",
		"Нет допустимых отражений лазера",
		"Нет freeze на прогнозируемом пути",
		"Не найден угол отражения",
		"Кандидаты не прошли проверку попадания",
		"Выстрел подготовлен",
		"Запуск нового хука: жду его вылета",
		"Super / invincible: проверка freeze недостоверна",
		"Жду серверное подтверждение прошлого выстрела",
		"Последний кандидат: лазер не разморозил владельца",
		"Последний кандидат: попадание без допустимого freeze",
		"Последний кандидат: попадание слишком далеко от центра",
		"Последний кандидат: повторный freeze после попадания",
		"Последний кандидат: недостаточно тиков без freeze",
		"Кандидат ломается при задержке сервера на 1 тик",
		"Кандидат ломается при запуске на 1 тик раньше",
		"Beta: выхода из freeze нет в прогнозе 64 тиков",
		"Beta: найден угол, жду расчётного тика выстрела",
		"Beta 2.4: попадание и разморозка проверены",
		"Beta: после анхука нет устойчивого выстрела",
	};
	const int Index = (int)Status;
	return Index >= 0 && Index < (int)(sizeof(apTexts) / sizeof(apTexts[0])) ? apTexts[Index] : "Неизвестный статус";
}

// 2.4 beta: real CPU deadlines and historical-input early launch checks after unhook.
// Beta retains its two-clear-tick rule and the 2.1 late/hook-lag checks.
bool FindTutorialUnfreezeAim(CGameWorld &Source, int ClientId,
 const CNetObj_PlayerInput &Input, int AngleStep, int MaxBounces, int BudgetMs,
 SLaserUnfreezeAim &Result, ENLaserStatus *pStatus, int *pFirstFrozenStep, bool RecentHookRelease, CGameWorld *pEarlySource)
{
 auto Fail = [&](ENLaserStatus Status) { if(pStatus) *pStatus = Status; return false; };
 if(pFirstFrozenStep) *pFirstFrozenStep = -1;
 CCharacter *pOwner = Source.GetCharacterById(ClientId);
 if(!pOwner || !Source.Collision()) return Fail(ENLaserStatus::HistoryUnavailable);
 if(pOwner->IsSuper() || pOwner->Core()->m_Invincible) return Fail(ENLaserStatus::SuperMode);
 if(!Source.m_WorldConfig.m_IsDDRace || Source.m_WorldConfig.m_OldLaser) return Fail(ENLaserStatus::UnsupportedMap);
 if(pOwner->m_FreezeTime || pOwner->Core()->m_DeepFrozen || pOwner->Core()->m_LiveFrozen) return Fail(ENLaserStatus::AlreadyFrozen);
 if(Input.m_Fire & 1) return Fail(ENLaserStatus::ManualFire);
 if(Input.m_Hook && pOwner->Core()->m_HookState == HOOK_IDLE) return Fail(ENLaserStatus::HookStarting);
 const bool OldHookAttached = pOwner->Core()->m_HookState == HOOK_GRABBED;
 const bool HookSensitive = !Input.m_Hook && (RecentHookRelease || OldHookAttached);
 const float MaxMiss = HookSensitive ? 16.0f : 20.0f;
 const int64_t Started = time_get_impl();
 const int64_t Deadline = Started + time_freq() * std::clamp(BudgetMs, 1, 20) / 1000;
 // Reserve time for native checks; geometry alone is not permission to shoot.
 const int64_t SearchDeadline = Started + (Deadline - Started) * (HookSensitive ? 9 : 12) / 20;
 struct SFrame { vec2 m_Pos; bool m_Frozen; int m_Zone; };
 std::vector<SFrame> Frames;
 Frames.reserve(65);
 Frames.push_back({pOwner->GetPos(), false, pOwner->GetOverriddenTuneZone()});
 int EnterFreeze = -1, TimerExit = -1, TileExit = -1;
 CGameWorld Future;
 SetupCopy(Future, Source);
 const CNetObj_PlayerInput Held = QuietInput(Input);
 if(CCharacter *pChar = Future.GetCharacterById(ClientId)) pChar->SetInput(&Held);
 for(int Tick = 1; Tick <= 64; ++Tick)
 {
  if(time_get_impl() >= Deadline) return Fail(ENLaserStatus::BudgetExpired);
  CCharacter *pChar = Future.GetCharacterById(ClientId);
  if(!pChar) return Fail(ENLaserStatus::HistoryUnavailable);
  ++Future.m_GameTick;
  pChar->OnPredictedInput(&Held);
  Future.Tick();
  pChar = Future.GetCharacterById(ClientId);
  if(!pChar) return Fail(ENLaserStatus::HistoryUnavailable);
  const bool Frozen = pChar->m_FreezeTime > 0;
  Frames.push_back({pChar->GetPos(), Frozen, pChar->GetOverriddenTuneZone()});
  if(EnterFreeze < 0 && Frozen) EnterFreeze = Tick;
  if(EnterFreeze >= 0 && Tick > EnterFreeze)
  {
   if(TimerExit < 0 && !Frozen) TimerExit = Tick;
   const int Index = Source.Collision()->GetPureMapIndex(pChar->GetPos());
   const bool InFreezeTile = Source.Collision()->GetTileIndex(Index) == TILE_FREEZE ||
    Source.Collision()->GetFrontTileIndex(Index) == TILE_FREEZE ||
    (Source.Collision()->GetSwitchType(Index) == TILE_FREEZE && Source.Collision()->GetSwitchNumber(Index) > 0 &&
     Source.Collision()->GetSwitchNumber(Index) < (int)Future.Switchers().size() &&
     Future.Switchers()[Source.Collision()->GetSwitchNumber(Index)].m_aStatus[pChar->Team()]);
   if(TileExit < 0 && !InFreezeTile) TileExit = Tick;
  }
 }
 if(pFirstFrozenStep) *pFirstFrozenStep = EnterFreeze;
 if(EnterFreeze < 0) return Fail(ENLaserStatus::NoFreezeAhead);
 // A normal freeze timer lasts longer than 64 ticks. For a thin freeze strip,
 // use its spatial exit if the natural thaw is outside the prediction horizon.
 const int ExitFreeze = TileExit >= 0 ? TileExit : TimerExit;
 if(ExitFreeze < 0) return Fail(ENLaserStatus::BetaNoExit);
 if(!pOwner->GetWeaponGot(WEAPON_LASER) || pOwner->GetWeaponAmmo(WEAPON_LASER) == 0 ||
  pOwner->GetActiveWeapon() != WEAPON_LASER) return Fail(ENLaserStatus::SelectLaser);
 if(pOwner->GetReloadTimer()) return Fail(ENLaserStatus::Reloading);
 if(Input.m_WantedWeapon && Input.m_WantedWeapon != WEAPON_LASER + 1) return Fail(ENLaserStatus::WeaponSwitch);
 const int Zone = Source.m_WorldConfig.m_UseTuneZones ? Source.Collision()->IsTune(Source.Collision()->GetMapIndex(pOwner->GetPos())) : 0;
 const CTuningParams *pTune = Source.GetTuning(Zone);
 const float Reach = Source.GetTuning(pOwner->GetOverriddenTuneZone())->m_LaserReach;
 const int BouncesLimit = std::min(std::clamp(MaxBounces, 1, 8), std::clamp((int)(float)pTune->m_LaserBounceNum, 0, 8));
 const float DelayMs = pTune->m_LaserBounceDelay;
 if(BouncesLimit < 1 || Reach <= 0 || DelayMs < 0 || DelayMs > 2000) return Fail(ENLaserStatus::UnsupportedTuning);
 const int DelayTicks = NBetaBounceTicks(DelayMs, SERVER_TICK_SPEED);
 // Laser ticks before the character: require the previous position to have
 // already left the freeze strip. Never target the tutorial's exit-2 window.
 const int TargetStart = std::max(EnterFreeze + 1, ExitFreeze + 1), TargetEnd = std::min(64, ExitFreeze + 6);
 float BestScore = -1e30f, BestMiss = 1e30f, BestAngle = 0;
 int BestFire = -1, BestTarget = -1;
 struct SShot { float m_Angle, m_Score, m_Miss; int m_Target; };
 std::vector<SShot> Ready;
 auto SaveReady = [&](float Angle, float Score, float Miss, int Target) {
  const ivec2 Aim = NAimFromAngle(Angle);
  for(const auto &Shot : Ready) if(NAimFromAngle(Shot.m_Angle) == Aim) return;
  Ready.push_back({Angle, Score, Miss, Target});
  std::stable_sort(Ready.begin(), Ready.end(), [](const SShot &A, const SShot &B) { return A.m_Score != B.m_Score ? A.m_Score > B.m_Score : A.m_Miss < B.m_Miss; });
  if(Ready.size() > 32) Ready.resize(32);
 };
 auto TestAngle = [&](float Angle) {
  const ivec2 Aim = NAimFromAngle(Angle);
  const vec2 Direction = normalize(vec2(Aim.x, Aim.y));
  for(int TargetTick = TargetStart; TargetTick <= TargetEnd; ++TargetTick)
   for(int WantBounces = 1; WantBounces <= BouncesLimit; ++WantBounces)
   {
    if(time_get_impl() >= SearchDeadline) return;
    const int TravelTicks = WantBounces * DelayTicks;
    const int FireTick = TargetTick - TravelTicks;
    if(!NBetaCanSchedule(FireTick, EnterFreeze) || !Frames[TargetTick - 1].m_Frozen) continue;
    // Future shots use their future launch position, not today's MyPos.
    // Reject unknown tune transitions instead of inventing a travel delay.
    if(Frames[FireTick].m_Zone != Frames[0].m_Zone) continue;
    vec2 Pos = Frames[FireTick].m_Pos, Dir = Direction;
    float Energy = Reach;
    bool ZeroLast = false;
    for(int Bounces = 0; Bounces <= BouncesLimit && Energy >= 0; ++Bounces)
    {
     vec2 CollisionPos, To = Pos + Dir * Energy;
     const int Res = Source.Collision()->IntersectLineTeleWeapon(Pos, To, &CollisionPos, &To);
     // The laser stops at its FIRST character hit, not the chosen bounce.
     // Cheap moving-owner check prunes premature returns; native simulation
     // below also handles other players and the actual unfreeze outcome.
     if(Bounces > 0 && Bounces < WantBounces)
     {
      const int EarlierTick = FireTick + Bounces * DelayTicks;
      const vec2 Delta = To - Pos;
      if(EarlierTick > 0 && EarlierTick <= 64 && dot(Delta, Delta) > .00001f)
      {
       const vec2 OwnerPos = Frames[EarlierTick - 1].m_Pos;
       const float Along = std::clamp(dot(OwnerPos - Pos, Delta) / dot(Delta, Delta), 0.0f, 1.0f);
       if(distance(Pos + Delta * Along, OwnerPos) < 28.0f) break;
      }
     }
     if(Bounces == WantBounces)
     {
      // Lasers tick before characters: aim at the pre-tick character position.
      const vec2 TargetPos = Frames[TargetTick - 1].m_Pos;
      const vec2 Delta = To - Pos;
      if(dot(Delta, Delta) > .00001f)
      {
       const float Along = std::clamp(dot(TargetPos - Pos, Delta) / dot(Delta, Delta), 0.0f, 1.0f);
       const float Miss = distance(Pos + Delta * Along, TargetPos);
       if(Miss < 28.0f)
       {
        // Prefer a central return over a grazing high-timing-score hit.
        const float Score = NBetaShotScore(TargetTick, ExitFreeze + 1, TravelTicks) - Miss * 50.0f;
        if(FireTick == 0) SaveReady(Angle, Score, Miss, TargetTick);
        if(Score > BestScore || (Score == BestScore && Miss < BestMiss))
        { BestScore = Score; BestMiss = Miss; BestAngle = Angle; BestFire = FireTick; BestTarget = TargetTick; }
       }
      }
      break;
     }
     if(!Res) break;
     const vec2 From = Pos;
     Pos = To;
     vec2 TempDir = Dir * 4.0f;
     int OldTile = 0;
     if(Res == -1)
     {
      OldTile = Source.Collision()->GetTile(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y));
      Source.Collision()->SetCollisionAt(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y), TILE_SOLID);
     }
     Source.Collision()->MovePoint(&Pos, &TempDir, 1.0f, nullptr);
     if(Res == -1) Source.Collision()->SetCollisionAt(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y), OldTile);
     if(length(TempDir) < .001f) break;
     const float Travel = distance(From, Pos);
     if(Travel == 0 && ZeroLast) break;
     ZeroLast = Travel == 0;
     Dir = normalize(TempDir);
     Energy -= Travel + pTune->m_LaserBounceCost;
    }
   }
 };
 AngleStep = std::clamp(AngleStep, 1, 15);
 const int Count = (360 + AngleStep - 1) / AngleStep;
 // Same degree grid as the tutorial, distributed around the circle if the CPU budget expires.
 int Stride = 37;
 while(std::gcd(Stride, Count) != 1) ++Stride;
 const int64_t CoarseDeadline = time_get_impl() + std::max<int64_t>(0, SearchDeadline - time_get_impl()) * 3 / 4;
 for(int Sample = 0; Sample < Count && time_get_impl() < CoarseDeadline; ++Sample)
  TestAngle(((Sample * Stride) % Count) * AngleStep * pi / 180.0f);
 // Refine several ready-to-fire angles, not only a high-scoring future shot.
 if(AngleStep > 1)
 {
  std::vector<float> Centers;
  for(size_t i = 0; i < std::min<size_t>(4, Ready.size()); ++i) Centers.push_back(Ready[i].m_Angle);
  if(BestFire >= 0) Centers.push_back(BestAngle);
  for(float Center : Centers)
   for(int i = -8; i <= 8 && time_get_impl() < SearchDeadline; ++i) TestAngle(Center + i * .3f * pi / 180.0f);
 }
 ENLaserStatus LastReason = ENLaserStatus::NoAngle;
 // A future candidate must not suppress a valid shot due NOW.
 // Verify only the current launch (no 1.8 early/late triple verification).
 for(const auto &Shot : Ready)
 {
  if(time_get_impl() >= Deadline) return Fail(ENLaserStatus::BudgetExpired);
  SLaserUnfreezeAim Verified;
  int ReturnTick = 0;
  if(Verify(Source, ClientId, Input, NAimFromAngle(Shot.m_Angle), Reach, 64,
   Deadline, 0, 2, MaxMiss, ReturnTick, Verified, LastReason, 2, true))
  {
   if(HookSensitive)
   {
    // Unlike a velocity offset, this is an actual earlier reconstructed world.
    // Its first physics tick still uses the known previous wire input; the
    // user's new release only belongs to the next scheduled input tick.
    if(pEarlySource && pEarlySource->GameTick() + 1 == Source.GameTick())
    {
     CCharacter *pEarlyOwner = pEarlySource->GetCharacterById(ClientId);
     if(!pEarlyOwner || pEarlyOwner->GetActiveWeapon() != WEAPON_LASER ||
      !pEarlyOwner->GetWeaponGot(WEAPON_LASER) || pEarlyOwner->GetWeaponAmmo(WEAPON_LASER) == 0)
     {
      LastReason = ENLaserStatus::BetaHookUncertain;
      continue;
     }
     SLaserUnfreezeAim Early;
     int EarlyReturn = 0;
     const CNetObj_PlayerInput PreviousPhysicsInput = pOwner->GetPredictionInput();
     const float EarlyReach = pEarlySource->GetTuning(pEarlyOwner->GetOverriddenTuneZone())->m_LaserReach;
     if(!Verify(*pEarlySource, ClientId, Input, NAimFromAngle(Shot.m_Angle), EarlyReach, 64,
      Deadline, 0, 2, MaxMiss, EarlyReturn, Early, LastReason, 2, true, 0, &PreviousPhysicsInput))
     {
      if(LastReason == ENLaserStatus::BudgetExpired) return Fail(LastReason);
      LastReason = ENLaserStatus::BetaHookUncertain;
      continue;
     }
    }
    // A just-released hook and a recovered release packet are timing-sensitive.
    // The SAME aim must thaw under one-tick-later launch; no angle chosen
    // from another branch may replace the tested wire aim.
    SLaserUnfreezeAim Late;
    int LateReturn = 0;
    if(!Verify(Source, ClientId, Input, NAimFromAngle(Shot.m_Angle), Reach, 64,
     Deadline, 1, 2, MaxMiss, LateReturn, Late, LastReason, 2, true))
    {
     if(LastReason == ENLaserStatus::BudgetExpired) return Fail(LastReason);
     LastReason = ENLaserStatus::BetaHookUncertain;
     continue;
    }
    if(OldHookAttached)
    {
     SLaserUnfreezeAim ReleaseLag;
     int LagReturn = 0;
     if(!Verify(Source, ClientId, Input, NAimFromAngle(Shot.m_Angle), Reach, 64,
      Deadline, 0, 2, MaxMiss, LagReturn, ReleaseLag, LastReason, 2, true, 1))
     {
      if(LastReason == ENLaserStatus::BudgetExpired) return Fail(LastReason);
      LastReason = ENLaserStatus::BetaHookUncertain;
      continue;
     }
    }
   }
   Verified.m_Target = NAimFromAngle(Shot.m_Angle);
   Verified.m_ReturnTick = ReturnTick;
   Result = std::move(Verified);
   if(pStatus) *pStatus = ENLaserStatus::BetaShotQueued;
   return true;
  }
  if(LastReason == ENLaserStatus::BudgetExpired) return Fail(LastReason);
 }
 // Waiting is informational only: no stale angle, no queued shot. Re-solve next tick.
 if(BestFire > 0)
 {
  Result.m_Target = NAimFromAngle(BestAngle);
  Result.m_LaunchTick = Source.GameTick() + BestFire;
  Result.m_ReturnTick = Source.GameTick() + BestTarget;
  Result.m_Forecast.clear();
  for(size_t i = BestFire; i < Frames.size(); ++i)
   Result.m_Forecast.push_back({Frames[i].m_Pos, Frames[i].m_Frozen, Source.GameTick() + (int)i});
  return Fail(ENLaserStatus::BetaWaiting);
 }
 return Fail(Ready.empty() ? ENLaserStatus::NoAngle : LastReason);
}
