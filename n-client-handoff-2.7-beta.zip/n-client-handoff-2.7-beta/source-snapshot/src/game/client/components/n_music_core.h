// Local now-playing helpers. No authentication, network or playback controls.
#ifndef GAME_CLIENT_COMPONENTS_N_MUSIC_CORE_H
#define GAME_CLIENT_COMPONENTS_N_MUSIC_CORE_H
#include <algorithm>
#include <atomic>
#include <chrono>
#include <thread>
#include <string>
#include <cstdint>
#include <cmath>
namespace NMusic
{
enum class EAsync { RUNNING, DONE, FAILED };
template<typename TStatus, typename TCancel>
bool Await(TStatus Status, TCancel Cancel, const std::atomic<bool> &Stop, std::chrono::steady_clock::time_point Deadline)
{
	while(!Stop && std::chrono::steady_clock::now() < Deadline)
	{
		const auto State = Status();
		if(State == EAsync::DONE) return true;
		if(State == EAsync::FAILED) return false;
		std::this_thread::sleep_for(std::chrono::milliseconds(20));
	}
	Cancel();
	return false;
}
enum class EAction { NONE, PREVIOUS, PLAY, PAUSE, NEXT };
struct SCommand { EAction m_Action = EAction::NONE; uint64_t m_SessionToken = 0; };
struct SPosition { float m_X, m_Y; };
inline SPosition Position(int X, int Y, float ScreenWidth, float CardWidth, float CardHeight)
{
	return {std::clamp(X, 0, 1000) / 1000.0f * std::max(0.0f, ScreenWidth - CardWidth),
		std::clamp((float)Y, 0.0f, std::max(0.0f, 300.0f - CardHeight))};
}
inline void SavePosition(float X, float Y, float ScreenWidth, float CardWidth, float CardHeight, int &SavedX, int &SavedY)
{
	const float Room = std::max(0.0f, ScreenWidth - CardWidth);
	SavedX = Room > 0.0f ? (int)std::lround(std::clamp(X / Room, 0.0f, 1.0f) * 1000.0f) : 0;
	SavedY = (int)std::lround(std::clamp(Y, 0.0f, std::max(0.0f, 300.0f - CardHeight)));
}
enum class EStatus { NONE, PLAYING, PAUSED, STOPPED, TITLE_ONLY };
struct STrack
{
	std::string m_Title, m_Artist, m_App, m_Detail;
	EStatus m_Status = EStatus::NONE;
	uint64_t m_SessionToken = 0;
	bool m_Previous = false, m_Play = false, m_Pause = false, m_Next = false;
	bool m_Pending = false;
	std::string m_ControlFeedback;
};
inline bool CanControl(const STrack &Track, EAction Action)
{
	if(!Track.m_SessionToken || Track.m_Pending || Track.m_Status == EStatus::NONE || Track.m_Status == EStatus::TITLE_ONLY) return false;
	switch(Action)
	{
	case EAction::PREVIOUS: return Track.m_Previous;
	case EAction::PLAY: return Track.m_Play;
	case EAction::PAUSE: return Track.m_Pause;
	case EAction::NEXT: return Track.m_Next;
	default: return false;
	}
}
inline bool Matches(const SCommand &Command, uint64_t SessionToken)
{
	return Command.m_Action != EAction::NONE && Command.m_SessionToken != 0 && Command.m_SessionToken == SessionToken;
}
inline std::string Clean(std::string Text)
{
	for(char &C : Text) if((unsigned char)C < 32 || C == 127) C = ' ';
	const auto First = Text.find_first_not_of(' ');
	if(First == std::string::npos) return {};
	Text = Text.substr(First, Text.find_last_not_of(' ') - First + 1);
	// Keep UTF-8 intact when bounding untrusted metadata.
	if(Text.size() > 512)
	{
		size_t End = 512;
		while(End && ((unsigned char)Text[End] & 0xc0) == 0x80) --End;
		Text.resize(End);
	}
	return Text;
}
inline int Rank(EStatus Status, bool Current)
{
	return Status == EStatus::PLAYING ? 300 + (Current ? 1 : 0) :
		Status == EStatus::PAUSED ? 200 + (Current ? 1 : 0) :
		Status == EStatus::STOPPED ? 100 + (Current ? 1 : 0) : 0;
}
inline std::string LowerAscii(std::string S)
{
	for(char &C : S) if(C >= 'A' && C <= 'Z') C += 'a' - 'A';
	return S;
}
inline STrack WindowTitle(const std::string &Exe, std::string Title)
{
	const std::string Process = LowerAscii(Exe);
	const bool Spotify = Process == "spotify.exe";
	const bool Yandex = Process == "yandexmusic.exe" || Process == "yandex music.exe";
	const bool Browser = Process == "chrome.exe" || Process == "msedge.exe" || Process == "firefox.exe" || Process == "browser.exe" || Process == "yandex.exe";
	Title = Clean(Title);
	if(!Spotify && !Yandex && !Browser) return {};
	if(Browser && Title.find("Яндекс Музыка") == std::string::npos && Title.find("Yandex Music") == std::string::npos) return {};
	for(const char *pSuffix : {" - Google Chrome", " — Mozilla Firefox", " - Microsoft Edge", " — Яндекс Браузер", " - Яндекс Браузер", " — Яндекс Музыка", " - Яндекс Музыка", " | Яндекс Музыка", " - Yandex Music", " - Spotify", " | Spotify"})
	{
		const std::string Suffix(pSuffix);
		if(Title.size() >= Suffix.size() && Title.compare(Title.size() - Suffix.size(), Suffix.size(), Suffix) == 0) Title.resize(Title.size() - Suffix.size());
	}
	// Generic application/page titles cannot prove a track is present.
	if(Title.empty() || Title == "Spotify" || Title == "Spotify Premium" || Title == "Spotify Free" || Title == "Яндекс Музыка" || Title == "Yandex Music") return {};
	size_t Sep = Title.find(" - "); size_t Length = 3;
	if(Sep == std::string::npos) { Sep = Title.find(" — "); Length = 5; }
	if(Sep == std::string::npos || Sep == 0 || Sep + Length >= Title.size()) return {};
	STrack Result;
	// Window title order varies; keep its full text rather than inventing artist/title roles.
	Result.m_Title = Clean(Title);
	Result.m_App = Spotify ? "Spotify" : "Яндекс Музыка";
	Result.m_Status = EStatus::TITLE_ONLY;
	Result.m_Detail = "Заголовок окна; состояние неизвестно";
	return Result;
}
inline const char *StatusText(EStatus Status)
{
	switch(Status)
	{
	case EStatus::PLAYING: return "Играет";
	case EStatus::PAUSED: return "Пауза";
	case EStatus::STOPPED: return "Остановлено";
	case EStatus::TITLE_ONLY: return "Из окна · состояние неизвестно";
	default: return "Нет данных о треке";
	}
}
}
#endif
