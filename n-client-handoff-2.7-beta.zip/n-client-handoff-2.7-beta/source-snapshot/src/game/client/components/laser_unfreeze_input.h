// Laser unfreeze assist: preserve manual input and the protocol fire counter.
#ifndef GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_INPUT_H
#define GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_INPUT_H
#include <generated/protocol.h>

class CLaserUnfreezeInput
{
	int m_Offset = 0;
	int m_ShotRawFire = 0;
	bool m_Queued = false;
	bool m_Guarded = false;
	CNetObj_PlayerInput m_Expected{};
	bool m_Release = false;
	int m_X = 1;
	int m_Y = 0;
public:
	void Reset() { m_Offset = 0; m_ShotRawFire = 0; m_Queued = false; m_Release = false; m_Guarded = false; }
	bool IsQueued() const { return m_Queued; }
	bool NeedsSend() const { return m_Queued || m_Release; }
	bool Queue(int X, int Y, const CNetObj_PlayerInput *pExpected = nullptr)
	{
		if(NeedsSend() || (X == 0 && Y == 0))
			return false;
		m_X = X; m_Y = Y; m_Queued = true;
		m_Guarded = pExpected != nullptr;
		if(pExpected) m_Expected = *pExpected;
		return true;
	}
	bool Finalize(CNetObj_PlayerInput &Input)
	{
		bool Committed = false;
		if(m_Release)
		{
			// A missing press packet is recovered from the fire counter in this
			// release packet. Keep its shot aim, not the physical mouse aim.
			// Any intervening manual fire-counter change takes priority.
			if((Input.m_Fire & INPUT_STATE_MASK) == m_ShotRawFire)
			{
				Input.m_TargetX = m_X; Input.m_TargetY = m_Y;
			}
			m_Offset = (m_Offset + 1) & INPUT_STATE_MASK;
			m_Release = false;
		}
		else if(m_Queued)
		{
			// A manual press between queue and finalization always wins.
			if(!(Input.m_Fire & 1) && (!m_Guarded ||
				(Input.m_Hook == m_Expected.m_Hook && Input.m_Direction == m_Expected.m_Direction && Input.m_Jump == m_Expected.m_Jump)))
			{
				m_Offset = (m_Offset + 1) & INPUT_STATE_MASK;
				m_Release = true;
				m_ShotRawFire = Input.m_Fire & INPUT_STATE_MASK;
				Committed = true;
				Input.m_TargetX = m_X; Input.m_TargetY = m_Y;
			}
			m_Queued = false; m_Guarded = false;
		}
		Input.m_Fire = (Input.m_Fire + m_Offset) & INPUT_STATE_MASK;
		return Committed;
	}
};
#endif
