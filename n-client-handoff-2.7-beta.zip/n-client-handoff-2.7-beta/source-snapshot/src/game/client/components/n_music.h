#ifndef GAME_CLIENT_COMPONENTS_N_MUSIC_H
#define GAME_CLIENT_COMPONENTS_N_MUSIC_H
#include <game/client/component.h>
#include "n_music_core.h"
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
class CNMusic : public CComponent
{
	std::thread m_Thread;
	std::atomic<bool> m_Stop{false}, m_Enabled{false}, m_Fallback{true};
	mutable std::mutex m_Mutex;
	std::condition_variable m_Wake;
	NMusic::STrack m_Track;
	NMusic::SCommand m_Command;
	bool m_CommandPending = false;
	bool m_Dragging = false;
	vec2 m_DragOffset{};
	void Worker();
	void RenderCard(bool Editor);
public:
	~CNMusic() override;
	int Sizeof() const override { return sizeof(*this); }
	void OnInit() override;
	void OnShutdown() override;
	void OnRender() override;
	NMusic::STrack Snapshot() const;
	bool QueueControl(NMusic::EAction Action, uint64_t SessionToken);
	void RenderEditor();
	void OnReset() override;
	void OnWindowResize() override;
};
#endif
