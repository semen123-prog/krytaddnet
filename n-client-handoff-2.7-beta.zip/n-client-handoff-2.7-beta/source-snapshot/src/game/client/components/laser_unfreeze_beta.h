#ifndef GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_BETA_H
#define GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_BETA_H
#include <algorithm>
#include <cmath>
// Tutorial timing/scoring, with past shots rejected rather than fired late.
inline int NBetaBounceTicks(float DelayMs, int TickSpeed)
{
 return (int)std::floor(DelayMs * TickSpeed / 1000.0f) + 1;
}
inline bool NBetaCanSchedule(int FireTick, int EnterFreeze)
{
 return FireTick >= 0 && FireTick < EnterFreeze;
}
inline float NBetaShotScore(int TargetTick, int ExitFreeze, int TravelTicks)
{
 return 10000.0f - std::abs(TargetTick - ExitFreeze) * 400.0f - TravelTicks * 50.0f +
  (TargetTick >= ExitFreeze && TargetTick <= ExitFreeze + 2 ? 1000.0f : 0.0f);
}
#endif
