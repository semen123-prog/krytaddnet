#include "n_music.h"
#include <base/str.h>
#include <engine/graphics.h>
#include <engine/shared/config.h>
#include <engine/textrender.h>
#include <game/client/gameclient.h>
#include <chrono>
#include <vector>
#if defined(CONF_FAMILY_WINDOWS)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#endif
using namespace std::chrono_literals;
namespace
{
#if defined(CONF_FAMILY_WINDOWS)
using namespace winrt::Windows::Media::Control;
using winrt::Windows::Foundation::AsyncStatus;
using TDeadline = std::chrono::steady_clock::time_point;
// Never wait for a WinRT operation on the render thread. Bound a whole polling pass.
template<typename T>
bool Await(const T &Operation, const std::atomic<bool> &Stop, TDeadline Deadline)
{
	// Repeated C++/WinRT wait_for would assign Completed multiple times, which is
	// illegal for many operations. Poll Status instead; no callback captures this.
	return NMusic::Await([&] {
		const auto Status = Operation.Status();
		return Status == AsyncStatus::Completed ? NMusic::EAsync::DONE :
			Status == AsyncStatus::Started ? NMusic::EAsync::RUNNING : NMusic::EAsync::FAILED;
	}, [&] { try { Operation.Cancel(); } catch(...) {} }, Stop, Deadline);
}
std::string Utf8(const wchar_t *pText)
{
	return NMusic::Clean(winrt::to_string(winrt::hstring(pText)));
}
struct SWindowSearch { NMusic::STrack m_Track; const std::atomic<bool> *m_pStop; TDeadline m_Deadline; };
BOOL CALLBACK FindWindowTrack(HWND Window, LPARAM Param)
{
	auto &Search = *reinterpret_cast<SWindowSearch *>(Param);
	if(*Search.m_pStop || std::chrono::steady_clock::now() >= Search.m_Deadline) return FALSE;
	if(!IsWindowVisible(Window)) return TRUE;
	wchar_t aTitle[1024];
	if(GetWindowTextW(Window, aTitle, 1024) <= 0) return TRUE;
	DWORD Pid = 0; GetWindowThreadProcessId(Window, &Pid);
	HANDLE Process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, Pid);
	if(!Process) return TRUE;
	wchar_t aPath[32768]; DWORD Size = 32768;
	const BOOL GotPath = QueryFullProcessImageNameW(Process, 0, aPath, &Size);
	CloseHandle(Process);
	if(!GotPath) return TRUE;
	const wchar_t *pExe = wcsrchr(aPath, L'\\');
	try
	{
		auto Track = NMusic::WindowTitle(Utf8(pExe ? pExe + 1 : aPath), Utf8(aTitle));
		if(Track.m_Status != NMusic::EStatus::NONE) { Search.m_Track = std::move(Track); return FALSE; }
	} catch(...) {}
	return TRUE;
}
NMusic::EStatus State(GlobalSystemMediaTransportControlsSessionPlaybackStatus Status)
{
	switch(Status)
	{
	case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing: return NMusic::EStatus::PLAYING;
	case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Paused: return NMusic::EStatus::PAUSED;
	case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Stopped: return NMusic::EStatus::STOPPED;
	default: return NMusic::EStatus::NONE;
	}
}
#endif
}
CNMusic::~CNMusic() { OnShutdown(); }
void CNMusic::OnInit()
{
	m_Stop = false;
	m_Enabled = g_Config.m_ClNMusic != 0;
	m_Fallback = g_Config.m_ClNMusicFallback != 0;
#if defined(CONF_FAMILY_WINDOWS)
	m_Thread = std::thread(&CNMusic::Worker, this);
#else
	m_Track.m_Detail = "Музыкальный HUD поддерживается в Windows 10 1809+";
#endif
}
void CNMusic::OnShutdown()
{
	m_Stop = true; m_Wake.notify_all();
	if(m_Thread.joinable()) m_Thread.join();
}
NMusic::STrack CNMusic::Snapshot() const
{
	std::lock_guard<std::mutex> Lock(m_Mutex);
	return m_Track;
}
void CNMusic::Worker()
{
#if defined(CONF_FAMILY_WINDOWS)
	bool Apartment = false;
	try { winrt::init_apartment(winrt::apartment_type::multi_threaded); Apartment = true; } catch(...) {}
	GlobalSystemMediaTransportControlsSessionManager Manager{nullptr};
	GlobalSystemMediaTransportControlsSession Selected{nullptr};
	uint64_t Token = 0;
	std::string Feedback;
	auto FeedbackUntil = std::chrono::steady_clock::now();
	while(!m_Stop)
	{
		NMusic::SCommand Command;
		{
			std::lock_guard<std::mutex> Lock(m_Mutex);
			Command = m_Command; m_Command = {};
		}
		if(Command.m_Action != NMusic::EAction::NONE)
		{
			Feedback = "Плеер изменился или команда недоступна";
			try
			{
				bool Present = false;
				if(Manager && Selected && m_Enabled && NMusic::Matches(Command, Token))
					for(const auto &Session : Manager.GetSessions()) if(Session == Selected) Present = true;
				if(Present && !m_Stop)
				{
					const auto Controls = Selected.GetPlaybackInfo().Controls();
					winrt::Windows::Foundation::IAsyncOperation<bool> Operation{nullptr};
					switch(Command.m_Action)
					{
					case NMusic::EAction::PREVIOUS: if(Controls.IsPreviousEnabled()) Operation = Selected.TrySkipPreviousAsync(); break;
					case NMusic::EAction::PLAY: if(Controls.IsPlayEnabled()) Operation = Selected.TryPlayAsync(); break;
					case NMusic::EAction::PAUSE: if(Controls.IsPauseEnabled()) Operation = Selected.TryPauseAsync(); break;
					case NMusic::EAction::NEXT: if(Controls.IsNextEnabled()) Operation = Selected.TrySkipNextAsync(); break;
					default: break;
					}
					if(Operation)
					{
						if(Await(Operation, m_Stop, std::chrono::steady_clock::now() + 700ms))
							Feedback = Operation.GetResults() ? "Команда принята плеером" : "Плеер отклонил команду";
						else Feedback = "Нет ответа плеера; команда не повторяется";
					}
				}
			} catch(...) { Feedback = "Не удалось управлять этой медиасессией"; }
			FeedbackUntil = std::chrono::steady_clock::now() + 4s;
		}
		NMusic::STrack Track;
		GlobalSystemMediaTransportControlsSession Candidate{nullptr};
		const auto Deadline = std::chrono::steady_clock::now() + 1200ms;
		if(m_Enabled && Apartment)
		{
			try
			{
				if(!Manager)
				{
					auto Request = GlobalSystemMediaTransportControlsSessionManager::RequestAsync();
					if(Await(Request, m_Stop, Deadline)) Manager = Request.GetResults();
				}
				if(Manager)
				{
					auto Current = Manager.GetCurrentSession();
					std::vector<GlobalSystemMediaTransportControlsSession> Sessions;
					if(Current) Sessions.push_back(Current);
					for(const auto &Session : Manager.GetSessions())
						if(Session != Current && Sessions.size() < 16) Sessions.push_back(Session);
					std::vector<std::pair<int, GlobalSystemMediaTransportControlsSession>> Ranked;
					for(const auto &Session : Sessions)
					{
						try { Ranked.emplace_back(NMusic::Rank(State(Session.GetPlaybackInfo().PlaybackStatus()), Session == Current), Session); } catch(...) {}
					}
					std::stable_sort(Ranked.begin(), Ranked.end(), [](const auto &A, const auto &B) { return A.first > B.first; });
					for(const auto &[Rank, Session] : Ranked)
					{
						if(m_Stop || !m_Enabled || std::chrono::steady_clock::now() >= Deadline) break;
						try
						{
							if(State(Session.GetPlaybackInfo().PlaybackStatus()) == NMusic::EStatus::NONE) continue;
							auto Request = Session.TryGetMediaPropertiesAsync();
							if(!Await(Request, m_Stop, std::min(Deadline, std::chrono::steady_clock::now() + 350ms))) continue;
							auto Properties = Request.GetResults();
							Track.m_Title = NMusic::Clean(winrt::to_string(Properties.Title()));
							if(Track.m_Title.empty()) continue;
							Track.m_Artist = NMusic::Clean(winrt::to_string(Properties.Artist()));
							Track.m_App = NMusic::Clean(winrt::to_string(Session.SourceAppUserModelId()));
							const auto Playback = Session.GetPlaybackInfo();
							Track.m_Status = State(Playback.PlaybackStatus());
							if(Track.m_Status == NMusic::EStatus::NONE) { Track = {}; continue; }
							const auto Controls = Playback.Controls();
							Track.m_Previous = Controls.IsPreviousEnabled();
							Track.m_Play = Controls.IsPlayEnabled();
							Track.m_Pause = Controls.IsPauseEnabled();
							Track.m_Next = Controls.IsNextEnabled();
							Track.m_Detail = "Медиасессия Windows";
							Candidate = Session;
							break;
						} catch(...) { Track = {}; }
					}
				}
			} catch(...) { Manager = nullptr; Track = {}; }
		}
		if(Candidate != Selected) { Selected = Candidate; ++Token; }
		if(Selected) Track.m_SessionToken = Token;
		if(m_Enabled && Track.m_Status == NMusic::EStatus::NONE && m_Fallback && !m_Stop)
		{
			SWindowSearch Search{{}, &m_Stop, std::chrono::steady_clock::now() + 150ms};
			EnumWindows(FindWindowTrack, reinterpret_cast<LPARAM>(&Search));
			Track = std::move(Search.m_Track); // title-only fallback never grants playback controls.
		}
		if(Track.m_Status == NMusic::EStatus::NONE) Track.m_Detail = "Нет медиаданных. Открой плеер и включи трек; некоторые приложения их не публикуют.";
		if(std::chrono::steady_clock::now() < FeedbackUntil) Track.m_ControlFeedback = Feedback;
		{
			std::lock_guard<std::mutex> Lock(m_Mutex);
			if(Command.m_Action != NMusic::EAction::NONE) m_CommandPending = false;
			Track.m_Pending = m_CommandPending;
			m_Track = m_Enabled ? std::move(Track) : NMusic::STrack{};
		}
		std::unique_lock<std::mutex> Lock(m_Mutex);
		m_Wake.wait_for(Lock, 500ms, [&] { return m_Stop || m_Command.m_Action != NMusic::EAction::NONE; });
	}
	Selected = nullptr;
	Manager = nullptr;
	if(Apartment) winrt::uninit_apartment();
#endif
}
bool CNMusic::QueueControl(NMusic::EAction Action, uint64_t SessionToken)
{
	{
		std::lock_guard<std::mutex> Lock(m_Mutex);
		if(m_Stop || !m_Enabled || m_CommandPending || SessionToken != m_Track.m_SessionToken || !NMusic::CanControl(m_Track, Action)) return false;
		m_Command = {Action, SessionToken};
		m_CommandPending = true;
		m_Track.m_Pending = true;
	}
	m_Wake.notify_all();
	return true;
}
void CNMusic::OnReset()
{
	g_Config.m_ClNMusicEdit = 0;
	OnWindowResize();
}
void CNMusic::OnWindowResize()
{
	m_Dragging = false;
	if(Ui()->ActiveItem() == &m_Dragging) Ui()->SetActiveItem(nullptr);
}
void CNMusic::OnRender()
{
	const bool Enabled = g_Config.m_ClNMusic != 0;
	if(m_Enabled.exchange(Enabled) != Enabled) m_Wake.notify_all();
	m_Fallback = g_Config.m_ClNMusicFallback != 0;
	if(!Enabled) { g_Config.m_ClNMusicEdit = 0; OnWindowResize(); return; }
	if(g_Config.m_ClNMusicEdit) { GameClient()->m_Menus.SetActive(true); return; }
	if(Client()->State() != IClient::STATE_ONLINE && Client()->State() != IClient::STATE_DEMOPLAYBACK) return;
	RenderCard(false);
}
void CNMusic::RenderEditor()
{
	Ui()->MapScreen();
	Ui()->Screen()->Draw(ColorRGBA(0.03f, 0.03f, 0.04f, 0.78f), IGraphics::CORNER_NONE, 0.0f);
	CUIRect Instructions = *Ui()->Screen();
	Instructions.HSplitBottom(60.0f, nullptr, &Instructions);
	Instructions.VMargin(20.0f, &Instructions);
	Ui()->DoLabel(&Instructions, "Тяни карточку за название. Кнопки снизу управляют треком. Esc — готово.", 14.0f, TEXTALIGN_ML);
	RenderCard(true);
	Ui()->MapScreen();
	CUIRect Close = {Ui()->Screen()->w - 150.0f, 8.0f, 140.0f, 28.0f};
	static int s_Close;
	Close.Draw(ColorRGBA(0.12f, 0.2f, 0.24f, 0.95f), IGraphics::CORNER_ALL, 4.0f);
	Ui()->DoLabel(&Close, "Готово / Esc", 14.0f, TEXTALIGN_MC);
	if(Ui()->DoButtonLogic(&s_Close, 0, &Close, BUTTONFLAG_LEFT))
	{
		g_Config.m_ClNMusicEdit = 0;
		OnWindowResize();
	}
}
void CNMusic::RenderCard(bool Editor)
{
	const auto Track = Snapshot();
	const CScreenRect Saved = Graphics()->GetScreen();
	const auto SavedColor = TextRender()->GetTextColor();
	TextRender()->TextColor(ColorRGBA(1.0f, 1.0f, 1.0f, 1.0f));
	const float Scale = Editor ? Ui()->Screen()->h / 300.0f : 1.0f;
	const float Width = Editor ? Ui()->Screen()->w / Scale : 300.0f * Graphics()->ScreenAspect();
	if(Editor) Ui()->MapScreen(); else Graphics()->MapScreenToSize(Width, 300.0f);
	const float CardWidth = std::min(170.0f, Width);
	constexpr float CardHeight = 34.0f;
	auto Pos = NMusic::Position(g_Config.m_ClNMusicX, g_Config.m_ClNMusicY, Width, CardWidth, CardHeight);
	CUIRect Card = {Pos.m_X * Scale, Pos.m_Y * Scale, CardWidth * Scale, CardHeight * Scale};
	if(Editor)
	{
		CUIRect Header = Card; Header.h = 19.0f * Scale;
		if(Ui()->MouseButtonClicked(0) && Ui()->MouseInside(&Header) && !Ui()->ActiveItem())
		{
			m_Dragging = true; m_DragOffset = Ui()->MousePos() - vec2(Card.x, Card.y);
			Ui()->SetActiveItem(&m_Dragging);
		}
		if(m_Dragging)
		{
			Ui()->CheckActiveItem(&m_Dragging);
			if(!Ui()->MouseButton(0)) { m_Dragging = false; Ui()->SetActiveItem(nullptr); }
			else
			{
				const vec2 Wanted = (Ui()->MousePos() - m_DragOffset) / Scale;
				NMusic::SavePosition(Wanted.x, Wanted.y, Width, CardWidth, CardHeight, g_Config.m_ClNMusicX, g_Config.m_ClNMusicY);
				Pos = NMusic::Position(g_Config.m_ClNMusicX, g_Config.m_ClNMusicY, Width, CardWidth, CardHeight);
				Card.x = Pos.m_X * Scale; Card.y = Pos.m_Y * Scale;
			}
		}
	}
	Card.Draw(ColorRGBA(0.05f, 0.05f, 0.07f, Editor ? 0.98f : 0.7f), IGraphics::CORNER_ALL, 3.0f * Scale);
	const std::string Title = Track.m_Title.empty() ? "Музыка · нет данных" : (Track.m_Artist.empty() ? Track.m_Title : Track.m_Artist + " — " + Track.m_Title);
	const auto Label = [&](float Y, float Size, const std::string &Text) {
		CTextCursor Cursor;
		Cursor.SetPosition(vec2(Card.x + 4.0f * Scale, Y));
		Cursor.m_FontSize = Size * Scale;
		Cursor.m_Flags = TEXTFLAG_RENDER | TEXTFLAG_ELLIPSIS_AT_END;
		Cursor.m_LineWidth = Card.w - 8.0f * Scale; Cursor.m_MaxLines = 1;
		TextRender()->TextEx(&Cursor, Text.c_str());
	};
	Label(Card.y + 2.0f * Scale, 7.0f, Title);
	const std::string Status = Track.m_Pending ? "Отправляю команду…" : !Track.m_ControlFeedback.empty() ? Track.m_ControlFeedback : NMusic::StatusText(Track.m_Status);
	Label(Card.y + 11.0f * Scale, 5.0f, Status);
	const NMusic::EAction Middle = Track.m_Status == NMusic::EStatus::PLAYING ? NMusic::EAction::PAUSE : NMusic::EAction::PLAY;
	const NMusic::EAction Actions[] = {NMusic::EAction::PREVIOUS, Middle, NMusic::EAction::NEXT};
	const char *Labels[] = {"<<", Middle == NMusic::EAction::PAUSE ? "Пауза" : "Играть", ">>"};
	static int s_Buttons[3];
	for(int i = 0; i < 3; ++i)
	{
		const float Cell = std::max(1.0f, (CardWidth - 8.0f) / 3.0f);
		CUIRect Button = {Card.x + (4.0f + i * Cell) * Scale, Card.y + 21.0f * Scale, std::max(1.0f, Cell - 2.0f) * Scale, 10.0f * Scale};
		const bool Available = NMusic::CanControl(Track, Actions[i]);
		Button.Draw(Available ? ColorRGBA(0.2f, 0.24f, 0.3f, 0.9f) : ColorRGBA(0.1f, 0.1f, 0.12f, 0.6f), IGraphics::CORNER_ALL, 2.0f * Scale);
		TextRender()->TextColor(Available ? ColorRGBA(1, 1, 1, 1) : ColorRGBA(0.5f, 0.5f, 0.5f, 1));
		Ui()->DoLabel(&Button, Labels[i], 6.0f * Scale, TEXTALIGN_MC);
		if(Editor && Available && !m_Dragging && Ui()->DoButtonLogic(&s_Buttons[i], 0, &Button, BUTTONFLAG_LEFT)) QueueControl(Actions[i], Track.m_SessionToken);
	}
	TextRender()->TextColor(SavedColor);
	Graphics()->MapScreen(Saved);
}
