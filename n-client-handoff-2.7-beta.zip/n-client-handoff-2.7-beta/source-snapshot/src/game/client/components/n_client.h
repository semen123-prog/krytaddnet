// n-client 0.2 movement prediction overlay.
#ifndef GAME_CLIENT_COMPONENTS_N_CLIENT_H
#define GAME_CLIENT_COMPONENTS_N_CLIENT_H
#include <game/client/component.h>
#include "laser_unfreeze.h"
class CNClient : public CComponent
{
	std::vector<SNPredictionPoint> m_Path;
	int m_LastTick = -1;
	int m_ClientId = -1;
	int m_Slot = -1;
	int m_Length = -1;
	CNetObj_PlayerInput m_LastInput{};
public:
	int Sizeof() const override { return sizeof(*this); }
	void OnReset() override;
	void OnRender() override;
};
#endif
