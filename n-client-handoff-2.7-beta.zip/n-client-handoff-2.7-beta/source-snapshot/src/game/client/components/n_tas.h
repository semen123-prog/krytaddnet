// n-client 2.3 beta: single/paired TAS with shared simulation, rewind and independent network input tracks.
#ifndef GAME_CLIENT_COMPONENTS_N_TAS_H
#define GAME_CLIENT_COMPONENTS_N_TAS_H
#include <game/client/component.h>
#include <game/client/prediction/gameworld.h>
#include "n_tas_core.h"
#include "laser_unfreeze.h"
#include <map>
#include <memory>
#include <utility>

class CNTas : public CComponent
{
	static constexpr int KEY_INTERVAL = 25; // world copy every N ticks, rewinding re-simulates at most N-1 ticks
	static constexpr int MAX_PLAN_TICKS = 6000;

	struct SActor
	{
		NTas::CEngine m_Engine;
		std::map<int, std::pair<int, int>> m_PlanPos;
		int m_LocalId = -1;
		vec2 m_SimPrev{0, 0}, m_SimCur{0, 0}, m_Aim{1, 0};
		int m_CumFire = 0, m_CumNext = 0, m_CumPrev = 0;
		int m_LiveFire = 0, m_LiveNext = 0, m_LivePrev = 0;
		CNetObj_PlayerInput m_LastRaw{};
		bool m_HaveRaw = false;
		int m_LastLabel = 0, m_LastCmpTick = -1, m_FirstDesync = -1;
		float m_Dev = 0.0f, m_MaxDev = 0.0f;
		ENLaserStatus m_PlanLaserStatus = ENLaserStatus::Disabled;
	};
	SActor m_aActors[2]; // roles: tee selected at session start, then its partner
	int m_MainConn = 0;
	bool m_WithDummy = false, m_PlayDonePending = false;
	NTas::SRecording m_Plan;
	std::unique_ptr<CGameWorld> m_pSim;
	std::vector<std::unique_ptr<CGameWorld>> m_vKeys;
	bool m_Planning = false, m_Paused = true, m_SimDead = false;
	float m_Accum = 0.0f;
	NTas::CStepRepeat m_StepRepeat;
	int m_StepKey = 0; // KEY_UNKNOWN; reset cancels any held step key
	int64_t m_StatusUntil = 0;
	int m_SavedSlot = 1, m_LastIdx = 0;
	int m_FilledGaps = 0, m_FirstGapIdx = -1;
	char m_aStatus[220] = "";

	int ActorCount() const { return m_WithDummy ? 2 : 1; }
	int Connection(int Role) const { return m_MainConn ^ Role; }
	int ActiveRole() const;
	void SelectMainConnection(int Conn);
	NTas::STrack &Track(int Role) { return Role ? m_Plan.m_Dummy : static_cast<NTas::STrack &>(m_Plan); }
	bool CheckActors();
	CNetObj_PlayerInput LiveInput(int Role) const;
	void SetStatus(const char *pText, int Seconds = 6);
	bool CanStart();
	void Log(const char *pEvent, const char *pDetail);
	bool Save(int Slot);
	bool Load(int Slot);
	void BuildPlanPos();
	void FreeSim();
	void EndSession(const char *pWhy);
	void Abort(const char *pWhy);
	bool AtRest(int Conn, vec2 *pPos) const;
	static int GotMask(const CCharacter *pChar);
	CNetObj_PlayerInput InputFromFrame(const NTas::SFrame &F, int Role) const;
	NTas::SFrame FrameFromLive(int Role);
	void ResyncLive(int Role);
	bool AdvanceSim(const NTas::SFrame &F, const NTas::SFrame &D, bool Record);
	void StepLive();
	void RewindTo(int Tick);
	void UpdatePlanning();
	void ResetStepRepeat();
	void UpdateStepRepeat();
	void DrawSimWeapons();
	void DrawPlanning();
	void DrawHud();

public:
	int Sizeof() const override { return sizeof(*this); }
	void OnReset() override;
	void OnStateChange(int NewState, int OldState) override;
	void OnNewSnapshot() override;
	void OnRender() override;
	bool OnInput(const IInput::CEvent &Event) override;

	int Process(int *pData, int Size, bool Dummy);
	void OnDummySwap();
	void ToggleSession();
	void StartPlay();
	void Stop();
	void TogglePause();
	void Step(int Direction);
	// Camera/crosshair follow the planned character while planning.
	void OverrideLocalPos(vec2 &Pos) const;
	bool Overriding() const { return m_aActors[0].m_Engine.Overriding() || m_aActors[1].m_Engine.Overriding(); }
	bool Planning() const { return m_Planning; }
	bool Playing() const { return m_aActors[0].m_Engine.Mode() == NTas::CEngine::EMode::Playing || m_aActors[1].m_Engine.Mode() == NTas::CEngine::EMode::Playing; }
	const char *Status() const { return m_aStatus; }
};
#endif
