// Configurable connection metadata. Does not change protocol, connection UUID,
// binary/checksum responses, or provide complete emulation of another client.
#ifndef ENGINE_SHARED_N_CLIENT_IDENTITY_H
#define ENGINE_SHARED_N_CLIENT_IDENTITY_H
#include <base/str.h>
namespace NIdentity
{
struct SProfile
{
	char m_aVersion[128]{};
	int m_Number = 0;
	bool m_Applied = false;
	const char *m_pError = nullptr;
};
inline bool ValidHash(const char *pHash)
{
	if(!pHash || !pHash[0]) return true;
	const int Length = str_length(pHash);
	if(Length < 7 || Length > 64) return false;
	for(int i = 0; i < Length; ++i)
		if(!((pHash[i] >= '0' && pHash[i] <= '9') || (pHash[i] >= 'a' && pHash[i] <= 'f') || (pHash[i] >= 'A' && pHash[i] <= 'F'))) return false;
	return true;
}
inline SProfile Build(bool Enabled, const char *pName, const char *pHash, int Number,
	const char *pRealString, const char *pRealName, const char *pRealHash, int RealNumber)
{
	SProfile Result;
	str_copy(Result.m_aVersion, pRealString, sizeof(Result.m_aVersion)); Result.m_Number = RealNumber;
	if(!Enabled) return Result;
	if(!ValidHash(pHash)) { Result.m_pError = "Хеш: только 7–64 символа 0–9 / a–f"; return Result; }
	if(Number < 0 || Number > 99999) { Result.m_pError = "Недопустимый номер DDNet"; return Result; }
	if(pName && pName[0])
	{
		if(str_length(pName) > 127 || !str_utf8_check(pName)) { Result.m_pError = "Недопустимая строка версии"; return Result; }
		for(const char *p = pName; *p; ++p)
			if((unsigned char)*p < 32 || (unsigned char)*p == 127 || *p == '(' || *p == ')')
			{ Result.m_pError = "Версия: без управляющих символов и скобок с хешем"; return Result; }
	}
	const char *pVersion = pName && pName[0] ? pName : pRealName;
	const char *pGit = pHash && pHash[0] ? pHash : pRealHash;
	const int Combined = str_length(pVersion) + ((pGit && pGit[0]) ? str_length(pGit) + 3 : 0);
	if(Combined >= (int)sizeof(Result.m_aVersion)) { Result.m_pError = "Строка версии с хешем слишком длинная"; return Result; }
	if(pGit && pGit[0]) str_format(Result.m_aVersion, sizeof(Result.m_aVersion), "%s (%s)", pVersion, pGit);
	else str_copy(Result.m_aVersion, pVersion, sizeof(Result.m_aVersion));
	Result.m_Number = Number > 0 ? Number : RealNumber;
	Result.m_Applied = true;
	return Result;
}
}
#endif
