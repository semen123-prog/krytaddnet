from pathlib import Path
import json,collections
B=Path('/data/raw/tas-debug');lines=(B/'nclient-tas-1.txt').read_text().splitlines();n=int(lines[3].split()[1]);frames=[list(map(int,s.split())) for s in lines[4:4+n]];pc=int(lines[4+n].split()[1]);pos=[list(map(int,s.split())) for s in lines[5+n:]];assert len(pos)==pc
log=[s.split(',',2) for s in (B/'nclient-tas.log').read_text().splitlines()];desync=[r[2] for r in log if len(r)==3 and r[1]=='desync'];assert len(desync)==sum(',desync,' in s for s in (B/'nclient-tas.log').read_text().splitlines())
ev={'source':'user TAS attachments','format':'NTAS2 per-frame inputs and post-tick positions; log split at first two commas, detail may contain commas','frames':n,'positions':pc,'desync_details':desync,'warnings':'repeated input rows intentional held keys; log mixes sessions and older client versions; timestamps reset; no observed per-tick replay positions supplied','window': [{'frame':i,'input':frames[i],'expected':pos[i][1:]} for i in range(115,146)],'disposition':'prose: code debugging, no measured actual trajectory for chart comparison'}
Path('/data/analysis/tas-evidence.json').write_text(json.dumps(ev,ensure_ascii=False,indent=2))
print('Valid NTAS2:',n,'frames;',pc,'post-tick positions; log split at first two commas; duplicate inputs expected.')
for r in ev['window'][::3]:print(r)
