// n-client 1.5: TAS without an address restriction. Planning runs in a private copy of the predicted world; replay sends the recorded inputs.
#include "n_tas.h"
#include <base/io.h>
#include <base/mem.h>
#include <base/str.h>
#include <base/time.h>
#include <engine/graphics.h>
#include <engine/shared/config.h>
#include <engine/storage.h>
#include <engine/textrender.h>
#include <game/client/animstate.h>
#include <game/client/gameclient.h>
#include <game/client/prediction/entities/character.h>
#include <game/client/prediction/entities/laser.h>
#include <game/client/prediction/entities/projectile.h>
#include <game/client/projectile_data.h>
#include <game/client/render.h>
#include <cmath>

namespace
{
bool IsFrozenChar(const CCharacter *pChar)
{
	return pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen;
}
const char *const gs_apWeaponNames[NUM_WEAPONS] = {"Молоток", "Пистолет", "Дробовик", "Гранатомёт", "Лазер", "Ниндзя"};
} // namespace

int CNTas::GotMask(const CCharacter *pChar)
{
	int Mask = 0;
	for(int w = 0; w < NUM_WEAPONS; ++w)
		if(pChar->Core()->m_aWeapons[w].m_Got) Mask |= 1 << w;
	return Mask;
}

void CNTas::SetStatus(const char *pText, int Seconds)
{
	str_copy(m_aStatus, pText, sizeof(m_aStatus));
	m_StatusUntil = time_get() + (int64_t)Seconds * time_freq();
}

void CNTas::Log(const char *pEvent, const char *pDetail)
{
	IOHANDLE File = Storage()->OpenFile("nclient-tas.log", IOFLAG_APPEND, IStorage::TYPE_SAVE);
	if(!File) return;
	if(io_length(File) < 256 * 1024)
	{
		char aLine[400];
		str_format(aLine, sizeof(aLine), "%lld,%s,%s\n", (long long)(time_get() / time_freq()), pEvent, pDetail);
		io_write(File, aLine, str_length(aLine));
	}
	io_close(File);
}

bool CNTas::Save(int Slot)
{
	char aPath[64];
	str_format(aPath, sizeof(aPath), "nclient-tas-%d.txt", Slot);
	IOHANDLE File = Storage()->OpenFile(aPath, IOFLAG_WRITE, IStorage::TYPE_SAVE);
	if(!File) return false;
	const std::string Text = NTas::Serialize(m_Plan);
	const bool Ok = io_write(File, Text.data(), Text.size()) == Text.size();
	io_close(File);
	return Ok;
}

void CNTas::BuildPlanPos()
{
	m_PlanPos.clear();
	for(const NTas::SPos &P : m_Plan.m_vPos) m_PlanPos[P.m_Idx] = {P.m_X, P.m_Y};
}

bool CNTas::Load(int Slot)
{
	char aPath[64];
	str_format(aPath, sizeof(aPath), "nclient-tas-%d.txt", Slot);
	IOHANDLE File = Storage()->OpenFile(aPath, IOFLAG_READ, IStorage::TYPE_SAVE);
	if(!File) return false;
	char *pText = io_read_all_str(File);
	io_close(File);
	if(!pText) return false;
	NTas::SRecording R;
	const bool Ok = NTas::Parse(pText, R);
	free(pText);
	if(!Ok || R.m_vFrames.empty()) return false;
	m_Plan = std::move(R);
	BuildPlanPos();
	return true;
}

bool CNTas::CanStart()
{
	if(!g_Config.m_ClNTas)
	{
		SetStatus("TAS выключен: включи галочку в Settings -> n-client -> TAS.");
		return false;
	}
	if(Client()->State() != IClient::STATE_ONLINE || Client()->DummyConnected() || GameClient()->m_Snap.m_SpecInfo.m_Active || !GameClient()->m_Snap.m_pLocalCharacter)
	{
		SetStatus("TAS: нужно быть живым на сервере, без dummy и не в наблюдателе.");
		return false;
	}
	return true;
}

bool CNTas::AtRest(vec2 *pPos) const
{
	const int Conn = g_Config.m_ClDummy;
	const CCharacter *pChar = GameClient()->m_PredictedWorld.GetCharacterById(GameClient()->m_aLocalIds[Conn]);
	if(!pChar) return false;
	if(pPos) *pPos = pChar->GetPos();
	const vec2 Vel = pChar->Core()->m_Vel;
	return std::abs(Vel.x) < 0.02f && std::abs(Vel.y) < 0.02f && pChar->Core()->m_HookState == HOOK_IDLE;
}

void CNTas::FreeSim()
{
	m_pSim.reset();
	m_vKeys.clear();
}

CNetObj_PlayerInput CNTas::InputFromFrame(const NTas::SFrame &F) const
{
	CNetObj_PlayerInput In;
	mem_zero(&In, sizeof(In));
	In.m_Direction = F.m_Direction;
	In.m_Jump = F.m_Jump;
	In.m_Hook = F.m_Hook;
	In.m_Fire = (m_Engine.F0() + F.m_Fire) & NTas::MASK;
	In.m_NextWeapon = (m_Engine.N0() + F.m_Next) & NTas::MASK;
	In.m_PrevWeapon = (m_Engine.P0() + F.m_Prev) & NTas::MASK;
	In.m_WantedWeapon = F.m_Weapon;
	In.m_TargetX = F.m_TargetX;
	In.m_TargetY = F.m_TargetY;
	In.m_PlayerFlags = PLAYERFLAG_PLAYING;
	return In;
}

void CNTas::ResyncLive()
{
	const CNetObj_PlayerInput &L = GameClient()->m_Controls.m_aInputData[g_Config.m_ClDummy];
	m_LiveFire = L.m_Fire & NTas::MASK;
	m_LiveNext = L.m_NextWeapon & NTas::MASK;
	m_LivePrev = L.m_PrevWeapon & NTas::MASK;
}

NTas::SFrame CNTas::FrameFromLive()
{
	const CNetObj_PlayerInput L = GameClient()->m_Controls.NClientHeldInput(g_Config.m_ClDummy); // fresh keys and mouse, weapon counters as in the real input
	NTas::SFrame F;
	F.m_Direction = std::clamp(L.m_Direction, -1, 1);
	F.m_Jump = L.m_Jump ? 1 : 0;
	F.m_Hook = L.m_Hook ? 1 : 0;
	F.m_Weapon = L.m_WantedWeapon;
	F.m_TargetX = L.m_TargetX;
	F.m_TargetY = L.m_TargetY;
	if(!F.m_TargetX && !F.m_TargetY) F.m_TargetX = 1;
	m_Aim = vec2((float)F.m_TargetX, (float)F.m_TargetY);
	int DFire = (L.m_Fire - m_LiveFire) & NTas::MASK;
	if((((m_CumFire + DFire) & 1) != (L.m_Fire & 1))) DFire += 1; // keep "pressed" in the plan equal to "pressed" on the keyboard
	m_CumFire += DFire;
	m_CumNext += (L.m_NextWeapon - m_LiveNext) & NTas::MASK;
	m_CumPrev += (L.m_PrevWeapon - m_LivePrev) & NTas::MASK;
	ResyncLive();
	F.m_Fire = m_CumFire;
	F.m_Next = m_CumNext;
	F.m_Prev = m_CumPrev;
	return F;
}

bool CNTas::AdvanceSim(const NTas::SFrame &F, bool Record)
{
	CCharacter *pChar = m_pSim ? m_pSim->GetCharacterById(m_LocalId) : nullptr;
	if(!pChar)
	{
		m_SimDead = true;
		return false;
	}
	const CNetObj_PlayerInput In = InputFromFrame(F);
	// Same order as CGameClient::UpdatePrediction: OnDirectInput runs BEFORE the tick counter advances,
	// so projectiles get StartTick = Tick - 1 (otherwise grenades/shotgun/gun fly one tick late and desync).
	pChar->OnDirectInput(&In);
	m_pSim->m_GameTick++;
	pChar->OnPredictedInput(&In);
	m_pSim->Tick();
	pChar = m_pSim->GetCharacterById(m_LocalId);
	vec2 Pos = m_SimCur;
	if(pChar)
		Pos = pChar->GetPos();
	else
		m_SimDead = true;
	m_SimPrev = m_SimCur;
	m_SimCur = Pos;
	if(Record)
	{
		const int Idx = (int)m_Plan.m_vFrames.size();
		m_Plan.m_vFrames.push_back(F);
		m_Plan.m_vPos.push_back({Idx, round_to_int(Pos.x), round_to_int(Pos.y)});
		if((Idx + 1) % KEY_INTERVAL == 0 && (int)m_vKeys.size() == (Idx + 1) / KEY_INTERVAL)
		{
			m_vKeys.push_back(std::make_unique<CGameWorld>());
			m_vKeys.back()->CopyWorld(m_pSim.get(), false);
		}
	}
	return true;
}

void CNTas::StepLive()
{
	if((int)m_Plan.m_vFrames.size() >= MAX_PLAN_TICKS)
	{
		m_Paused = true;
		SetStatus("Достигнут предел сессии (2 мин). Заверши сессию и начни новую.");
		return;
	}
	AdvanceSim(FrameFromLive(), true);
	if(m_SimDead)
	{
		m_Paused = true;
		SetStatus("TAS-тий умер. Шаг назад (кнопка назад) отменит последние тики.", 10);
	}
}

void CNTas::RewindTo(int Tick)
{
	if(!m_Planning || !m_pSim) return;
	Tick = std::clamp(Tick, 0, (int)m_Plan.m_vFrames.size());
	if(Tick == (int)m_Plan.m_vFrames.size()) return;
	size_t Key = std::min<size_t>(Tick / KEY_INTERVAL, m_vKeys.size() - 1);
	m_pSim->CopyWorld(m_vKeys[Key].get(), false);
	m_SimDead = false;
	const std::vector<NTas::SFrame> Frames = m_Plan.m_vFrames;
	m_SimCur = m_SimPrev = vec2((float)m_Plan.m_StartX, (float)m_Plan.m_StartY);
	if(CCharacter *pChar = m_pSim->GetCharacterById(m_LocalId)) m_SimCur = m_SimPrev = pChar->GetPos();
	for(int i = (int)Key * KEY_INTERVAL; i < Tick; ++i)
		AdvanceSim(Frames[i], false);
	m_Plan.m_vFrames.resize(Tick);
	m_Plan.m_vPos.resize(Tick);
	m_vKeys.resize(std::min<size_t>(m_vKeys.size(), Tick / KEY_INTERVAL + 1));
	m_SimPrev = m_SimCur;
	m_CumFire = Tick > 0 ? Frames[Tick - 1].m_Fire : 0;
	m_CumNext = Tick > 0 ? Frames[Tick - 1].m_Next : 0;
	m_CumPrev = Tick > 0 ? Frames[Tick - 1].m_Prev : 0;
	m_Accum = 0.0f;
	ResyncLive();
}

void CNTas::ToggleSession()
{
	if(m_Planning)
	{
		EndSession("Сессия закончена.");
		return;
	}
	if(m_Engine.Overriding())
	{
		SetStatus("TAS уже работает: нажми Стоп.");
		return;
	}
	if(!CanStart()) return;
	vec2 Pos;
	if(!AtRest(&Pos))
	{
		SetStatus("Встань неподвижно на земле (хук убран) и повтори: так старт будет точным.");
		return;
	}
	const int Conn = g_Config.m_ClDummy;
	m_LocalId = GameClient()->m_aLocalIds[Conn];
	m_pSim = std::make_unique<CGameWorld>();
	m_pSim->CopyWorld(&GameClient()->m_PredictedWorld, false);
	m_pSim->m_LocalClientId = GameClient()->m_PredictedWorld.m_LocalClientId;
	m_pSim->m_WorldConfig.m_PredictFreeze = 1;
	m_pSim->m_WorldConfig.m_PredictTiles = true;
	m_pSim->m_WorldConfig.m_PredictDDRace = true;
	m_pSim->m_WorldConfig.m_PredictWeapons = true;
	m_pSim->m_WorldConfig.m_PredictEvents = false;
	m_pSim->m_PredictedEvents.clear();
	for(CCharacter *pChar = (CCharacter *)m_pSim->FindFirst(CGameWorld::ENTTYPE_CHARACTER); pChar; pChar = (CCharacter *)pChar->TypeNext())
		pChar->m_CanMoveInFreeze = false;
	if(!m_pSim->GetCharacterById(m_LocalId))
	{
		FreeSim();
		SetStatus("Не удалось скопировать мир (нет предикта персонажа). Проверь cl_predict 1.");
		return;
	}
	m_vKeys.clear();
	m_vKeys.push_back(std::make_unique<CGameWorld>());
	m_vKeys.back()->CopyWorld(m_pSim.get(), false);
	m_Plan = NTas::SRecording();
	m_Plan.m_Lead = 0;
	m_Plan.m_HasStart = true;
	m_Plan.m_StartX = round_to_int(Pos.x);
	m_Plan.m_StartY = round_to_int(Pos.y);
	if(const CCharacter *pSimChar = m_pSim->GetCharacterById(m_LocalId))
	{
		m_Plan.m_HasLoadout = true;
		m_Plan.m_Active = std::clamp(pSimChar->Core()->m_ActiveWeapon, 0, NUM_WEAPONS - 1);
		m_Plan.m_GotMask = GotMask(pSimChar);
	}
	m_PlanPos.clear();
	m_Engine.BeginPrep(true, nullptr); // real character gets neutral input while we plan
	m_CumFire = m_CumNext = m_CumPrev = 0;
	ResyncLive();
	m_SimPrev = m_SimCur = Pos;
	m_SavedSlot = g_Config.m_ClNTasSlot;
	m_Planning = true;
	m_Paused = true;
	m_SimDead = false;
	m_Accum = 0.0f;
	SetStatus("TAS-сессия: пауза. Пуск/пауза - кнопка паузы, шаг - '.', назад - ','. Оружие: 1-5/колесо, огонь - ЛКМ (пишется в план). Конец - кнопка сессии.", 15);
	char aBuf[80];
	str_format(aBuf, sizeof(aBuf), "start=%d,%d", m_Plan.m_StartX, m_Plan.m_StartY);
	Log("session_start", aBuf);
}

void CNTas::EndSession(const char *pWhy)
{
	char aBuf[220];
	const int Frames = (int)m_Plan.m_vFrames.size();
	if(Frames >= 5)
	{
		if(Save(m_SavedSlot))
			str_format(aBuf, sizeof(aBuf), "%s Сохранено: слот %d, %d кадров (%.1f с). Проиграть: кнопка воспроизведения.", pWhy, m_SavedSlot, Frames, Frames / 50.0f);
		else
			str_format(aBuf, sizeof(aBuf), "%s НЕ УДАЛОСЬ СОХРАНИТЬ запись!", pWhy);
	}
	else
		str_format(aBuf, sizeof(aBuf), "%s Слишком коротко, не сохранено.", pWhy);
	SetStatus(aBuf, 10);
	Log("session_end", aBuf);
	m_Planning = false;
	FreeSim();
	m_Engine.RequestStop();
}

void CNTas::Abort(const char *pWhy)
{
	m_Planning = false;
	FreeSim();
	m_Engine.RequestStop();
	SetStatus(pWhy, 8);
	Log("abort", pWhy);
}

void CNTas::StartPlay()
{
	if(!CanStart()) return;
	if(m_Engine.Mode() == NTas::CEngine::EMode::Playing)
	{
		SetStatus("Уже проигрывается: нажми Стоп.");
		return;
	}
	if(m_Planning)
	{
		if(m_Plan.m_vFrames.size() < 5)
		{
			SetStatus("Слишком мало кадров для проигрывания.");
			return;
		}
		Save(m_SavedSlot);
		BuildPlanPos();
	}
	else if(!Load(g_Config.m_ClNTasSlot))
	{
		char aBuf[120];
		str_format(aBuf, sizeof(aBuf), "В слоте %d нет записи (или файл повреждён).", g_Config.m_ClNTasSlot);
		SetStatus(aBuf);
		return;
	}
	const CNetObj_Character *pChar = GameClient()->m_Snap.m_pLocalCharacter;
	if(m_Plan.m_HasStart)
	{
		const float dx = (float)(pChar->m_X - m_Plan.m_StartX), dy = (float)(pChar->m_Y - m_Plan.m_StartY);
		const float Dist = std::sqrt(dx * dx + dy * dy);
		if(Dist > 1.5f || std::abs(pChar->m_VelX) > 6 || std::abs(pChar->m_VelY) > 6 || pChar->m_HookState != HOOK_IDLE)
		{
			char aBuf[200];
			str_format(aBuf, sizeof(aBuf), "Встань неподвижно на старт записи (x %d, y %d). Сейчас откл. %.0f px.", m_Plan.m_StartX, m_Plan.m_StartY, Dist);
			SetStatus(aBuf, 10);
			return;
		}
	}
	if(m_Plan.m_HasLoadout)
	{
		const CCharacter *pRealChar = GameClient()->m_PredictedWorld.GetCharacterById(GameClient()->m_aLocalIds[g_Config.m_ClDummy]);
		if(pRealChar)
		{
			const int Mask = GotMask(pRealChar), Active = pRealChar->Core()->m_ActiveWeapon;
			if(Mask != m_Plan.m_GotMask || Active != m_Plan.m_Active)
			{
				char aBuf[220];
				str_format(aBuf, sizeof(aBuf), "Оружие не совпадает с записью: в записи в руках «%s» (набор %d), сейчас «%s» (набор %d). Возьми то же оружие и повтори.",
					gs_apWeaponNames[m_Plan.m_Active], m_Plan.m_GotMask, Active >= 0 && Active < NUM_WEAPONS ? gs_apWeaponNames[Active] : "?", Mask);
				SetStatus(aBuf, 12);
				return;
			}
		}
	}
	m_Planning = false;
	FreeSim();
	m_Engine.BeginPrep(false, &m_Plan);
	m_Engine.SetAnchor(Client()->PredGameTick(g_Config.m_ClDummy) + 1);
	m_FirstDesync = -1;
	m_LastLabel = 0;
	m_FilledGaps = 0;
	m_FirstGapIdx = -1;
	m_Dev = m_MaxDev = 0.0f;
	m_LastIdx = 0;
	m_LastCmpTick = -1;
	char aBuf[100];
	str_format(aBuf, sizeof(aBuf), "frames=%d", (int)m_Plan.m_vFrames.size());
	Log("play_start", aBuf);
	SetStatus("ПРОИГРЫВАНИЕ. Не нажимай кнопки.", 5);
}

void CNTas::Stop()
{
	if(m_Planning)
		EndSession("Сессия остановлена.");
	else if(m_Engine.Mode() == NTas::CEngine::EMode::Playing)
	{
		char aBuf[100];
		str_format(aBuf, sizeof(aBuf), "Проигрывание остановлено на кадре %d.", m_LastIdx);
		Abort(aBuf);
	}
}

void CNTas::TogglePause()
{
	if(!m_Planning) return;
	m_Paused = !m_Paused;
	m_Accum = 0.0f;
	if(!m_Paused) ResyncLive();
	SetStatus(m_Paused ? "Пауза." : "Идёт.", 2);
}

void CNTas::Step(int Direction)
{
	if(!m_Planning || !m_pSim) return;
	m_Paused = true;
	if(Direction < 0)
		RewindTo((int)m_Plan.m_vFrames.size() - 1);
	else if(!m_SimDead)
		StepLive();
}

void CNTas::OverrideLocalPos(vec2 &Pos) const
{
	if(!m_Planning || !m_pSim) return;
	const float t = m_Paused ? 1.0f : std::clamp(m_Accum, 0.0f, 1.0f);
	Pos = mix(m_SimPrev, m_SimCur, t);
}

void CNTas::OnReset()
{
	m_Planning = false;
	FreeSim();
	m_Engine.HardReset();
	m_HaveRaw = false;
}

void CNTas::OnStateChange(int NewState, int /*OldState*/)
{
	if(NewState != IClient::STATE_ONLINE) OnReset();
}

void CNTas::OnNewSnapshot()
{
	const CNetObj_Character *pChar = GameClient()->m_Snap.m_pLocalCharacter;
	if(m_Planning && !m_Engine.Closing())
	{
		if(!pChar || GameClient()->m_Snap.m_SpecInfo.m_Active) EndSession("Настоящий тий умер/наблюдатель - сессия закрыта.");
		return;
	}
	if(m_Engine.Mode() != NTas::CEngine::EMode::Playing || m_Engine.Closing()) return;
	if(!pChar || GameClient()->m_Snap.m_SpecInfo.m_Active)
	{
		char aBuf[160];
		str_format(aBuf, sizeof(aBuf), "Тий умер на кадре %d. Макс. откл. %.0f px.", m_LastIdx, m_MaxDev);
		Abort(aBuf);
		return;
	}
	m_LastIdx = std::max(0, Client()->GameTick(g_Config.m_ClDummy) - m_Engine.Anchor());
	if(pChar->m_Tick <= 0 || pChar->m_Tick == m_LastCmpTick) return;
	m_LastCmpTick = pChar->m_Tick;
	const int Idx = pChar->m_Tick - m_Engine.Anchor();
	const auto It = m_PlanPos.find(Idx);
	if(Idx < 0 || It == m_PlanPos.end()) return;
	const float dx = (float)(pChar->m_X - It->second.first), dy = (float)(pChar->m_Y - It->second.second);
	m_Dev = std::sqrt(dx * dx + dy * dy);
	m_MaxDev = std::max(m_MaxDev, m_Dev);
	if(m_FirstDesync < 0 && m_Dev > 1.5f)
	{
		m_FirstDesync = Idx;
		char aBuf[100];
		str_format(aBuf, sizeof(aBuf), "frame=%d dev=%.1f", Idx, m_Dev);
		Log("desync", aBuf);
	}
}

int CNTas::Process(int *pData, int Size, bool Dummy)
{
	if(Dummy) return Size;
	const int Conn = g_Config.m_ClDummy;
	if(Size == (int)sizeof(CNetObj_PlayerInput))
	{
		mem_copy(&m_LastRaw, pData, sizeof(m_LastRaw));
		m_HaveRaw = true;
	}
	else if(!m_Engine.Overriding())
		return Size;
	CNetObj_PlayerInput In = m_HaveRaw ? m_LastRaw : GameClient()->m_Controls.m_aInputData[Conn];
	if(m_Engine.Mode() == NTas::CEngine::EMode::Playing && !m_Engine.Closing())
	{
		// The client creates one input per predicted tick but can jump over a label (frame hitch, time sync). The server then keeps the
		// previous input for that tick and the replay desyncs. Re-send every skipped label right away with its own tick number.
		const int Label = Client()->PredGameTick(Conn);
		if(m_LastLabel > 0 && Label > m_LastLabel + 1 && Label - m_LastLabel <= 6)
		{
			for(int L = m_LastLabel + 1; L < Label; ++L)
			{
				CNetObj_PlayerInput Extra;
				if(!m_Engine.FrameInput(L, In, Extra)) continue;
				Client()->SendInputAtTick(Conn, L, (const int *)&Extra, sizeof(Extra));
				++m_FilledGaps;
				if(m_FirstGapIdx < 0) m_FirstGapIdx = L - m_Engine.Anchor();
				char aBuf[60];
				str_format(aBuf, sizeof(aBuf), "frame=%d", L - m_Engine.Anchor());
				Log("label_gap_filled", aBuf);
			}
		}
		m_LastLabel = Label;
	}
	const bool Force = m_Engine.Apply(In, Client()->PredGameTick(Conn));
	if(Size == 0 && !Force) return 0;
	mem_copy(pData, &In, sizeof(In));
	return sizeof(In);
}

bool CNTas::OnInput(const IInput::CEvent &Event)
{
	if(!g_Config.m_ClNTas || Event.m_Key == KEY_UNKNOWN || !(Event.m_Flags & (IInput::FLAG_PRESS | IInput::FLAG_REPEAT))) return false;
	if(Client()->State() != IClient::STATE_ONLINE) return false;
	if(GameClient()->m_Chat.IsActive() || GameClient()->m_Menus.IsActive() || GameClient()->m_GameConsole.IsActive() || GameClient()->m_KeyBinder.IsActive())
		return false;
	const bool Press = (Event.m_Flags & IInput::FLAG_PRESS) != 0;
	if(m_Planning && Event.m_Key == g_Config.m_ClNTasKeyBack)
	{
		Step(-1);
		return true;
	}
	if(m_Planning && Event.m_Key == g_Config.m_ClNTasKeyStep)
	{
		Step(1);
		return true;
	}
	if(!Press) return false;
	if(Event.m_Key == g_Config.m_ClNTasKeyRecord)
	{
		ToggleSession();
		return true;
	}
	if(Event.m_Key == g_Config.m_ClNTasKeyPlay)
	{
		StartPlay();
		return true;
	}
	if(Event.m_Key == g_Config.m_ClNTasKeyStop)
	{
		if(m_Planning) TogglePause();
		else Stop();
		return true;
	}
	return false;
}

void CNTas::UpdatePlanning()
{
	if(!m_Planning || !m_pSim || m_Paused || m_SimDead) return;
	if(GameClient()->m_Menus.IsActive() || GameClient()->m_Chat.IsActive()) return;
	m_Accum += Client()->RenderFrameTime() * 50.0f * g_Config.m_ClNTasSpeed / 100.0f;
	int Steps = 0;
	while(m_Accum >= 1.0f && Steps < 4 && !m_Paused && !m_SimDead)
	{
		m_Accum -= 1.0f;
		StepLive();
		++Steps;
	}
	if(m_Accum > 1.0f) m_Accum = 1.0f;
}

void CNTas::DrawSimWeapons()
{
	// Lines only: projectiles with a short trail, lasers, and the aim direction of the planned tee.
	const int Tick = m_pSim->GameTick(), TickSpeed = m_pSim->GameTickSpeed();
	for(CEntity *pEnt = m_pSim->FindFirst(CGameWorld::ENTTYPE_PROJECTILE); pEnt; pEnt = pEnt->TypeNext())
	{
		CProjectile *pProj = static_cast<CProjectile *>(pEnt);
		const int Type = pProj->GetData().m_Type;
		if(Type == WEAPON_GRENADE) Graphics()->SetColor(0.3f, 1.0f, 0.3f, 0.95f);
		else if(Type == WEAPON_SHOTGUN) Graphics()->SetColor(1.0f, 0.6f, 0.2f, 0.95f);
		else Graphics()->SetColor(1.0f, 1.0f, 0.3f, 0.95f);
		const float Pt = (float)(Tick - pProj->GetStartTick()) / (float)TickSpeed;
		const vec2 Pos = pProj->GetPos(Pt), Old = pProj->GetPos(std::max(0.0f, Pt - 0.06f));
		const IGraphics::CLineItem aLines[3] = {
			IGraphics::CLineItem(Old.x, Old.y, Pos.x, Pos.y),
			IGraphics::CLineItem(Pos.x - 4.0f, Pos.y, Pos.x + 4.0f, Pos.y),
			IGraphics::CLineItem(Pos.x, Pos.y - 4.0f, Pos.x, Pos.y + 4.0f)};
		Graphics()->LinesDraw(aLines, 3);
	}
	Graphics()->SetColor(0.4f, 0.9f, 1.0f, 0.95f);
	for(CEntity *pEnt = m_pSim->FindFirst(CGameWorld::ENTTYPE_LASER); pEnt; pEnt = pEnt->TypeNext())
	{
		CLaser *pLaser = static_cast<CLaser *>(pEnt);
		const IGraphics::CLineItem Line(pLaser->GetFrom().x, pLaser->GetFrom().y, pLaser->GetPos().x, pLaser->GetPos().y);
		Graphics()->LinesDraw(&Line, 1);
	}
	if(const CCharacter *pChar = m_pSim->GetCharacterById(m_LocalId))
	{
		if(length(m_Aim) > 0.001f)
		{
			const vec2 Dir = normalize(m_Aim), From = mix(m_SimPrev, m_SimCur, 1.0f);
			Graphics()->SetColor(1.0f, 1.0f, 1.0f, 0.35f);
			const IGraphics::CLineItem Line(From.x, From.y, From.x + Dir.x * 90.0f, From.y + Dir.y * 90.0f);
			Graphics()->LinesDraw(&Line, 1);
		}
		(void)pChar;
	}
}

void CNTas::DrawPlanning()
{
	if(!m_Planning || !m_pSim || Client()->State() != IClient::STATE_ONLINE) return;
	const CScreenRect Saved = Graphics()->GetScreen();
	const auto &Camera = GameClient()->m_Camera;
	Graphics()->MapScreen(Graphics()->MapScreenToWorld(Camera.m_Center.x, Camera.m_Center.y,
		100.0f, 100.0f, 100.0f, 0.0f, 0.0f, Graphics()->ScreenAspect(), Camera.m_Zoom));
	Graphics()->TextureClear();
	Graphics()->LinesBegin();
	Graphics()->SetColor(1.0f, 0.85f, 0.25f, 0.8f);
	const size_t Count = m_Plan.m_vPos.size();
	const size_t From = Count > 400 ? Count - 400 : 0;
	for(size_t i = From + 1; i < Count; ++i)
	{
		const IGraphics::CLineItem Line((float)m_Plan.m_vPos[i - 1].m_X, (float)m_Plan.m_vPos[i - 1].m_Y, (float)m_Plan.m_vPos[i].m_X, (float)m_Plan.m_vPos[i].m_Y);
		Graphics()->LinesDraw(&Line, 1);
	}
	if(const CCharacter *pChar = m_pSim->GetCharacterById(m_LocalId))
	{
		const CCharacterCore *pCore = pChar->Core();
		if(pCore->m_HookState == HOOK_FLYING || pCore->m_HookState == HOOK_GRABBED)
		{
			Graphics()->SetColor(1.0f, 1.0f, 1.0f, 0.8f);
			const IGraphics::CLineItem Hook(pCore->m_Pos.x, pCore->m_Pos.y, pCore->m_HookPos.x, pCore->m_HookPos.y);
			Graphics()->LinesDraw(&Hook, 1);
		}
	}
	DrawSimWeapons();
	Graphics()->LinesEnd();
	Graphics()->SetColor(1.0f, 1.0f, 1.0f, 1.0f);
	const int Conn = g_Config.m_ClDummy;
	vec2 Pos = m_SimCur;
	OverrideLocalPos(Pos);
	CTeeRenderInfo Info = GameClient()->m_aClients[m_LocalId].m_RenderInfo;
	vec2 Dir = GameClient()->m_Controls.m_aMousePos[Conn];
	if(length(Dir) > 0.001f) Dir = normalize(Dir);
	RenderTools()->RenderTee(CAnimState::GetIdle(), &Info, EMOTE_NORMAL, Dir, Pos, 0.7f);
	Graphics()->MapScreen(Saved);
}

void CNTas::DrawHud()
{
	const int64_t Now = time_get();
	if(!m_Planning && m_Engine.Mode() == NTas::CEngine::EMode::Idle && Now > m_StatusUntil) return;
	if(GameClient()->m_Menus.IsActive()) return;
	char aText[260] = "";
	if(m_Planning)
	{
		bool Frozen = false;
		if(const CCharacter *pChar = m_pSim ? m_pSim->GetCharacterById(m_LocalId) : nullptr) Frozen = IsFrozenChar(pChar);
		str_format(aText, sizeof(aText), "TAS ПЛАН  тик %d (%.2f с)  %s  x%d%%%s%s", (int)m_Plan.m_vFrames.size(), m_Plan.m_vFrames.size() / 50.0f,
			m_Paused ? "ПАУЗА" : "ИДЁТ", g_Config.m_ClNTasSpeed, Frozen ? "  FREEZE" : "", m_SimDead ? "  ТИЙ УМЕР" : "");
	}
	else if(m_Engine.Mode() == NTas::CEngine::EMode::Playing)
		str_format(aText, sizeof(aText), "TAS ПРОИГРЫВАНИЕ  кадр %d/%d  откл. %.0f px%s", m_LastIdx, (int)m_Plan.m_vFrames.size(), m_Dev, m_FirstDesync >= 0 ? "  РАССИНХРОН" : "");
	const CScreenRect SavedScreen = Graphics()->GetScreen();
	const auto SavedColor = TextRender()->GetTextColor();
	Graphics()->MapScreenToSize(300.0f * Graphics()->ScreenAspect(), 300.0f);
	const float CenterX = 150.0f * Graphics()->ScreenAspect();
	char aWeapon[200] = "";
	if(m_Planning && m_pSim)
	{
		if(const CCharacter *pChar = m_pSim->GetCharacterById(m_LocalId))
		{
			const int Active = pChar->Core()->m_ActiveWeapon;
			char aGot[40] = "";
			for(int w = 0; w < NUM_WEAPONS; ++w)
			{
				if(!pChar->Core()->m_aWeapons[w].m_Got) continue;
				char aOne[8];
				str_format(aOne, sizeof(aOne), w == Active ? " [%d]" : " %d", w + 1);
				str_append(aGot, aOne);
			}
			const int Ammo = Active >= 0 && Active < NUM_WEAPONS ? pChar->Core()->m_aWeapons[Active].m_Ammo : 0;
			const int Shots = m_Plan.m_vFrames.empty() ? 0 : (m_Plan.m_vFrames.back().m_Fire + 1) / 2;
			str_format(aWeapon, sizeof(aWeapon), "Оружие: %s  патронов %d  перезарядка %d  выстрелов в плане %d  Есть:%s",
				Active >= 0 && Active < NUM_WEAPONS ? gs_apWeaponNames[Active] : "?", Ammo, pChar->GetReloadTimer(), Shots, aGot);
		}
	}
	TextRender()->TextColor(1.0f, 0.85f, 0.35f, 1.0f);
	float Y = 24.0f;
	if(aText[0])
	{
		const float W = TextRender()->TextWidth(7.0f, aText, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 7.0f, aText);
		Y += 9.0f;
	}
	if(aWeapon[0])
	{
		const float W = TextRender()->TextWidth(6.0f, aWeapon, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 6.0f, aWeapon);
		Y += 8.0f;
	}
	if(m_aStatus[0] && Now <= m_StatusUntil)
	{
		const float W = TextRender()->TextWidth(6.0f, m_aStatus, -1, -1.0f);
		TextRender()->Text(CenterX - W / 2.0f, Y, 6.0f, m_aStatus);
	}
	TextRender()->TextColor(SavedColor);
	Graphics()->MapScreen(SavedScreen);
}

void CNTas::OnRender()
{
	if(Client()->State() != IClient::STATE_ONLINE) return;
	UpdatePlanning();
	if(m_Engine.TakeEnd() == NTas::CEngine::EEnd::PlayDone)
	{
		char aBuf[200];
		if(m_FirstDesync >= 0)
			str_format(aBuf, sizeof(aBuf), "Воспроизведение закончено. РАССИНХРОН с кадра %d, макс. откл. %.0f px. Досланных пропущенных тиков: %d.", m_FirstDesync, m_MaxDev, m_FilledGaps);
		else
			str_format(aBuf, sizeof(aBuf), "Воспроизведение закончено. Позиции совпали (макс. откл. %.1f px). Досланных пропущенных тиков: %d.", m_MaxDev, m_FilledGaps);
		SetStatus(aBuf, 10);
		Log("play_done", aBuf);
	}
	DrawPlanning();
	DrawHud();
}
