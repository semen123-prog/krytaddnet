// n-client 1.0. Path assumes the current keys remain held; future input is unknown.
#include "n_client.h"
#include <engine/graphics.h>
#include <engine/textrender.h>
#include <engine/shared/config.h>
#include <game/client/gameclient.h>
#include <game/client/prediction/entities/character.h>
#include <algorithm>
#include <base/str.h>

void CNClient::OnReset()
{
	m_Path.clear(); m_LastTick = -1; m_ClientId = -1; m_Slot = -1; m_Length = -1;
}
void CNClient::OnRender()
{
	if(g_Config.m_ClNClientStatus && g_Config.m_ClLaserAutoUnfreeze && Client()->State() == IClient::STATE_ONLINE &&
		!GameClient()->m_Menus.IsActive() && !GameClient()->m_Chat.IsActive() && !GameClient()->m_Snap.m_SpecInfo.m_Active)
	{
		const CScreenRect SavedScreen = Graphics()->GetScreen();
		const auto SavedColor = TextRender()->GetTextColor();
		Graphics()->MapScreenToSize(300.0f * Graphics()->ScreenAspect(), 300.0f);
		TextRender()->TextColor(0.8f, 0.95f, 1.0f, 1.0f);
		TextRender()->Text(8.0f, 270.0f, 6.0f, "n-client 1.0 / auto unfreeze:");
		TextRender()->Text(8.0f, 278.0f, 6.0f, NLaserStatusText(GameClient()->m_Controls.NLaserStatus(g_Config.m_ClDummy)));
		if(g_Config.m_ClNClientLearn)
		{
			const auto &L=GameClient()->m_Controls.NLearning(g_Config.m_ClDummy);
			char aLearning[256];
			str_format(aLearning,sizeof(aLearning),"Адаптация: фаза %+d т., образцы %d; thaw %d / freeze %d / ? %d",L.Phase(),L.Samples(),L.m_ObservedThaws,L.m_StillFrozen,L.m_Unknown);
			TextRender()->Text(8.0f,286.0f,5.0f,aLearning);
		}
		TextRender()->TextColor(SavedColor);
		Graphics()->MapScreen(SavedScreen);
	}
	if(!g_Config.m_ClNClientPrediction || !g_Config.m_ClPredict || Client()->State() != IClient::STATE_ONLINE ||
		GameClient()->m_Snap.m_SpecInfo.m_Active || GameClient()->m_Menus.IsActive() || GameClient()->m_Chat.IsActive())
	{
		m_Path.clear(); m_LastTick = -1;
		return;
	}
	const int Slot = g_Config.m_ClDummy;
	const int ClientId = GameClient()->m_aLocalIds[Slot];
	CGameWorld &World = GameClient()->m_PredictedWorld;
	CCharacter *pChar = World.GetCharacterById(ClientId);
	if(!pChar)
	{
		OnReset(); return;
	}
	const CNetObj_PlayerInput Held = GameClient()->m_Controls.NClientHeldInput(Slot);
	const int Tick = World.GameTick();
	const bool InputChanged = Held.m_Direction != m_LastInput.m_Direction || Held.m_Jump != m_LastInput.m_Jump ||
		Held.m_Hook != m_LastInput.m_Hook || (Held.m_Hook &&
			(Held.m_TargetX != m_LastInput.m_TargetX || Held.m_TargetY != m_LastInput.m_TargetY));
	const bool MovedFar = !m_Path.empty() && distance(pChar->GetPos(), m_Path.front().m_Pos) > 48.0f;
	const int Refresh = g_Config.m_ClNClientOptimize ? 2 : 1;
	if(m_LastTick < 0 || Slot != m_Slot || ClientId != m_ClientId || Tick < m_LastTick ||
		m_Length != g_Config.m_ClNClientPredictionTicks || ((InputChanged || MovedFar) && Tick != m_LastTick) || Tick - m_LastTick >= Refresh)
	{
		BuildNPredictionPath(World, ClientId, Held, g_Config.m_ClNClientPredictionTicks,
			g_Config.m_ClNClientOptimize ? 2 : 4, m_Path);
		m_LastTick = Tick; m_LastInput = Held; m_ClientId = ClientId; m_Slot = Slot;
		m_Length = g_Config.m_ClNClientPredictionTicks;
	}
	if(m_Path.size() < 2)
		return;
	const CScreenRect Saved = Graphics()->GetScreen();
	const auto &Camera = GameClient()->m_Camera;
	Graphics()->MapScreen(Graphics()->MapScreenToWorld(Camera.m_Center.x, Camera.m_Center.y,
		100.0f, 100.0f, 100.0f, 0.0f, 0.0f, Graphics()->ScreenAspect(), Camera.m_Zoom));
	Graphics()->TextureClear();
	Graphics()->LinesBegin();
	const float Alpha = g_Config.m_ClNClientPredictionAlpha / 100.0f;
	for(size_t Index = 1; Index < m_Path.size(); ++Index)
	{
		const auto &A = m_Path[Index - 1]; const auto &B = m_Path[Index];
		if(A.m_Frozen || B.m_Frozen) Graphics()->SetColor(1.0f, 0.22f, 0.22f, Alpha);
		else Graphics()->SetColor(0.2f, 0.85f, 1.0f, Alpha);
		const IGraphics::CLineItem Line(A.m_Pos.x, A.m_Pos.y, B.m_Pos.x, B.m_Pos.y);
		Graphics()->LinesDraw(&Line, 1);
	}
	Graphics()->LinesEnd();
	Graphics()->SetColor(1.0f, 1.0f, 1.0f, 1.0f);
	Graphics()->MapScreen(Saved);
}
