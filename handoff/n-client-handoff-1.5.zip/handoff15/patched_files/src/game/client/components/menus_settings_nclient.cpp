// n-client settings; Russian labels for the requested custom features.
#include "menus.h"
#include <engine/shared/config.h>
#include <engine/textrender.h>
#include <game/client/ui.h>
#include <game/client/gameclient.h>

void CMenus::RenderSettingsNClient(CUIRect MainView)
{
	CUIRect Row;
	MainView.HSplitTop(28.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, "n-client 1.5", 24.0f, TEXTALIGN_ML);
	MainView.HSplitTop(6.0f, nullptr, &MainView);
	static int s_Page = 0;
	{
		CUIRect Tabs, TabA, TabB;
		MainView.HSplitTop(22.0f, &Tabs, &MainView);
		Tabs.VSplitMid(&TabA, &TabB, 6.0f);
		static CButtonContainer s_PageLaser, s_PageTas;
		if(DoButton_Menu(&s_PageLaser, "Лазер", s_Page == 0, &TabA)) s_Page = 0;
		if(DoButton_Menu(&s_PageTas, "TAS", s_Page == 1, &TabB)) s_Page = 1;
		MainView.HSplitTop(6.0f, nullptr, &MainView);
	}
	if(s_Page == 1)
	{
		RenderSettingsNTas(MainView);
		return;
	}
	auto Check = [&](int &Value, const char *pLabel) {
		MainView.HSplitTop(18.0f, &Row, &MainView);
		if(DoButton_CheckBox(&Value, pLabel, Value, &Row)) Value ^= 1;
		MainView.HSplitTop(2.0f, nullptr, &MainView);
	};
	Check(g_Config.m_ClLaserAutoUnfreeze, "Laser Auto Unfreeze");
	Check(g_Config.m_ClNClientLearn, "Адаптация по серверным результатам (не нейросеть)");
	Check(g_Config.m_ClNClientFeedbackLog, "Локальный журнал выстрелов nclient-feedback-08.csv");
	Check(g_Config.m_ClNClientStatus, "Показывать причину отказа / статус поиска");
	Check(g_Config.m_ClNClientPrediction, "Показывать линию движения по зажатым кнопкам");
	Check(g_Config.m_ClNClientStrict, "Строгая проверка выстрела (меньше случайных выстрелов)");
	Check(g_Config.m_ClNClientOptimize, "Оптимизация: кэш и ограничение частоты расчётов");
	auto Slider = [&](int &Value, const char *pLabel, int Min, int Max, const char *pSuffix) {
		MainView.HSplitTop(20.0f, &Row, &MainView);
		Ui()->DoScrollbarOption(&Value, &Value, &Row, pLabel, Min, Max, &CUi::ms_LinearScrollbarScale, 0u, pSuffix);
		MainView.HSplitTop(3.0f, nullptr, &MainView);
	};
	Slider(g_Config.m_ClNClientPredictionTicks, "Длина предикта", 8, 64, " тиков");
	Slider(g_Config.m_ClNClientPredictionAlpha, "Прозрачность линии", 10, 100, "%");
	Slider(g_Config.m_ClLaserAutoUnfreezeSamples, "Качество поиска угла", 180, 1440, "");
	Slider(g_Config.m_ClLaserAutoUnfreezeBudget, "Бюджет расчёта выстрела", 2, 12, " мс");
	Slider(g_Config.m_ClNClientSearchInterval, "Интервал поиска при оптимизации", 1, 6, " тиков");
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	MainView.HSplitTop(24.0f, &Row, &MainView);
	static CButtonContainer s_Preset;
	if(DoButton_Menu(&s_Preset, "Применить настройки поиска: 500 / 3 мс / 3 тика", 0, &Row))
	{
		g_Config.m_ClNClientOptimize = 1;
		g_Config.m_ClLaserAutoUnfreezeSamples = 500;
		g_Config.m_ClLaserAutoUnfreezeBudget = 3;
		g_Config.m_ClNClientSearchInterval = 3;
	}
	MainView.HSplitTop(20.0f, &Row, &MainView);
	static CButtonContainer s_ResetLearn;
	if(DoButton_Menu(&s_ResetLearn, "Сбросить адаптацию текущей карты", 0, &Row)) GameClient()->m_Controls.ResetNLearning();
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, NLaserStatusText(GameClient()->m_Controls.NLaserStatus(g_Config.m_ClDummy)), 12.0f, TEXTALIGN_ML);
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	const char *apNotes[] = {
		"Голубая линия — движение. Красная — ожидаемая заморозка.",
		"Прогноз предполагает, что текущие кнопки остаются зажатыми.",
		"Нужен выбранный лазер, cl_predict 1 и cl_predict_freeze 1.",
		"Обучение локальное, сбрасывается при смене карты/подключения.",
		"Выстрел до freeze. Новый хук запускается первым. Пинг влияет.",
	};
	for(const char *pNote : apNotes)
	{
		MainView.HSplitTop(16.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, pNote, 12.0f, TEXTALIGN_ML);
	}
}

void CMenus::RenderSettingsNTas(CUIRect MainView)
{
	CUIRect Row;
	MainView.HSplitTop(18.0f, &Row, &MainView);
	if(DoButton_CheckBox(&g_Config.m_ClNTas, "Включить TAS", g_Config.m_ClNTas, &Row)) g_Config.m_ClNTas ^= 1;
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	static CButtonContainer s_aReader[5], s_aClear[5];
	auto KeyRow = [&](int Index, int &Key, const char *pLabel) {
		CUIRect Label, KeyRect;
		MainView.HSplitTop(20.0f, &Row, &MainView);
		MainView.HSplitTop(3.0f, nullptr, &MainView);
		Row.VSplitLeft(260.0f, &Label, &KeyRect);
		Ui()->DoLabel(&Label, pLabel, 12.0f, TEXTALIGN_ML);
		KeyRect.VSplitLeft(170.0f, &KeyRect, nullptr);
		const CKeyBinder::CKeyReaderResult Result = GameClient()->m_KeyBinder.DoKeyReader(&s_aReader[Index], &s_aClear[Index], &KeyRect, CBindSlot(Key, KeyModifier::NONE), false);
		if(!Result.m_Aborted && Result.m_Bind.m_Key != Key) Key = Result.m_Bind.m_Key;
	};
	KeyRow(0, g_Config.m_ClNTasKeyRecord, "Начать / закончить TAS-сессию (план)");
	KeyRow(1, g_Config.m_ClNTasKeyPlay, "Проиграть запись в игре");
	KeyRow(2, g_Config.m_ClNTasKeyStop, "Пауза / пуск плана; стоп проигрывания");
	KeyRow(3, g_Config.m_ClNTasKeyBack, "Шаг назад (можно удерживать)");
	KeyRow(4, g_Config.m_ClNTasKeyStep, "Шаг вперёд (можно удерживать)");
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoScrollbarOption(&g_Config.m_ClNTasSlot, &g_Config.m_ClNTasSlot, &Row, "Слот записи", 1, 9, &CUi::ms_LinearScrollbarScale, 0u, "");
	MainView.HSplitTop(3.0f, nullptr, &MainView);
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoScrollbarOption(&g_Config.m_ClNTasSpeed, &g_Config.m_ClNTasSpeed, &Row, "Скорость плана", 5, 100, &CUi::ms_LinearScrollbarScale, 0u, "%");
	MainView.HSplitTop(8.0f, nullptr, &MainView);
	MainView.HSplitTop(24.0f, &Row, &MainView);
	CUIRect ButtonA, ButtonB, ButtonC;
	Row.VSplitLeft(Row.w / 3.0f, &ButtonA, &Row);
	Row.VSplitMid(&ButtonB, &ButtonC);
	static CButtonContainer s_Session, s_Play, s_Stop;
	const bool Planning = GameClient()->m_Tas.Planning();
	if(DoButton_Menu(&s_Session, Planning ? "Закончить сессию" : "Начать сессию", Planning, &ButtonA))
	{
		GameClient()->m_Tas.ToggleSession();
		if(GameClient()->m_Tas.Overriding()) SetActive(false);
	}
	if(DoButton_Menu(&s_Play, "Проиграть", 0, &ButtonB))
	{
		GameClient()->m_Tas.StartPlay();
		if(GameClient()->m_Tas.Overriding()) SetActive(false);
	}
	if(DoButton_Menu(&s_Stop, "Стоп", 0, &ButtonC)) GameClient()->m_Tas.Stop();
	MainView.HSplitTop(8.0f, nullptr, &MainView);
	MainView.HSplitTop(16.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, GameClient()->m_Tas.Status()[0] ? GameClient()->m_Tas.Status() : "Статус: ожидание", 12.0f, TEXTALIGN_ML);
	MainView.HSplitTop(6.0f, nullptr, &MainView);
	const char *apNotes[] = {
		"1) Встань неподвижно на земле (хук убран), начни сессию: делается копия мира.",
		"2) Играй в копии (полупрозрачный тий): пауза, шаг вперёд/назад, замедление.",
		"3) Настоящий тий в это время стоит. Закончи сессию: запись сохранится.",
		"4) Проиграть: настоящий тий повторит ввод. Стоять надо на той же точке старта.",
		"Позиции сверяются по кадрам, при разнице появится РАССИНХРОН.",
		"Фильтра адресов нет. Соблюдай правила сервера; возможен рассинхрон.",
		"Записи: nclient-tas-1..9.txt, журнал: nclient-tas.log (папка настроек).",
	};
	for(const char *pNote : apNotes)
	{
		MainView.HSplitTop(16.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, pNote, 12.0f, TEXTALIGN_ML);
	}
}
