// n-client 1.3: TAS (weapons in the plan: fire, switch, projectiles, loadout check) without an address restriction. Plan in a copy of the world (slow motion, step, rewind), then replay the inputs. No respawn needed.
#ifndef GAME_CLIENT_COMPONENTS_N_TAS_H
#define GAME_CLIENT_COMPONENTS_N_TAS_H
#include <game/client/component.h>
#include <game/client/prediction/gameworld.h>
#include "n_tas_core.h"
#include <map>
#include <memory>
#include <utility>

class CNTas : public CComponent
{
	static constexpr int KEY_INTERVAL = 25; // world copy every N ticks, rewinding re-simulates at most N-1 ticks
	static constexpr int MAX_PLAN_TICKS = 6000;

	NTas::CEngine m_Engine;
	NTas::SRecording m_Plan;
	std::map<int, std::pair<int, int>> m_PlanPos;
	std::unique_ptr<CGameWorld> m_pSim;
	std::vector<std::unique_ptr<CGameWorld>> m_vKeys;
	bool m_Planning = false, m_Paused = true, m_SimDead = false;
	float m_Accum = 0.0f;
	vec2 m_SimPrev{0, 0}, m_SimCur{0, 0};
	int m_LocalId = -1;
	int m_CumFire = 0, m_CumNext = 0, m_CumPrev = 0;
	int m_LiveFire = 0, m_LiveNext = 0, m_LivePrev = 0;
	CNetObj_PlayerInput m_LastRaw{};
	bool m_HaveRaw = false;
	int64_t m_StatusUntil = 0;
	int m_SavedSlot = 1;
	float m_Dev = 0.0f, m_MaxDev = 0.0f;
	int m_FirstDesync = -1, m_LastIdx = 0, m_LastCmpTick = -1;
	vec2 m_Aim{1, 0};
	int m_LastLabel = 0, m_FilledGaps = 0, m_FirstGapIdx = -1;
	char m_aStatus[220] = "";

	void SetStatus(const char *pText, int Seconds = 6);
	bool CanStart();
	void Log(const char *pEvent, const char *pDetail);
	bool Save(int Slot);
	bool Load(int Slot);
	void BuildPlanPos();
	void FreeSim();
	void EndSession(const char *pWhy);
	void Abort(const char *pWhy);
	bool AtRest(vec2 *pPos) const;
	static int GotMask(const CCharacter *pChar);
	CNetObj_PlayerInput InputFromFrame(const NTas::SFrame &F) const;
	NTas::SFrame FrameFromLive();
	void ResyncLive();
	bool AdvanceSim(const NTas::SFrame &F, bool Record);
	void StepLive();
	void RewindTo(int Tick);
	void UpdatePlanning();
	void DrawSimWeapons();
	void DrawPlanning();
	void DrawHud();

public:
	int Sizeof() const override { return sizeof(*this); }
	void OnReset() override;
	void OnStateChange(int NewState, int OldState) override;
	void OnNewSnapshot() override;
	void OnRender() override;
	bool OnInput(const IInput::CEvent &Event) override;

	int Process(int *pData, int Size, bool Dummy);
	void ToggleSession();
	void StartPlay();
	void Stop();
	void TogglePause();
	void Step(int Direction);
	// Camera/crosshair follow the planned character while planning.
	void OverrideLocalPos(vec2 &Pos) const;
	bool Overriding() const { return m_Engine.Overriding(); }
	bool Planning() const { return m_Planning; }
	bool Playing() const { return m_Engine.Mode() == NTas::CEngine::EMode::Playing; }
	const char *Status() const { return m_aStatus; }
};
#endif
