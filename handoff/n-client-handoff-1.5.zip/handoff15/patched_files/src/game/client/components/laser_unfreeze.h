// n-client 0.4: conservative laser assistance and held-input prediction.
#ifndef GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_H
#define GAME_CLIENT_COMPONENTS_LASER_UNFREEZE_H
#include <base/vmath.h>
#include <generated/protocol.h>
#include <vector>
class CGameWorld;
enum class ENLaserStatus
{
 Disabled, Pending, Paused, PredictionDisabled, DummyMode, ManualFire,
 SelectLaser, WeaponSwitch, Waiting, HistoryUnavailable, BudgetExpired,
 Reloading, AlreadyFrozen, UnsupportedMap, UnsupportedTuning,
 NoFreezeAhead, NoAngle, VerificationFailed, ShotQueued, HookStarting, SuperMode, WaitingAck, NativeNoHit, NativeEarlyHit, NativeOffCenter, NativeRefreeze, NativeShortWindow, NativeLateTick
};
const char *NLaserStatusText(ENLaserStatus Status);
// The wire aim changes for one shot tick, never for the entire hook forecast.
inline CNetObj_PlayerInput NLaserShotStepInput(CNetObj_PlayerInput Held, ivec2 Aim, int Step)
{
	if(Step == 1) { Held.m_TargetX = Aim.x; Held.m_TargetY = Aim.y; }
	return Held;
}
struct SNPredictionPoint
{
	vec2 m_Pos;
	bool m_Frozen;
	int m_Tick = 0;
};
struct SLaserUnfreezeAim
{
	ivec2 m_Target = ivec2(1, 0);
	int m_ReturnTick = 0;
	int m_LaunchTick = 0;
	std::vector<SNPredictionPoint> m_Forecast;
};
bool BuildNPredictionPath(CGameWorld &Source, int ClientId, const CNetObj_PlayerInput &Input,
	int Ticks, int BudgetMs, std::vector<SNPredictionPoint> &Path);
bool FindLaserUnfreezeAim(CGameWorld &Source, int ClientId,
	const CNetObj_PlayerInput &Input, int Samples, int BudgetMs, SLaserUnfreezeAim &Result,
	bool Strict = true, ivec2 CachedAim = ivec2(0, 0), ENLaserStatus *pStatus = nullptr, float HitMargin = 0.0f, int *pFirstFrozenStep = nullptr);
#endif
