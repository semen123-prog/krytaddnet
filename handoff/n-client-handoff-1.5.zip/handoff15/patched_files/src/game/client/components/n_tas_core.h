// n-client 1.5 TAS core: tick-indexed input recording/replay, no engine dependencies except the input struct.
#ifndef GAME_CLIENT_COMPONENTS_N_TAS_CORE_H
#define GAME_CLIENT_COMPONENTS_N_TAS_CORE_H
#include <generated/protocol.h>
#include <algorithm>
#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

namespace NTas
{
constexpr int LEAD_TICKS = 10; // inputs right after respawn are neutral: some were already sent before the spawn was seen
constexpr int MAX_FRAMES = 50 * 60 * 10;
constexpr int MASK = INPUT_STATE_MASK;

struct SFrame
{
	int m_Direction = 0, m_Jump = 0, m_Hook = 0;
	int m_Fire = 0, m_Next = 0, m_Prev = 0; // counters relative to the neutral base
	int m_Weapon = 0, m_TargetX = 1, m_TargetY = 0;
};
struct SPos
{
	int m_Idx = 0, m_X = 0, m_Y = 0;
};
struct SRecording
{
	int m_Lead = LEAD_TICKS;
	bool m_HasStart = false;
	int m_StartX = 0, m_StartY = 0;
	bool m_HasLoadout = false; // weapons at the start: replay needs the same ones
	int m_Active = 0, m_GotMask = 0;
	std::vector<SFrame> m_vFrames;
	std::vector<SPos> m_vPos;
};

inline std::string Serialize(const SRecording &R)
{
	std::ostringstream S;
	S << "NTAS " << (R.m_HasLoadout ? 3 : 2) << "\nstart " << (R.m_HasStart ? 1 : 0) << ' ' << R.m_StartX << ' ' << R.m_StartY << "\n";
	if(R.m_HasLoadout) S << "loadout " << R.m_Active << ' ' << R.m_GotMask << "\n";
	S << "lead " << R.m_Lead << "\nframes " << R.m_vFrames.size() << "\n";
	for(const SFrame &F : R.m_vFrames)
		S << F.m_Direction << ' ' << F.m_Jump << ' ' << F.m_Hook << ' ' << F.m_Fire << ' ' << F.m_Weapon << ' ' << F.m_Next << ' ' << F.m_Prev << ' ' << F.m_TargetX << ' ' << F.m_TargetY << '\n';
	S << "positions " << R.m_vPos.size() << "\n";
	for(const SPos &P : R.m_vPos)
		S << P.m_Idx << ' ' << P.m_X << ' ' << P.m_Y << '\n';
	return S.str();
}
inline bool Parse(const std::string &Text, SRecording &Out)
{
	std::istringstream S(Text);
	std::string Word;
	int Version = 0;
	size_t Count = 0;
	SRecording R;
	if(!(S >> Word >> Version) || Word != "NTAS" || (Version < 1 || Version > 3)) return false;
	if(Version >= 2)
	{
		int Has = 0;
		if(!(S >> Word >> Has >> R.m_StartX >> R.m_StartY) || Word != "start") return false;
		R.m_HasStart = Has != 0;
	}
	if(Version == 3)
	{
		if(!(S >> Word >> R.m_Active >> R.m_GotMask) || Word != "loadout" || R.m_GotMask < 0 || R.m_GotMask > 63) return false;
		R.m_HasLoadout = true;
	}
	if(!(S >> Word >> R.m_Lead) || Word != "lead" || R.m_Lead < 0 || R.m_Lead > 1000) return false;
	if(!(S >> Word >> Count) || Word != "frames" || Count > (size_t)MAX_FRAMES) return false;
	R.m_vFrames.resize(Count);
	for(SFrame &F : R.m_vFrames)
	{
		if(!(S >> F.m_Direction >> F.m_Jump >> F.m_Hook >> F.m_Fire >> F.m_Weapon >> F.m_Next >> F.m_Prev >> F.m_TargetX >> F.m_TargetY)) return false;
		if(F.m_Direction < -1 || F.m_Direction > 1 || F.m_Fire < 0 || F.m_Next < 0 || F.m_Prev < 0) return false;
	}
	if(!(S >> Word >> Count) || Word != "positions" || Count > (size_t)MAX_FRAMES) return false;
	R.m_vPos.resize(Count);
	for(SPos &P : R.m_vPos)
		if(!(S >> P.m_Idx >> P.m_X >> P.m_Y)) return false;
	Out = std::move(R);
	return true;
}

// Private or loopback addresses only. Returns false for anything that looks like a public server.
inline bool IsLocalIpv4(int A, int B)
{
	if(A == 127 || A == 10) return true;
	if(A == 192 && B == 168) return true;
	if(A == 172 && B >= 16 && B <= 31) return true;
	if(A == 169 && B == 254) return true;
	if(A == 100 && B >= 64 && B <= 127) return true; // CGNAT / Tailscale
	if(A == 25 || A == 26) return true; // Hamachi / Radmin VPN
	return false;
}
inline bool IsLocalIpv6(const uint8_t *p)
{
	bool ZeroPrefix = true;
	for(int i = 0; i < 15; ++i) ZeroPrefix = ZeroPrefix && p[i] == 0;
	if(ZeroPrefix && p[15] == 1) return true; // ::1
	bool Mapped = true;
	for(int i = 0; i < 10; ++i) Mapped = Mapped && p[i] == 0;
	if(Mapped && p[10] == 0xff && p[11] == 0xff) return IsLocalIpv4(p[12], p[13]);
	if(p[0] == 0xfe && (p[1] & 0xc0) == 0x80) return true; // fe80::/10
	if((p[0] & 0xfe) == 0xfc) return true; // fc00::/7
	return false;
}

class CEngine
{
public:
	enum class EMode { Idle, PrepRecord, PrepPlay, Recording, Playing };
	enum class EEnd { None, Stopped, PlayDone };

	EMode Mode() const { return m_Mode; }
	bool Overriding() const { return m_Mode != EMode::Idle; }
	bool Waiting() const { return m_Mode == EMode::PrepRecord || m_Mode == EMode::PrepPlay; }
	int Anchor() const { return m_Anchor; }
	int F0() const { return m_F0; }
	int N0() const { return m_N0; }
	int P0() const { return m_P0; }
	int FirstIdx() const { return m_FirstIdx; }
	int Index(int Tick) const { return Tick - m_Anchor; }
	const SRecording &Recording() const { return m_Rec; }
	EEnd TakeEnd() { const EEnd E = m_End; m_End = EEnd::None; return E; }
	void SetFrameCapacityReached(bool V) { m_CapacityReached = V; }
	bool CapacityReached() const { return m_CapacityReached; }

	void BeginPrep(bool Record, const SRecording *pPlay)
	{
		m_Mode = Record ? EMode::PrepRecord : EMode::PrepPlay;
		m_F0 = (m_LastFire + 1) & ~1 & MASK;
		m_N0 = m_LastNext;
		m_P0 = m_LastPrev;
		m_PendingEnd = false;
		m_RealStarted = false;
		m_Closed = false;
		m_CapacityReached = false;
		m_FirstIdx = -1;
		m_CumFire = m_CumNext = m_CumPrev = 0;
		m_PrevFire = m_F0; m_PrevNext = m_N0; m_PrevPrev = m_P0;
		m_Rec = Record || !pPlay ? SRecording() : *pPlay;
	}
	void SetAnchor(int Anchor)
	{
		if(!Waiting()) return;
		m_Anchor = Anchor;
		m_Mode = m_Mode == EMode::PrepRecord ? EMode::Recording : EMode::Playing;
	}
	void HardReset()
	{
		m_Mode = EMode::Idle; m_End = EEnd::None; m_PendingEnd = false; m_Closed = false;
		m_ShiftActive = false; m_ShiftF = m_ShiftN = m_ShiftP = 0; m_LastFire = m_LastNext = m_LastPrev = 0;
	}
	bool Closing() const { return m_PendingEnd; }
	// Input the replay would send for a tick label. Used to re-send a label that the client skipped.
	bool FrameInput(int Tick, const CNetObj_PlayerInput &Raw, CNetObj_PlayerInput &Out) const
	{
		if(m_Mode != EMode::Playing) return false;
		const int Idx = Tick - m_Anchor;
		if(Idx < 0 || Idx >= (int)m_Rec.m_vFrames.size()) return false;
		Out = Raw;
		FillFrame(Out, m_Rec.m_vFrames[Idx], Raw);
		return true;
	}
	void RequestStop() { if(m_Mode != EMode::Idle) { m_PendingEnd = true; m_Closed = true; } }
	// Apply: Io is the raw final input, Tick the predicted tick label. Returns true when the packet must be sent now.
	bool Apply(CNetObj_PlayerInput &Io, int Tick)
	{
		const CNetObj_PlayerInput Raw = Io;
		if(m_PendingEnd && m_Mode != EMode::Idle)
		{
			EndOverride(Raw);
			Io = Raw;
			ApplyShift(Io);
			Remember(Io);
			m_Mode = EMode::Idle;
			m_End = EEnd::Stopped;
			m_PendingEnd = false;
			return true;
		}
		switch(m_Mode)
		{
		case EMode::Idle:
			ApplyShift(Io);
			Remember(Io);
			return false;
		case EMode::PrepRecord:
		case EMode::PrepPlay:
			Neutral(Io);
			Remember(Io);
			return true;
		case EMode::Recording:
		{
			const int Idx = Tick - m_Anchor;
			if(m_FirstIdx < 0)
			{
				m_FirstIdx = std::max(0, Idx);
				m_Rec.m_Lead = std::max((int)LEAD_TICKS, m_FirstIdx);
			}
			if(Idx < m_Rec.m_Lead)
				Neutral(Io);
			else
			{
				if(!m_RealStarted)
				{
					m_RealStarted = true;
					m_ShiftF = m_F0 - (Raw.m_Fire & ~1);
					m_ShiftN = m_N0 - Raw.m_NextWeapon;
					m_ShiftP = m_P0 - Raw.m_PrevWeapon;
					m_ShiftActive = true;
				}
				ApplyShift(Io);
				Io.m_PlayerFlags = Clean(Io.m_PlayerFlags);
			}
			Remember(Io);
			if(!m_Closed && Idx >= 0)
			{
				if(Idx >= MAX_FRAMES)
				{
					m_CapacityReached = true;
					m_PendingEnd = true;
					m_Closed = true;
				}
				else
					Store(Idx, Io);
			}
			return true;
		}
		case EMode::Playing:
		{
			const int Idx = Tick - m_Anchor;
			if(m_FirstIdx < 0) m_FirstIdx = std::max(0, Idx);
			if(Idx < 0)
			{
				Neutral(Io);
				Remember(Io);
				return true;
			}
			if(Idx >= (int)m_Rec.m_vFrames.size())
			{
				EndOverride(Raw);
				Io = Raw;
				ApplyShift(Io);
				Remember(Io);
				m_Mode = EMode::Idle;
				m_End = EEnd::PlayDone;
				return true;
			}
			FillFrame(Io, m_Rec.m_vFrames[Idx], Raw);
			Remember(Io);
			return true;
		}
		}
		return false;
	}

private:
	EMode m_Mode = EMode::Idle;
	EEnd m_End = EEnd::None;
	SRecording m_Rec;
	int m_Anchor = 0, m_FirstIdx = -1;
	int m_F0 = 0, m_N0 = 0, m_P0 = 0;
	int m_LastFire = 0, m_LastNext = 0, m_LastPrev = 0;
	int m_ShiftF = 0, m_ShiftN = 0, m_ShiftP = 0;
	int m_CumFire = 0, m_CumNext = 0, m_CumPrev = 0, m_PrevFire = 0, m_PrevNext = 0, m_PrevPrev = 0;
	bool m_ShiftActive = false, m_PendingEnd = false, m_RealStarted = false, m_Closed = false, m_CapacityReached = false;

	void FillFrame(CNetObj_PlayerInput &Io, const SFrame &F, const CNetObj_PlayerInput &Raw) const
	{
		Io.m_Direction = F.m_Direction;
		Io.m_Jump = F.m_Jump;
		Io.m_Hook = F.m_Hook;
		Io.m_Fire = (m_F0 + F.m_Fire) & MASK;
		Io.m_NextWeapon = (m_N0 + F.m_Next) & MASK;
		Io.m_PrevWeapon = (m_P0 + F.m_Prev) & MASK;
		Io.m_WantedWeapon = F.m_Weapon;
		Io.m_TargetX = F.m_TargetX;
		Io.m_TargetY = F.m_TargetY;
		Io.m_PlayerFlags = Clean(Raw.m_PlayerFlags);
	}
	static int Clean(int Flags) { return (Flags & ~(PLAYERFLAG_IN_MENU | PLAYERFLAG_CHATTING)) | PLAYERFLAG_PLAYING; }
	void Remember(const CNetObj_PlayerInput &Io) { m_LastFire = Io.m_Fire; m_LastNext = Io.m_NextWeapon; m_LastPrev = Io.m_PrevWeapon; }
	void ApplyShift(CNetObj_PlayerInput &Io) const
	{
		if(!m_ShiftActive) return;
		Io.m_Fire = (Io.m_Fire + m_ShiftF) & MASK;
		Io.m_NextWeapon = (Io.m_NextWeapon + m_ShiftN) & MASK;
		Io.m_PrevWeapon = (Io.m_PrevWeapon + m_ShiftP) & MASK;
	}
	void Neutral(CNetObj_PlayerInput &Io) const
	{
		Io.m_Direction = 0;
		Io.m_Jump = 0;
		Io.m_Hook = 0;
		Io.m_WantedWeapon = 0;
		Io.m_Fire = m_F0;
		Io.m_NextWeapon = m_N0;
		Io.m_PrevWeapon = m_P0;
		Io.m_PlayerFlags = Clean(Io.m_PlayerFlags);
	}
	void EndOverride(const CNetObj_PlayerInput &Raw)
	{
		// Recording keeps its constant shift; every other end re-aligns the protocol counters so no phantom shot appears.
		if(m_Mode == EMode::Recording && m_RealStarted) return;
		m_ShiftF = ((m_LastFire + 1) & ~1) - (Raw.m_Fire & ~1);
		m_ShiftN = m_LastNext - Raw.m_NextWeapon;
		m_ShiftP = m_LastPrev - Raw.m_PrevWeapon;
		m_ShiftActive = true;
	}
	void Store(int Idx, const CNetObj_PlayerInput &Io)
	{
		SFrame Blank;
		Blank.m_TargetX = Io.m_TargetX;
		Blank.m_TargetY = Io.m_TargetY;
		while((int)m_Rec.m_vFrames.size() <= Idx)
			m_Rec.m_vFrames.push_back(m_Rec.m_vFrames.empty() ? Blank : m_Rec.m_vFrames.back());
		m_CumFire += (Io.m_Fire - m_PrevFire) & MASK; m_PrevFire = Io.m_Fire;
		m_CumNext += (Io.m_NextWeapon - m_PrevNext) & MASK; m_PrevNext = Io.m_NextWeapon;
		m_CumPrev += (Io.m_PrevWeapon - m_PrevPrev) & MASK; m_PrevPrev = Io.m_PrevWeapon;
		SFrame &F = m_Rec.m_vFrames[Idx];
		F.m_Direction = Io.m_Direction;
		F.m_Jump = Io.m_Jump;
		F.m_Hook = Io.m_Hook;
		F.m_Fire = m_CumFire;
		F.m_Next = m_CumNext;
		F.m_Prev = m_CumPrev;
		F.m_Weapon = Io.m_WantedWeapon;
		F.m_TargetX = Io.m_TargetX;
		F.m_TargetY = Io.m_TargetY;
	}
};
} // namespace NTas
#endif
