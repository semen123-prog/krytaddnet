// Experimental DDNet 20.1 self-unfreeze assist. Not an authoritative server simulation.
#include "laser_unfreeze.h"
#include <base/math.h>
#include <base/time.h>
#include <game/client/prediction/entities/character.h>
#include <game/client/prediction/entities/laser.h>
#include <game/client/prediction/gameworld.h>
#include <game/collision.h>
#include <game/mapitems.h>
#include <algorithm>
#include <cmath>
#include <vector>

namespace
{
struct SFutureFrame
{
	vec2 m_Pos;
	bool m_Frozen;
};
struct SCandidate
{
	ivec2 m_Target;
	float m_Score;
};
void SetupCopy(CGameWorld &World, CGameWorld &Source)
{
	// Never replace Source's prediction child or borrow entity parent pointers.
	World.CopyWorld(&Source, false);
	World.m_LocalClientId = Source.m_LocalClientId;
	World.m_WorldConfig.m_PredictFreeze = 1;
	World.m_WorldConfig.m_PredictTiles = true;
	World.m_WorldConfig.m_PredictDDRace = true;
	// Existing projectiles still tick, but don't create unrelated future shots.
	World.m_WorldConfig.m_PredictWeapons = false;
	World.m_WorldConfig.m_PredictEvents = false;
	World.m_PredictedEvents.clear();
	for(CCharacter *pChar = (CCharacter *)World.FindFirst(CGameWorld::ENTTYPE_CHARACTER); pChar; pChar = (CCharacter *)pChar->TypeNext())
		pChar->m_CanMoveInFreeze = false;
}
CNetObj_PlayerInput QuietInput(CNetObj_PlayerInput Input)
{
	if(Input.m_Fire & 1)
		Input.m_Fire = (Input.m_Fire + 1) & INPUT_STATE_MASK;
	Input.m_WantedWeapon = 0;
	Input.m_NextWeapon = 0;
	Input.m_PrevWeapon = 0;
	return Input;
}
bool UsableFrozen(CCharacter *pChar)
{
	return pChar && pChar->m_FreezeTime > 0 &&
		!pChar->Core()->m_DeepFrozen && !pChar->Core()->m_LiveFrozen;
}
// Geometry is only a fast candidate filter. The native CLaser verifies the hit.
bool GeometryCandidate(CCollision *pCollision, vec2 Origin, vec2 Direction,
	float Energy, float BounceCost, int BounceNum, int DelayTicks,
	float Radius, const std::vector<SFutureFrame> &vFrames, float &Score)
{
	vec2 Pos = Origin;
	int Step = 0;
	int Bounces = 0;
	bool ZeroLast = false;
	while(Energy >= 0.0f && Step < (int)vFrames.size())
	{
		vec2 CollisionPos;
		vec2 To = Pos + Direction * Energy;
		const int Res = pCollision->IntersectLineTeleWeapon(Pos, To, &CollisionPos, &To);
		if(Bounces > 0 && vFrames[Step].m_Frozen && distance(Pos, To) > 0.001f)
		{
			const vec2 Delta = To - Pos;
			const float Along = std::clamp(dot(vFrames[Step].m_Pos - Pos, Delta) / dot(Delta, Delta), 0.0f, 1.0f);
			const float Miss = distance(Pos + Delta * Along, vFrames[Step].m_Pos);
			if(Miss < Radius)
			{
				Score = Miss + Step * 0.1f;
				return true;
			}
		}
		if(!Res)
			return false;
		const vec2 From = Pos;
		Pos = To;
		vec2 TempDir = Direction * 4.0f;
		int Tile = 0;
		if(Res == -1)
		{
			Tile = pCollision->GetTile(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y));
			pCollision->SetCollisionAt(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y), TILE_SOLID);
		}
		pCollision->MovePoint(&Pos, &TempDir, 1.0f, nullptr);
		if(Res == -1)
			pCollision->SetCollisionAt(round_to_int(CollisionPos.x), round_to_int(CollisionPos.y), Tile);
		if(length(TempDir) < 0.001f)
			return false;
		Direction = normalize(TempDir);
		const float Travel = distance(From, Pos);
		if(Travel == 0.0f && ZeroLast)
			return false;
		Energy -= Travel + BounceCost;
		ZeroLast = Travel == 0.0f;
		if(++Bounces > BounceNum)
			return false;
		Step += DelayTicks;
	}
	return false;
}
ivec2 NAimFromAngle(float Angle)
{
	return ivec2(round_to_int(std::cos(Angle) * 1000.0f), round_to_int(std::sin(Angle) * 1000.0f));
}
// Local angle refinement: halve the angle step and keep any move that lowers the
// geometric miss. Only a candidate filter; native verification still decides.
float RefineGeometryAngle(CCollision *pCollision, vec2 Origin, float &Angle, float Score,
	float Energy, float BounceCost, int BounceNum, int DelayTicks, float Radius,
	const std::vector<SFutureFrame> &vFrames, int64_t Deadline)
{
	float Step = 0.02f;
	for(int Iteration = 0; Iteration < 10 && time_get() < Deadline; ++Iteration, Step *= 0.5f)
		for(int Move = 0; Move < 4; ++Move)
		{
			bool Improved = false;
			for(int Sign = -1; Sign <= 1 && !Improved; Sign += 2)
			{
				const ivec2 TryAim = NAimFromAngle(Angle + Sign * Step);
				float TryScore;
				if(GeometryCandidate(pCollision, Origin, normalize(vec2(TryAim.x, TryAim.y)), Energy, BounceCost,
					   BounceNum, DelayTicks, Radius, vFrames, TryScore) &&
					TryScore < Score)
				{
					Score = TryScore;
					Angle += Sign * Step;
					Improved = true;
				}
			}
			if(!Improved)
				break;
		}
	return Score;
}
bool Verify(CGameWorld &Source, int ClientId, const CNetObj_PlayerInput &Input,
	ivec2 Aim, float Reach, int Horizon, int64_t Deadline, int ShotDelay, float MaxMiss, int &ReturnTick, SLaserUnfreezeAim &Details, ENLaserStatus &Reason)
{
	int OwnerUnfreezeTick = -1, OwnerHitTick = -1;
	auto Fail = [&](ENLaserStatus Status) { Reason = Status; return false; };
	float HitDistance = 1000.0f;
	CGameWorld World;
	SetupCopy(World, Source);
	CNetObj_PlayerInput Future = QuietInput(Input);
	// Future keeps the physical mouse aim; only the firing packet uses Aim.
	CCharacter *pChar = World.GetCharacterById(ClientId);
	if(!pChar)
		return Fail(ENLaserStatus::HistoryUnavailable);
	pChar->SetInput(&Future);
	for(int Tick = 0; Tick < ShotDelay; ++Tick)
	{
		if(time_get() >= Deadline)
			return Fail(ENLaserStatus::BudgetExpired);
		++World.m_GameTick;
		pChar->OnPredictedInput(&Future);
		World.Tick();
		pChar = World.GetCharacterById(ClientId);
		if(!pChar)
			return Fail(ENLaserStatus::HistoryUnavailable);
	}
	// The delayed shot must still be physically possible, not shot from freeze.
	if(pChar->m_FreezeTime != 0 || pChar->GetReloadTimer() != 0 ||
		pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen)
		return Fail(ENLaserStatus::AlreadyFrozen);
	new CLaser(&World, pChar->GetPos(), normalize(vec2(Aim.x, Aim.y)), Reach,
		ClientId, WEAPON_LASER, &OwnerUnfreezeTick, &HitDistance, &OwnerHitTick);
	const int Start = World.GameTick();
	std::vector<SNPredictionPoint> Forecast;
	Forecast.reserve(Horizon+4);
	Forecast.push_back({pChar->GetPos(), false, Start});
	int ClearTicks = 0;
	for(int Step = 1; Step <= Horizon + 3; ++Step)
	{
		if(time_get() >= Deadline)
			return Fail(ENLaserStatus::BudgetExpired);
		pChar = World.GetCharacterById(ClientId);
		if(!pChar)
			return Fail(ENLaserStatus::HistoryUnavailable);
		World.m_GameTick = Start + Step;
		const CNetObj_PlayerInput StepInput = NLaserShotStepInput(Future, Aim, Step);
		pChar->OnPredictedInput(&StepInput);
		World.Tick();
		pChar = World.GetCharacterById(ClientId);
		if(!pChar) return Fail(ENLaserStatus::HistoryUnavailable);
		Forecast.push_back({pChar->GetPos(), pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen, World.GameTick()});
		if(OwnerUnfreezeTick >= 0)
		{
			pChar = World.GetCharacterById(ClientId);
			if(HitDistance > MaxMiss) return Fail(ENLaserStatus::NativeOffCenter);
			if(!pChar) return Fail(ENLaserStatus::HistoryUnavailable);
			if(pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen)
				return Fail(ENLaserStatus::NativeRefreeze);
			// Reject hits which only clear freeze momentarily before immediate refreeze.
			if(++ClearTicks >= 3)
			{
				ReturnTick = OwnerUnfreezeTick;
				Details.m_LaunchTick = Start;
				Details.m_Forecast = std::move(Forecast);
				return true;
			}
		}
	}
	return Fail(OwnerUnfreezeTick >= 0 ? ENLaserStatus::NativeShortWindow :
		OwnerHitTick >= 0 ? ENLaserStatus::NativeEarlyHit : ENLaserStatus::NativeNoHit);
}
}

bool FindLaserUnfreezeAim(CGameWorld &Source, int ClientId,
	const CNetObj_PlayerInput &Input, int Samples, int BudgetMs, SLaserUnfreezeAim &Result,
	bool Strict, ivec2 CachedAim, ENLaserStatus *pStatus, float HitMargin, int *pFirstFrozenStep)
{
	auto Fail = [&](ENLaserStatus Status) { if(pStatus) *pStatus = Status; return false; };
	if(pFirstFrozenStep) *pFirstFrozenStep = -1;
	CCharacter *pOwner = Source.GetCharacterById(ClientId);
	if(!pOwner || !Source.Collision()) return Fail(ENLaserStatus::HistoryUnavailable);
	if(pOwner->IsSuper() || pOwner->Core()->m_Invincible) return Fail(ENLaserStatus::SuperMode);
	if(!Source.m_WorldConfig.m_IsDDRace || Source.m_WorldConfig.m_OldLaser)
		return Fail(ENLaserStatus::UnsupportedMap);
	if(pOwner->GetActiveWeapon() != WEAPON_LASER || !pOwner->GetWeaponGot(WEAPON_LASER) || pOwner->GetWeaponAmmo(WEAPON_LASER) == 0)
		return Fail(ENLaserStatus::SelectLaser);
	if(pOwner->m_FreezeTime != 0 || pOwner->Core()->m_DeepFrozen || pOwner->Core()->m_LiveFrozen)
		return Fail(ENLaserStatus::AlreadyFrozen);
	if(pOwner->GetReloadTimer() != 0) return Fail(ENLaserStatus::Reloading);
	if(Input.m_Fire & 1) return Fail(ENLaserStatus::ManualFire);
	if(Input.m_WantedWeapon && Input.m_WantedWeapon != WEAPON_LASER + 1)
		return Fail(ENLaserStatus::WeaponSwitch);
	// Rifle and a NEW hook share one protocol aim. Allow the user's hook to
	// launch first; a flying/grabbed/retracted held hook never blocks the search.
	if(Input.m_Hook && pOwner->Core()->m_HookState == HOOK_IDLE)
		return Fail(ENLaserStatus::HookStarting);
	const int64_t Deadline = time_get() + time_freq() * std::clamp(BudgetMs, 1, 20) / 1000;
	const int Zone = Source.m_WorldConfig.m_UseTuneZones ? Source.Collision()->IsTune(Source.Collision()->GetMapIndex(pOwner->GetPos())) : 0;
	const CTuningParams *pTune = Source.GetTuning(Zone);
	const float Reach = Source.GetTuning(pOwner->GetOverriddenTuneZone())->m_LaserReach;
	const int Bounces = std::clamp((int)(float)pTune->m_LaserBounceNum, 0, 8);
	const float DelayMs = pTune->m_LaserBounceDelay;
	if(Bounces == 0 || Reach <= 0.0f || DelayMs < 0.0f || DelayMs > 2000.0f)
		return Fail(ENLaserStatus::UnsupportedTuning);
	const int DelayTicks = (int)std::floor((float)SERVER_TICK_SPEED * DelayMs / 1000.0f) + 1;
	const int Horizon = std::min(96, DelayTicks * Bounces);
	const float MaxMiss = HitMargin > 0.0f ? std::clamp(HitMargin, 6.0f, Strict ? 12.0f : 20.0f) : (Strict ? 12.0f : 20.0f);
	ENLaserStatus LastReason = ENLaserStatus::NativeNoHit;
	auto Validate = [&](ivec2 Aim, int &ReturnTick) {
		// Verify the actual launch. A second hypothetical shot one tick later
		// was rejecting the last usable pre-freeze tick even on a local server.
		if(!Verify(Source, ClientId, Input, Aim, Reach, Horizon, Deadline, 0, MaxMiss, ReturnTick, Result, LastReason))
			return false;
		// The server may execute the same input one tick later (about 30% of shots
		// in a real log). Require the shot to also work with a 1 tick later launch.
		int LateReturn = 0; SLaserUnfreezeAim Late; ENLaserStatus LateReason = ENLaserStatus::NativeNoHit;
		if(Verify(Source, ClientId, Input, Aim, Reach, Horizon, Deadline, 1, MaxMiss, LateReturn, Late, LateReason))
			return true;
		// Last chance: next tick the character is already frozen, so waiting is pointless.
		if(LateReason == ENLaserStatus::AlreadyFrozen)
			return true;
		LastReason = LateReason == ENLaserStatus::BudgetExpired ? LateReason : ENLaserStatus::NativeLateTick;
		return false;
	};
	// A cached angle is never trusted blindly: it must pass fresh native checks.
	if(CachedAim.x != 0 || CachedAim.y != 0)
	{
		int ReturnTick;
		if(Validate(CachedAim, ReturnTick))
		{
			Result.m_Target = CachedAim; Result.m_ReturnTick = ReturnTick;
			if(pStatus) *pStatus = ENLaserStatus::ShotQueued;
			return true;
		}
	}
	std::vector<SFutureFrame> vFrames(Horizon + 1);
	bool FrozenSoon = false;
	{
		CGameWorld FutureWorld;
		SetupCopy(FutureWorld, Source);
		const CNetObj_PlayerInput FutureInput = QuietInput(Input);
		if(CCharacter *pFuture = FutureWorld.GetCharacterById(ClientId))
			pFuture->SetInput(&FutureInput);
		const int Start = FutureWorld.GameTick();
		vFrames[0] = {pOwner->GetPos(), false};
		for(int Step = 1; Step <= Horizon; ++Step)
		{
			if(time_get() >= Deadline)
				return Fail(ENLaserStatus::BudgetExpired);
			CCharacter *pFuture = FutureWorld.GetCharacterById(ClientId);
			if(!pFuture)
				return Fail(ENLaserStatus::HistoryUnavailable);
			// Laser entities tick before characters: use the PRE-tick position.
			vFrames[Step] = {pFuture->GetPos(), UsableFrozen(pFuture)};
			if(vFrames[Step].m_Frozen && !FrozenSoon && pFirstFrozenStep) *pFirstFrozenStep = Step;
			FrozenSoon |= vFrames[Step].m_Frozen;
			FutureWorld.m_GameTick = Start + Step;
			pFuture->OnPredictedInput(&FutureInput);
			FutureWorld.Tick();
		}
	}
	if(!FrozenSoon)
		return Fail(ENLaserStatus::NoFreezeAhead);
	Samples = std::clamp(Samples, 90, 1440);
	const float BaseAngle = std::atan2((float)Input.m_TargetY, (float)Input.m_TargetX);
	std::vector<SCandidate> vCandidates;
	// Reserve half of the remaining budget for verification, even on big maps.
	// The coarse sweep gets 70% of the geometry half, local refinement the rest.
	const int64_t GeometryStart = time_get();
	const int64_t GeometryHalf = (Deadline - GeometryStart) / 2;
	const int64_t CoarseDeadline = GeometryStart + GeometryHalf * 7 / 10;
	const int64_t GeometryDeadline = GeometryStart + GeometryHalf;
	// 0.8: a wider net than the real miss limit. A coarse (or time-truncated) angle
	// sweep can step over a narrow solution; local refinement then narrows it and the
	// native verification still enforces the true MaxMiss on every candidate.
	const float BaseRadius = std::min(pOwner->GetProximityRadius(), MaxMiss);
	const float NetRadius = std::min(BaseRadius * 2.0f, 48.0f);
	for(int Sample = 0; Sample < Samples; ++Sample)
	{
		if(time_get() >= CoarseDeadline)
			break;
		// Low-discrepancy order covers ALL directions early instead of stopping
		// after only a contiguous sector when the budget is small.
		unsigned Bits = (unsigned)Sample + 1;
		float Fraction = 0.0f, Weight = 0.5f;
		while(Bits) { Fraction += (Bits & 1u) * Weight; Bits >>= 1; Weight *= 0.5f; }
		const float Angle = BaseAngle + 2.0f * pi * Fraction;
		const ivec2 Aim = NAimFromAngle(Angle);
		const vec2 Dir = normalize(vec2(Aim.x, Aim.y));
		float Score;
		if(GeometryCandidate(Source.Collision(), pOwner->GetPos(), Dir, Reach, pTune->m_LaserBounceCost,
			Bounces, DelayTicks, NetRadius, vFrames, Score))
			vCandidates.push_back({Aim, Score});
	}
	std::sort(vCandidates.begin(), vCandidates.end(), [](const SCandidate &A, const SCandidate &B) { return A.m_Score < B.m_Score; });
	// Refine the best geometric candidates: shrink the angle step and keep any move
	// that lowers the geometric miss. Cheap compared to one native verification.
	for(size_t Index = 0; Index < std::min<size_t>(vCandidates.size(), 8); ++Index)
	{
		float Angle = std::atan2((float)vCandidates[Index].m_Target.y, (float)vCandidates[Index].m_Target.x);
		const float Best = RefineGeometryAngle(Source.Collision(), pOwner->GetPos(), Angle, vCandidates[Index].m_Score,
			Reach, pTune->m_LaserBounceCost, Bounces, DelayTicks, NetRadius, vFrames, GeometryDeadline);
		vCandidates[Index].m_Target = NAimFromAngle(Angle);
		vCandidates[Index].m_Score = Best;
	}
	std::sort(vCandidates.begin(), vCandidates.end(), [](const SCandidate &A, const SCandidate &B) { return A.m_Score < B.m_Score; });
	vCandidates.erase(std::unique(vCandidates.begin(), vCandidates.end(), [](const SCandidate &A, const SCandidate &B) { return A.m_Target == B.m_Target; }), vCandidates.end());
	for(size_t Index = 0; Index < std::min<size_t>(vCandidates.size(), 16); ++Index)
	{
		if(time_get() >= Deadline)
			return Fail(ENLaserStatus::BudgetExpired);
		int ReturnTick;
		if(Validate(vCandidates[Index].m_Target, ReturnTick))
		{
			Result.m_Target = vCandidates[Index].m_Target;
			Result.m_ReturnTick = ReturnTick;
			if(pStatus) *pStatus = ENLaserStatus::ShotQueued;
			return true;
		}
	}
	if(time_get() >= Deadline) return Fail(ENLaserStatus::BudgetExpired);
	return Fail(vCandidates.empty() ? ENLaserStatus::NoAngle : LastReason);
}


bool BuildNPredictionPath(CGameWorld &Source, int ClientId, const CNetObj_PlayerInput &Input,
	int Ticks, int BudgetMs, std::vector<SNPredictionPoint> &Path)
{
	Path.clear();
	if(!Source.Collision() || !Source.GetCharacterById(ClientId))
		return false;
	const int64_t Deadline = time_get() + time_freq() * std::clamp(BudgetMs, 1, 6) / 1000;
	CGameWorld Future;
	SetupCopy(Future, Source);
	CNetObj_PlayerInput Held = QuietInput(Input);
	CCharacter *pChar = Future.GetCharacterById(ClientId);
	pChar->SetInput(&Held);
	Ticks = std::clamp(Ticks, 8, 64);
	Path.reserve(Ticks + 1);
	Path.push_back({pChar->GetPos(), pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen});
	for(int Step = 0; Step < Ticks && time_get() < Deadline; ++Step)
	{
		pChar = Future.GetCharacterById(ClientId);
		if(!pChar)
			break;
		++Future.m_GameTick;
		pChar->OnPredictedInput(&Held);
		Future.Tick();
		pChar = Future.GetCharacterById(ClientId);
		if(!pChar)
			break;
		Path.push_back({pChar->GetPos(), pChar->m_FreezeTime != 0 || pChar->Core()->m_DeepFrozen || pChar->Core()->m_LiveFrozen});
	}
	return Path.size() > 1;
}

const char *NLaserStatusText(ENLaserStatus Status)
{
	static const char *apTexts[] = {
		"Отключено",
		"Отправка выстрела / отпускание огня",
		"Пауза: меню, чат или наблюдение",
		"Нужны cl_predict 1 и cl_predict_freeze 1",
		"Отключите специальные режимы dummy",
		"Ручной огонь имеет приоритет",
		"Нужен выбранный лазер с патронами",
		"Смена оружия",
		"Ожидание следующего тика поиска",
		"Недоступна история предикта",
		"Исчерпан CPU-бюджет поиска",
		"Лазер перезаряжается",
		"Уже заморожен: выстрел невозможен",
		"Не поддерживается режим карты / old laser",
		"Нет допустимых отражений лазера",
		"Нет freeze на прогнозируемом пути",
		"Не найден угол отражения",
		"Кандидаты не прошли проверку попадания",
		"Выстрел подготовлен",
		"Запуск нового хука: жду его вылета",
		"Super / invincible: проверка freeze недостоверна",
		"Жду серверное подтверждение прошлого выстрела",
		"Последний кандидат: лазер не разморозил владельца",
		"Последний кандидат: попадание без допустимого freeze",
		"Последний кандидат: попадание слишком далеко от центра",
		"Последний кандидат: повторный freeze после попадания",
		"Последний кандидат: недостаточно тиков без freeze",
		"Кандидат ломается при задержке сервера на 1 тик",
	};
	const int Index = (int)Status;
	return Index >= 0 && Index < (int)(sizeof(apTexts) / sizeof(apTexts[0])) ? apTexts[Index] : "Неизвестный статус";
}
