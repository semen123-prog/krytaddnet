from pathlib import Path
import tarfile,hashlib,json,difflib,base64,zlib,shutil,yaml
B=Path('/data/ddnet-laser-unfreeze');R=B/'ddnet-20.1';O=B/'v13/package';O.mkdir(parents=True,exist_ok=True)
old=json.loads((B/'package/manifest.json').read_text());names=list(old)+['scripts/git_revision.py',
 'src/game/client/components/n_client.h','src/game/client/components/n_client.cpp',
 'src/game/client/components/menus.h','src/game/client/components/menus_settings.cpp',
 'src/game/client/components/menus_settings_nclient.cpp','src/game/client/components/n_client_learning.h',
 'src/game/client/components/n_tas.h','src/game/client/components/n_tas.cpp','src/game/client/components/n_tas_core.h']
manifest={};diff=[]
with tarfile.open(B/'ddnet-20.1.tar.gz') as t:
 for name in names:
  try:before=t.extractfile('ddnet-20.1/'+name).read()
  except KeyError:before=b''
  after=(R/name).read_bytes();out=O/'patched_files'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(after)
  manifest[name]={'original_sha256':hashlib.sha256(before).hexdigest() if before else None,'new_sha256':hashlib.sha256(after).hexdigest()}
  diff.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
patch=''.join(diff).encode();(O/'n-client-1.3.patch').write_bytes(patch);(O/'manifest.json').write_text(json.dumps(manifest,indent=2))
for name in ['apply_patch.py','LICENSE_DDNET.txt','test_input.cpp']:shutil.copy2(B/'package'/name,O/name)
shutil.copy2(B/'test_geometry08.cpp',O/'test_geometry.cpp')
payload=base64.b64encode(zlib.compress(patch,9)).decode()
original=(B/'research/build-windows-v01.yml').read_text()
import re
workflow=re.sub(r'payload = "[A-Za-z0-9+/=]+"','payload = "'+payload+'"',original)
workflow=workflow.replace('Build DDNet Laser Assist','Build n-client 1.3').replace("ref: '20.1'","ref: 'c9d208138f85755521f16a0096b6fe036c5c8698'")
workflow=workflow.replace('Patched official DDNet 20.1. Assist is disabled by default.','n-client 1.3 patched onto DDNet 20.1. Movement preview and strict validation are available in Settings.')
workflow=workflow.replace('DDNet-LaserAssist-win64','n-client-1.3-win64').replace('Experimental DDNet 20.1 Laser Assist for Windows x64.','Experimental n-client 1.3 based on official DDNet 20.1, Windows x64.').replace('Assist is disabled by default. F1: cl_laser_auto_unfreeze 1','Open Settings -> n-client to toggle features. Strict validation and movement preview default to ON.').replace('README-LaserAssist.txt','README-n-client.txt')
config=yaml.load(workflow,Loader=yaml.BaseLoader);assert config['name']=='Build n-client 1.3';assert 'workflow_dispatch' in config['on']
embedded=re.search('payload = "([A-Za-z0-9+/=]+)"',workflow).group(1);assert zlib.decompress(base64.b64decode(embedded))==patch
assert '\u200b' not in workflow
(O/'build-nclient-13.yml').write_text(workflow);print('Files',len(manifest),'patch bytes',len(patch),'standalone workflow bytes',len(workflow.encode()))

p=O/'build-nclient-13.yml'
s=p.read_text().replace('Equip rifle. Manual fire, hook, deep/live freeze and special dummy modes take priority.', 'Equip rifle. Held hook, jump and direction are predicted. TAS record/replay (no address filter) lives in Settings -> n-client -> TAS. Manual fire still takes priority. New hooks launch before auto aim. Status explains rejected shots.')
p.write_text(s)

for name in ['test_hook.cpp','test_learning.cpp','test_tas.cpp']:shutil.copy2(B/name,O/name)
p=O/'build-nclient-13.yml'
s=p.read_text().replace('This is a prediction-based prototype, not a guarantee of unfreezing.', 'Local session-only feedback calibrates server shot timing. It is not a neural network or a guarantee of unfreezing. Numeric feedback is saved locally to nclient-feedback-08.csv when enabled; no upload. Disable super/invincible for testing.')
p.write_text(s)
