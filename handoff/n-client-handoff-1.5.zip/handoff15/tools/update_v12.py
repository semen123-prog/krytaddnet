from pathlib import Path
B=Path('/data/ddnet-laser-unfreeze');R=B/'ddnet-20.1'
p=R/'scripts/git_revision.py';s=p.read_text();assert '"--short=16"' in s;s=s.replace('"--short=16"','"--verify"');p.write_text(s)
p=R/'src/game/client/components/menus_settings_nclient.cpp';s=p.read_text().replace('n-client 1.1','n-client 1.2');p.write_text(s)
s=(B/'package_v11.py').read_text().replace('v11/package','v12/package').replace('1.1','1.2').replace('build-nclient-11','build-nclient-12').replace("names=list(old)+[","names=list(old)+['scripts/git_revision.py',")
(B/'package_v12.py').write_text(s)
