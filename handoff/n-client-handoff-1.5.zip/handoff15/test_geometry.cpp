// This tests the real broad-phase code using a synthetic single-wall collision
// implementation. It is NOT a native map/physics integration test.
#include <cassert>
#include <iostream>
#include "laser_unfreeze.cpp"
#include <chrono>
int64_t time_get(){return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count()*time_freq()/1000000000LL;}
static float Wall = 100.0f;
CCollision::CCollision() {}
CCollision::~CCollision() {}
int CCollision::IntersectLineTeleWeapon(vec2 A,vec2 B,vec2 *Col,vec2 *Before,int *) const
{
 if(B.x>A.x && A.x<Wall && B.x>=Wall)
 {
  float T=(Wall-A.x)/(B.x-A.x);*Col=A+(B-A)*T;*Before=*Col;Before->x-=0.001f;return TILE_SOLID;
 }
 *Col=*Before=B;return 0;
}
void CCollision::MovePoint(vec2 *Pos,vec2 *Dir,float,int *) const {if(Pos->x+Dir->x>=Wall)Dir->x=-Dir->x;else *Pos+=*Dir;}
int CCollision::GetTile(int,int) const{return TILE_SOLID;}
void CCollision::SetCollisionAt(float,float,int){}
int main()
{
 CCollision Col;std::vector<SFutureFrame> Frames(33,{vec2(0,0),false});Frames[8].m_Frozen=true;float Score;
 assert(GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,28,Frames,Score));
 assert(!GeometryCandidate(&Col,vec2(0,0),vec2(-1,0),800,0,1,8,28,Frames,Score));
 assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),150,0,1,8,28,Frames,Score));
 assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,0,8,28,Frames,Score));
 Frames[8].m_Frozen=false;assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,28,Frames,Score));
 Frames[8]={vec2(50,0),true};assert(GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,28,Frames,Score));
 Frames[8]={vec2(0,40),true};assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,28,Frames,Score));
 Frames.resize(8);assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,28,Frames,Score));
 Frames.resize(33,{vec2(0,0),false});Frames[8]={vec2(0,14),true};
 assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,12,Frames,Score));
 assert(GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,8,20,Frames,Score));
 Frames[8]={vec2(0,0),true};
 assert(!GeometryCandidate(&Col,vec2(0,0),vec2(1,0),800,0,1,9,28,Frames,Score));
 std::cout<<"Geometry filter: 11 synthetic-wall/timing/margin cases OK\n";
 // 0.8 refinement: a coarse angle that is off by ~6 px must converge to the exact angle.
 Frames[8]={vec2(0,14),true};
 const float Exact=std::atan(14.0f/200.0f);
 int Refined=0;
 for(float Start=Exact-0.02f; Start<=Exact+0.02f; Start+=0.004f)
 {
  float Angle=Start,S0;
  const ivec2 A0=NAimFromAngle(Start);
  if(!GeometryCandidate(&Col,vec2(0,0),normalize(vec2(A0.x,A0.y)),800,0,1,8,24,Frames,S0)) continue;
  const float S1=RefineGeometryAngle(&Col,vec2(0,0),Angle,S0,800,0,1,8,24,Frames,time_get()+time_freq());
  assert(S1<=S0+1e-4f);
  assert(std::fabs(Angle-Exact)<0.003f);
  ++Refined;
 }
 assert(Refined>=10);
 // An expired deadline must not move the angle.
 {float Angle=Exact+0.03f,S0;const ivec2 A0=NAimFromAngle(Angle);
  assert(GeometryCandidate(&Col,vec2(0,0),normalize(vec2(A0.x,A0.y)),800,0,1,8,24,Frames,S0));
  const float S1=RefineGeometryAngle(&Col,vec2(0,0),Angle,S0,800,0,1,8,24,Frames,time_get()-1);
  assert(S1==S0&&std::fabs(Angle-(Exact+0.03f))<1e-6f);}
 std::cout<<"Refinement: "<<Refined<<" synthetic start angles converge, expired deadline is a no-op OK\n";
}
