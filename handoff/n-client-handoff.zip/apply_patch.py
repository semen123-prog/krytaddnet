"""Install checked file replacements into an unmodified DDNet 20.1 source tree.
Usage: python apply_patch.py PATH_TO_DDNET_SOURCE
No network access, compilation or executable downloads are performed.
"""
import hashlib,json,sys,os
from pathlib import Path
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)==2 else None
PACKAGE=Path(__file__).resolve().parent
if ROOT is None:raise SystemExit('Usage: python apply_patch.py PATH_TO_DDNET_20_1_SOURCE')
manifest=json.loads((PACKAGE/'manifest.json').read_text())
changes=[]
for name,info in manifest.items():
 target=ROOT/name;replacement=PACKAGE/'patched_files'/name
 if not target.resolve().is_relative_to(ROOT):raise SystemExit('Unsafe path')
 data=replacement.read_bytes()
 if hashlib.sha256(data).hexdigest()!=info['new_sha256']:raise SystemExit('Corrupted replacement: '+name)
 original=target.read_bytes() if target.exists() else None
 normalized=original.replace(b'\r\n',b'\n') if original is not None else None
 digest=hashlib.sha256(normalized).hexdigest() if normalized is not None else None
 if digest==info['new_sha256']:continue
 if digest!=info['original_sha256']:raise SystemExit('Source version mismatch or local edit: '+name+'\nExpected clean DDNet 20.1. No files changed.')
 changes.append((target,original,data))
backup=ROOT/'laser-unfreeze-backup';backup.mkdir(exist_ok=True)
written=[]
try:
 for target,original,data in changes:
  target.parent.mkdir(parents=True,exist_ok=True)
  relative=target.relative_to(ROOT)
  if original is not None:
   b=backup/relative;b.parent.mkdir(parents=True,exist_ok=True)
   if b.exists() and b.read_bytes()!=original:raise RuntimeError('Backup already exists with different contents: '+str(b))
   b.write_bytes(original)
  tmp=target.with_name(target.name+'.laser-tmp');tmp.write_bytes(data);os.replace(tmp,target);written.append((target,original))
except Exception:
 for target,original in reversed(written):
  if original is None:target.unlink(missing_ok=True)
  else:target.write_bytes(original)
 raise
print(f'Applied {len(changes)} file replacements. Original files backed up in laser-unfreeze-backup.')
