from pathlib import Path
import re,csv,io,json,collections,math
import pandas as pd
src=Path('/data/.agent-service/files/ccd7af4c-db47-4323-8def-81362504c47f/tool-result').read_text()
src=src[src.index('session,epoch,slot,event,'):].replace('\\_','_')
parts=re.split(r'<br\s*/?>',src)
lines=[p.strip() for p in parts if p.strip() and (p.startswith('session,') or re.match(r'^\d+,\d+,',p.strip()))]
raw='\n'.join(lines)+'\n';Path('/data/raw/nclient-feedback-user.csv').write_text(raw)
rows=list(csv.DictReader(io.StringIO(raw)));assert all(None not in r and len(r)==22 for r in rows)
df=pd.DataFrame(rows)
for c in df.columns:
 if c!='event':df[c]=pd.to_numeric(df[c],errors='raise')
keys=['session','epoch','slot','base_launch_tick']
sent=df[df.event=='sent'];terminal=df[df.event.isin(['ambiguous_result','still_frozen','no_attack_ack','superseded','early_thaw_observed'])]
assert not sent.duplicated(keys).any();assert not terminal.duplicated(keys).any()
assert len(sent)==len(terminal)
acks=df[df.event=='attack_observed'].copy();acks['delta']=acks.attack_tick-acks.base_launch_tick
samples=df[df.event=='position_sample'].copy()
# Independent arithmetic and counts from raw stdlib records.
assert len(sent)==sum(r['event']=='sent' for r in rows)
assert terminal.event.value_counts().to_dict()==dict(collections.Counter(r['event'] for r in rows if r['event'] in set(terminal.event)))
for r in rows:
 if int(r['has_prediction']):assert abs(math.hypot(float(r['observed_x'])-float(r['predicted_x']),float(r['observed_y'])-float(r['predicted_y']))-float(r['position_error']))<.001
amb=terminal[terminal.event=='ambiguous_result']
first=samples[(samples.epoch==8)&(samples.base_launch_tick==306)]
repeats=terminal[terminal.event=='superseded'][keys+['snapshot_tick']].to_dict('records')
new_acks=acks[acks.delta<0][keys+['attack_tick','delta']].to_dict('records')
out={
 'provenance':{'source':'User pasted CSV in session event 1016','normalization':'Markdown escaped underscores removed, <br /> converted to line breaks; no data rows dropped','grain':'One event or position sample, NOT one shot per row','row_count':len(rows),'columns':22,'duplicate_rows':int(df.duplicated().sum())},
 'attempts':len(sent),'outcomes':terminal.event.value_counts().to_dict(),
 'ambiguous':{'total':len(amb),'input_changed':int((amb.input_changed==1).sum()),'manual':int((amb.manual==1).sum()),'external':int((amb.external_influence==1).sum())},
 'ack_count':len(acks),'ack_delta_distribution':acks.delta.value_counts().sort_index().to_dict(),
 'superseded':repeats,'negative_delta_acks':new_acks,
 'first_attempt':{'base_tick':306,'attack_tick':307,'first_position_error':float(first.iloc[0].position_error),'last_position_error':float(first.iloc[-1].position_error),'last_sample_tick':int(first.iloc[-1].snapshot_tick),'input_changed':bool(first.input_changed.any()),'terminal':'still_frozen'},
 'samples':{'count':len(samples),'zero_error_count':int((samples.position_error==0).sum())},
 'phase_applied_values':sorted(df.phase.unique().tolist()),
 'comparison_plan':[{'grain':'attempt','population':'All pasted attempts','disposition':'prose','reason':'Causal debugging; metadata outcomes are not confirmed hits/misses and a compact statement suffices.'}, {'grain':'position sample','population':'First unchanged-input attempt','disposition':'prose','reason':'Single diagnostic residual plus attack tick identifies timing hypothesis; not a request for a broad trend report.'}],
 'limitations':['No CPU timings/FPS in log','InputChanged combines mouse, keys and weapon changes; cause is not recorded','phase=0 does not reveal whether learning was disabled','No launch-origin snapshot or authoritative self-laser hit event','AttackObserved may belong to an older auto-pulse when feedback was superseded']
}
Path('/data/analysis/nclient-feedback-evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:out[k] for k in ['provenance','attempts','outcomes','ambiguous','ack_delta_distribution','first_attempt','samples','phase_applied_values']},ensure_ascii=False,indent=2))
