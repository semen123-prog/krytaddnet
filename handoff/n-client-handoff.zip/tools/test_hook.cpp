#include <game/client/components/laser_unfreeze_input.h>
#include <game/client/components/laser_unfreeze.h>
#include <cassert>
#include <iostream>
int main() {
 int N=0;
 for(int Hook=0; Hook<2; ++Hook) for(int Dir=-1; Dir<=1; ++Dir)
 for(int Jump=0; Jump<2; ++Jump) for(int Counter=0; Counter<=INPUT_STATE_MASK; Counter+=2) {
  CNetObj_PlayerInput Held{}; Held.m_Hook=Hook; Held.m_Direction=Dir;
  Held.m_Jump=Jump; Held.m_TargetX=123; Held.m_TargetY=-456; Held.m_Fire=Counter;
  CLaserUnfreezeInput Queue; assert(Queue.Queue(-900,300));
  auto Wire=Held; Queue.Finalize(Wire);
  assert(Wire.m_TargetX==-900 && Wire.m_TargetY==300);
  assert(Wire.m_Hook==Hook && Wire.m_Direction==Dir && Wire.m_Jump==Jump);
  assert(Wire.m_Fire & 1);
  auto Released=Held; Queue.Finalize(Released);
  assert(Released.m_TargetX==123 && Released.m_TargetY==-456);
  assert(Released.m_Hook==Hook && Released.m_Direction==Dir && Released.m_Jump==Jump);
  assert(!(Released.m_Fire&1));
  for(int Step=0; Step<=64; ++Step) {
   auto Forecast=NLaserShotStepInput(Held,ivec2(-900,300),Step);
   assert(Forecast.m_Hook==Hook && Forecast.m_Direction==Dir && Forecast.m_Jump==Jump);
   assert(Forecast.m_TargetX==(Step==1 ? -900 : 123));
   assert(Forecast.m_TargetY==(Step==1 ? 300 : -456));
   ++N;
  }
 }
 // Distribution covers every quadrant in the first eight samples.
 bool Q[4]{};
 for(unsigned Sample=0; Sample<8; ++Sample) {
  unsigned Bits=Sample+1; float F=0, W=.5f;
  while(Bits){F+=(Bits&1u)*W;Bits>>=1;W*=.5f;}
  Q[(int)(4*F)]=true;
 }
 assert(Q[0] && Q[1] && Q[2] && Q[3]);
 std::cout << "Hook / movement preservation and shot-aim restoration: " << N << " assertions groups PASS\n";
}
