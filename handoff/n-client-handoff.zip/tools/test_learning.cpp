#include <game/client/components/n_client_learning.h>
#include <game/client/components/laser_unfreeze_input.h>
#include <cassert>
#include <iostream>
#include <random>
int main()
{
 for(int Mask=0;Mask<8;++Mask)
  assert(NFeedbackAwaitingAck(Mask&1,Mask&2,(Mask&4)?123:-1) == ((Mask&1) && (Mask&2) && !(Mask&4)));
 CNClientLearning L;
 assert(L.Phase()==0 && L.Samples()==0);
 assert(!L.ObservePhase(-3) && !L.ObservePhase(4));
 for(int i=0;i<3;++i){assert(L.ObservePhase(1));assert(L.Phase()==0);}
 assert(L.ObservePhase(1));assert(L.Phase()==1);
 for(int i=0;i<16;++i)L.ObservePhase(2);assert(L.Phase()==2 && L.Samples()==16);
 L.Reset();for(int i=0;i<4;++i)L.ObservePhase(i%2 ? -2 : 3);assert(L.Phase()==0);
 L.Reset();for(int i=0;i<4;++i)L.ObservePhase(-1);assert(L.Phase()==-1);
 L.Reset();for(int i=0;i<100;++i){L.SearchTimeout();L.NoAngle();L.FrozenObserved();}
 assert(L.Budget(8)==8 && L.Angles(960)==960 && L.HitMargin(true)==6);
 for(int i=0;i<100;++i)L.ThawObserved();assert(L.HitMargin(true)==12);
 L.PositionError(20);assert(L.HitMargin(true)==8);
 L.PositionError(-1);L.PositionError(1000);assert(L.m_PositionError==20);
 L.Reset();assert(L.Budget(3)==3 && L.Angles(720)==720 && L.m_Unknown==0 && L.m_PositionError<0);
 int Outcomes=0;
 for(int Mask=0;Mask<64;++Mask)
 {
  const bool Changed=Mask&1, Manual=Mask&2, External=Mask&4, Freeze=Mask&8, Thaw=Mask&16, Frozen=Mask&32;
  auto O=NFeedbackOutcome(Changed,Manual,External,Freeze,Thaw,Frozen);
  if(Changed || Manual || External || !Freeze) assert(O==ENFeedbackOutcome::Unknown);
  else if(Frozen) assert(O==ENFeedbackOutcome::StillFrozen);
  else if(Thaw) assert(O==ENFeedbackOutcome::EarlyThaw);
  else assert(O==ENFeedbackOutcome::Unknown);
  ++Outcomes;
 }
 std::mt19937 Rng(4412);
 for(int i=0;i<10000;++i)
 {
  L.ObservePhase((int)(Rng()%40)-20);
  if(Rng()%2)L.SearchTimeout();else L.NoAngle();
  if(Rng()%2)L.FrozenObserved();else L.ThawObserved();
  assert(L.Phase()>=-2 && L.Phase()<=3);
  assert(L.Budget(2)==2 && L.Budget(12)==12 && L.Budget(3)==3);
  assert(L.Angles(180)==180 && L.Angles(1440)==1440 && L.Angles(500)==500);
  assert(L.HitMargin(true)>=6 && L.HitMargin(true)<=12);
 }
 CLaserUnfreezeInput Queue;CNetObj_PlayerInput I{};
 assert(Queue.Queue(400,200) && Queue.IsQueued());assert(Queue.Finalize(I));assert(!Queue.IsQueued());
 I.m_Fire=0;assert(!Queue.Finalize(I));assert(!Queue.NeedsSend());
 assert(Queue.Queue(300,200));I.m_Fire=1;assert(!Queue.Finalize(I));assert(!Queue.NeedsSend());
 std::cout<<"Learning: phase calibration, outliers, reset, "<<Outcomes<<" outcome masks, 10000 bounded updates and manual cancellation PASS\n";
}
