/* (c) Magnus Auvinen. See licence.txt in the root of the distribution for more information. */
/* If you are missing that file, acquire a complete release at teeworlds.com.                */
#ifndef GAME_CLIENT_COMPONENTS_CONTROLS_H
#define GAME_CLIENT_COMPONENTS_CONTROLS_H

#include <base/vmath.h>
#include <string>

#include <engine/client.h>
#include <engine/console.h>

#include <generated/protocol.h>

#include <game/client/component.h>
#include "laser_unfreeze_input.h"
#include "laser_unfreeze.h"
#include "n_client_learning.h"

class CGameWorld;

class CControls : public CComponent
{
public:
	float GetMinMouseDistance() const;
	float GetMaxMouseDistance() const;

	enum class EMouseInputType
	{
		ABSOLUTE,
		RELATIVE,
		AUTOMATED,
	};

	vec2 m_aMousePos[NUM_DUMMIES];
	vec2 m_aMousePosOnAction[NUM_DUMMIES];
	vec2 m_aTargetPos[NUM_DUMMIES];

	EMouseInputType m_aMouseInputType[NUM_DUMMIES];

	int m_aAmmoCount[NUM_WEAPONS];

	int64_t m_LastSendTime;
	CNetObj_PlayerInput m_aInputData[NUM_DUMMIES];
	CNetObj_PlayerInput m_aLastData[NUM_DUMMIES];
	int m_aInputDirectionLeft[NUM_DUMMIES];
	int m_aInputDirectionRight[NUM_DUMMIES];
	int m_aShowHookColl[NUM_DUMMIES];

	CControls();
	int Sizeof() const override { return sizeof(*this); }

	void OnReset() override;
	void OnRender() override;
	void OnShutdown() override;
	void OnNewSnapshot() override;
	void OnMapLoad() override;
	void OnMessage(int MsgType, void *pRawMsg) override;
	bool OnCursorMove(float x, float y, IInput::ECursorType CursorType) override;
	void OnConsoleInit() override;
	virtual void OnPlayerDeath();

	int SnapInput(int *pData);
	void ResetLaserConnection(int Connection)
	{
		m_aLaserInput[Connection].Reset();
		m_aLaserLastSolveTick[Connection] = -1;
		m_aLaserStatus[Connection] = ENLaserStatus::Disabled;
		m_aLaserCachedAim[Connection] = ivec2(0, 0);
		++m_aFeedbackEpoch[Connection];
		m_aLearning[Connection].Reset();
		m_aFeedback[Connection] = SShotFeedback();
	}
	bool LaserNeedsSend(int Connection) const { return m_aLaserInput[Connection].NeedsSend(); }
	void FinalizeLaserInput(CNetObj_PlayerInput &Input, int Connection);
	void ResetNLearning();
	const CNClientLearning &NLearning(int Slot) const { return m_aLearning[Slot]; }
	CNetObj_PlayerInput NClientHeldInput(int Slot) const;
	ENLaserStatus NLaserStatus(int Slot) const { return m_aLaserStatus[Slot]; }
	void ClampMousePos();
	void ResetInput(int Dummy);

private:
	struct SShotFeedback
	{
		bool m_Active = false, m_Committed = false, m_InputChanged = false, m_Manual = false;
		bool m_SawFreeze = false, m_ThawObserved = false, m_PhaseObserved = false, m_ExternalInfluence = false;
		int m_Id = -1, m_BaseTick = 0, m_AttackTick = -1, m_PreviousAttack = -1;
		int m_LastSnap = -1, m_PreviousFreezeEnd = 0, m_AppliedPhase = 0;
		CNetObj_PlayerInput m_Held{};
		SLaserUnfreezeAim m_Aim;
	};
	int64_t m_FeedbackSession = 0;
	std::string m_FeedbackBuffer;
	int64_t m_LastFeedbackFlush = 0;
	void FlushNFeedback(bool Force = false);
	int m_aFeedbackEpoch[NUM_DUMMIES]{};
	CNClientLearning m_aLearning[NUM_DUMMIES];
	SShotFeedback m_aFeedback[NUM_DUMMIES];
	void ObserveNInput(int Slot, const CNetObj_PlayerInput &Held);
	void NFeedbackLog(int Slot, const char *pEvent, int SnapTick, vec2 Observed = vec2(0, 0));
	void FinishNFeedback(int Slot, const char *pEvent, int SnapTick);
	CLaserUnfreezeInput m_aLaserInput[NUM_DUMMIES];
	ENLaserStatus m_aLaserStatus[NUM_DUMMIES]{};
	int m_aLaserLastSolveTick[NUM_DUMMIES]{};
	ivec2 m_aLaserCachedAim[NUM_DUMMIES]{};
	CNetObj_PlayerInput m_aLaserSearchInput[NUM_DUMMIES]{};
	bool BuildLaserShotWorld(CGameWorld &World, int Slot, int64_t Deadline, int Phase);
	bool MaybeLaserAutoUnfreeze();
	static void ConKeyInputState(IConsole::IResult *pResult, void *pUserData);
	static void ConKeyInputCounter(IConsole::IResult *pResult, void *pUserData);
	static void ConKeyInputSet(IConsole::IResult *pResult, void *pUserData);
	static void ConKeyInputNextPrevWeapon(IConsole::IResult *pResult, void *pUserData);
};
#endif
