/* (c) Magnus Auvinen. See licence.txt in the root of the distribution for more information. */
/* If you are missing that file, acquire a complete release at teeworlds.com.                */
#include "controls.h"
#include "laser_unfreeze.h"
#include <game/client/prediction/entities/character.h>

#include <base/dbg.h>
#include <base/io.h>
#include <base/str.h>
#include <engine/storage.h>
#include <base/mem.h>
#include <base/time.h>
#include <base/vmath.h>

#include <engine/client.h>
#include <engine/shared/config.h>

#include <generated/protocol.h>

#include <game/client/components/camera.h>
#include <game/client/components/chat.h>
#include <game/client/components/menus.h>
#include <game/client/components/scoreboard.h>
#include <game/client/gameclient.h>
#include <game/collision.h>

#include <algorithm>

CControls::CControls()
{
	m_FeedbackSession = time_timestamp();
	mem_zero(&m_aLastData, sizeof(m_aLastData));
	std::fill(std::begin(m_aMousePos), std::end(m_aMousePos), vec2(0.0f, 0.0f));
	std::fill(std::begin(m_aMousePosOnAction), std::end(m_aMousePosOnAction), vec2(0.0f, 0.0f));
	std::fill(std::begin(m_aTargetPos), std::end(m_aTargetPos), vec2(0.0f, 0.0f));
	std::fill(std::begin(m_aMouseInputType), std::end(m_aMouseInputType), EMouseInputType::ABSOLUTE);
}

void CControls::OnReset()
{
	ResetInput(0);
	ResetInput(1);

	std::fill(std::begin(m_aAmmoCount), std::end(m_aAmmoCount), 0);

	m_LastSendTime = 0;
	for(int Slot = 0; Slot < NUM_DUMMIES; ++Slot)
	{
		ResetLaserConnection(Slot);
	}
}

void CControls::ResetInput(int Dummy)
{
	m_aLastData[Dummy].m_Direction = 0;
	// simulate releasing the fire button
	if((m_aLastData[Dummy].m_Fire & 1) != 0)
		m_aLastData[Dummy].m_Fire++;
	m_aLastData[Dummy].m_Fire &= INPUT_STATE_MASK;
	m_aLastData[Dummy].m_Jump = 0;
	m_aInputData[Dummy] = m_aLastData[Dummy];

	m_aInputDirectionLeft[Dummy] = 0;
	m_aInputDirectionRight[Dummy] = 0;
}

void CControls::OnPlayerDeath()
{
	std::fill(std::begin(m_aAmmoCount), std::end(m_aAmmoCount), 0);
}

struct CInputState
{
	CControls *m_pControls;
	int *m_apVariables[NUM_DUMMIES];
};

void CControls::ConKeyInputState(IConsole::IResult *pResult, void *pUserData)
{
	CInputState *pState = (CInputState *)pUserData;

	if(pState->m_pControls->GameClient()->m_GameInfo.m_BugDDRaceInput && pState->m_pControls->GameClient()->m_Snap.m_SpecInfo.m_Active)
		return;

	*pState->m_apVariables[g_Config.m_ClDummy] = pResult->GetInteger(0);
}

void CControls::ConKeyInputCounter(IConsole::IResult *pResult, void *pUserData)
{
	CInputState *pState = (CInputState *)pUserData;

	if((pState->m_pControls->GameClient()->m_GameInfo.m_BugDDRaceInput && pState->m_pControls->GameClient()->m_Snap.m_SpecInfo.m_Active) || pState->m_pControls->GameClient()->m_Spectator.IsActive())
		return;

	int *pVariable = pState->m_apVariables[g_Config.m_ClDummy];
	if(((*pVariable) & 1) != pResult->GetInteger(0))
		(*pVariable)++;
	*pVariable &= INPUT_STATE_MASK;
}

struct CInputSet
{
	CControls *m_pControls;
	int *m_apVariables[NUM_DUMMIES];
	int m_Value;
};

void CControls::ConKeyInputSet(IConsole::IResult *pResult, void *pUserData)
{
	CInputSet *pSet = (CInputSet *)pUserData;
	if(pResult->GetInteger(0))
	{
		*pSet->m_apVariables[g_Config.m_ClDummy] = pSet->m_Value;
	}
}

void CControls::ConKeyInputNextPrevWeapon(IConsole::IResult *pResult, void *pUserData)
{
	CInputSet *pSet = (CInputSet *)pUserData;
	ConKeyInputCounter(pResult, pSet);
	pSet->m_pControls->m_aInputData[g_Config.m_ClDummy].m_WantedWeapon = 0;
}

void CControls::OnConsoleInit()
{
	// game commands
	{
		static CInputState s_State = {this, {&m_aInputDirectionLeft[0], &m_aInputDirectionLeft[1]}};
		Console()->Register("+left", "", CFGFLAG_CLIENT, ConKeyInputState, &s_State, "Move left");
	}
	{
		static CInputState s_State = {this, {&m_aInputDirectionRight[0], &m_aInputDirectionRight[1]}};
		Console()->Register("+right", "", CFGFLAG_CLIENT, ConKeyInputState, &s_State, "Move right");
	}
	{
		static CInputState s_State = {this, {&m_aInputData[0].m_Jump, &m_aInputData[1].m_Jump}};
		Console()->Register("+jump", "", CFGFLAG_CLIENT, ConKeyInputState, &s_State, "Jump");
	}
	{
		static CInputState s_State = {this, {&m_aInputData[0].m_Hook, &m_aInputData[1].m_Hook}};
		Console()->Register("+hook", "", CFGFLAG_CLIENT, ConKeyInputState, &s_State, "Hook");
	}
	{
		static CInputState s_State = {this, {&m_aInputData[0].m_Fire, &m_aInputData[1].m_Fire}};
		Console()->Register("+fire", "", CFGFLAG_CLIENT, ConKeyInputCounter, &s_State, "Fire");
	}
	{
		static CInputState s_State = {this, {&m_aShowHookColl[0], &m_aShowHookColl[1]}};
		Console()->Register("+showhookcoll", "", CFGFLAG_CLIENT, ConKeyInputState, &s_State, "Show Hook Collision");
	}

	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_WantedWeapon, &m_aInputData[1].m_WantedWeapon}, 1};
		Console()->Register("+weapon1", "", CFGFLAG_CLIENT, ConKeyInputSet, &s_Set, "Switch to hammer");
	}
	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_WantedWeapon, &m_aInputData[1].m_WantedWeapon}, 2};
		Console()->Register("+weapon2", "", CFGFLAG_CLIENT, ConKeyInputSet, &s_Set, "Switch to gun");
	}
	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_WantedWeapon, &m_aInputData[1].m_WantedWeapon}, 3};
		Console()->Register("+weapon3", "", CFGFLAG_CLIENT, ConKeyInputSet, &s_Set, "Switch to shotgun");
	}
	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_WantedWeapon, &m_aInputData[1].m_WantedWeapon}, 4};
		Console()->Register("+weapon4", "", CFGFLAG_CLIENT, ConKeyInputSet, &s_Set, "Switch to grenade");
	}
	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_WantedWeapon, &m_aInputData[1].m_WantedWeapon}, 5};
		Console()->Register("+weapon5", "", CFGFLAG_CLIENT, ConKeyInputSet, &s_Set, "Switch to laser");
	}

	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_NextWeapon, &m_aInputData[1].m_NextWeapon}, 0};
		Console()->Register("+nextweapon", "", CFGFLAG_CLIENT, ConKeyInputNextPrevWeapon, &s_Set, "Switch to next weapon");
	}
	{
		static CInputSet s_Set = {this, {&m_aInputData[0].m_PrevWeapon, &m_aInputData[1].m_PrevWeapon}, 0};
		Console()->Register("+prevweapon", "", CFGFLAG_CLIENT, ConKeyInputNextPrevWeapon, &s_Set, "Switch to previous weapon");
	}
}

void CControls::OnMessage(int Msg, void *pRawMsg)
{
	if(Msg == NETMSGTYPE_SV_WEAPONPICKUP)
	{
		CNetMsg_Sv_WeaponPickup *pMsg = (CNetMsg_Sv_WeaponPickup *)pRawMsg;
		if(g_Config.m_ClAutoswitchWeapons)
			m_aInputData[g_Config.m_ClDummy].m_WantedWeapon = pMsg->m_Weapon + 1;
		// We don't really know ammo count, until we'll switch to that weapon, but any non-zero count will suffice here
		m_aAmmoCount[std::max(0, pMsg->m_Weapon % NUM_WEAPONS)] = 10;
	}
}

int CControls::SnapInput(int *pData)
{
	// update player state
	if(GameClient()->m_Chat.IsActive())
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags = PLAYERFLAG_CHATTING;
	else if(GameClient()->m_Menus.IsActive())
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags = PLAYERFLAG_IN_MENU;
	else
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags = PLAYERFLAG_PLAYING;

	if(GameClient()->m_Scoreboard.IsActive())
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags |= PLAYERFLAG_SCOREBOARD;

	if(Client()->ServerCapAnyPlayerFlag() && GameClient()->m_Controls.m_aShowHookColl[g_Config.m_ClDummy])
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags |= PLAYERFLAG_AIM;

	if(Client()->ServerCapAnyPlayerFlag() && GameClient()->m_Camera.CamType() == CCamera::CAMTYPE_SPEC)
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags |= PLAYERFLAG_SPEC_CAM;

	switch(m_aMouseInputType[g_Config.m_ClDummy])
	{
	case CControls::EMouseInputType::AUTOMATED:
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags |= PLAYERFLAG_INPUT_ABSOLUTE;
		break;
	case CControls::EMouseInputType::ABSOLUTE:
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags |= PLAYERFLAG_INPUT_ABSOLUTE | PLAYERFLAG_INPUT_MANUAL;
		break;
	case CControls::EMouseInputType::RELATIVE:
		m_aInputData[g_Config.m_ClDummy].m_PlayerFlags |= PLAYERFLAG_INPUT_MANUAL;
		break;
	}

	bool Send = m_aLastData[g_Config.m_ClDummy].m_PlayerFlags != m_aInputData[g_Config.m_ClDummy].m_PlayerFlags;

	m_aLastData[g_Config.m_ClDummy].m_PlayerFlags = m_aInputData[g_Config.m_ClDummy].m_PlayerFlags;

	// we freeze the input if chat or menu is activated
	if(!(m_aInputData[g_Config.m_ClDummy].m_PlayerFlags & PLAYERFLAG_PLAYING))
	{
		if(!GameClient()->m_GameInfo.m_BugDDRaceInput)
			ResetInput(g_Config.m_ClDummy);

		mem_copy(pData, &m_aInputData[g_Config.m_ClDummy], sizeof(m_aInputData[0]));

		// set the target anyway though so that we can keep seeing our surroundings,
		// even if chat or menu are activated
		m_aInputData[g_Config.m_ClDummy].m_TargetX = (int)m_aMousePos[g_Config.m_ClDummy].x;
		m_aInputData[g_Config.m_ClDummy].m_TargetY = (int)m_aMousePos[g_Config.m_ClDummy].y;

		// send once a second just to be sure
		Send = Send || time_get() > m_LastSendTime + time_freq();
	}
	else
	{
		m_aInputData[g_Config.m_ClDummy].m_TargetX = (int)m_aMousePos[g_Config.m_ClDummy].x;
		m_aInputData[g_Config.m_ClDummy].m_TargetY = (int)m_aMousePos[g_Config.m_ClDummy].y;

		if(g_Config.m_ClSubTickAiming && m_aMousePosOnAction[g_Config.m_ClDummy] != vec2(0.0f, 0.0f))
		{
			m_aInputData[g_Config.m_ClDummy].m_TargetX = (int)m_aMousePosOnAction[g_Config.m_ClDummy].x;
			m_aInputData[g_Config.m_ClDummy].m_TargetY = (int)m_aMousePosOnAction[g_Config.m_ClDummy].y;
			m_aMousePosOnAction[g_Config.m_ClDummy] = vec2(0.0f, 0.0f);
		}

		if(!m_aInputData[g_Config.m_ClDummy].m_TargetX && !m_aInputData[g_Config.m_ClDummy].m_TargetY)
		{
			m_aInputData[g_Config.m_ClDummy].m_TargetX = 1;
			m_aMousePos[g_Config.m_ClDummy].x = 1;
		}

		// set direction
		m_aInputData[g_Config.m_ClDummy].m_Direction = 0;
		if(m_aInputDirectionLeft[g_Config.m_ClDummy] && !m_aInputDirectionRight[g_Config.m_ClDummy])
			m_aInputData[g_Config.m_ClDummy].m_Direction = -1;
		if(!m_aInputDirectionLeft[g_Config.m_ClDummy] && m_aInputDirectionRight[g_Config.m_ClDummy])
			m_aInputData[g_Config.m_ClDummy].m_Direction = 1;

		// dummy copy moves
		if(g_Config.m_ClDummyCopyMoves)
		{
			CNetObj_PlayerInput *pDummyInput = &GameClient()->m_DummyInput;

			// Don't copy any input to dummy when spectating others
			if(!GameClient()->m_Snap.m_SpecInfo.m_Active || GameClient()->m_Snap.m_SpecInfo.m_SpectatorId < 0)
			{
				pDummyInput->m_Direction = m_aInputData[g_Config.m_ClDummy].m_Direction;
				pDummyInput->m_Hook = m_aInputData[g_Config.m_ClDummy].m_Hook;
				pDummyInput->m_Jump = m_aInputData[g_Config.m_ClDummy].m_Jump;
				pDummyInput->m_PlayerFlags = m_aInputData[g_Config.m_ClDummy].m_PlayerFlags;
				pDummyInput->m_TargetX = m_aInputData[g_Config.m_ClDummy].m_TargetX;
				pDummyInput->m_TargetY = m_aInputData[g_Config.m_ClDummy].m_TargetY;
				pDummyInput->m_WantedWeapon = m_aInputData[g_Config.m_ClDummy].m_WantedWeapon;

				if(!g_Config.m_ClDummyControl)
					pDummyInput->m_Fire += m_aInputData[g_Config.m_ClDummy].m_Fire - m_aLastData[g_Config.m_ClDummy].m_Fire;

				pDummyInput->m_NextWeapon += m_aInputData[g_Config.m_ClDummy].m_NextWeapon - m_aLastData[g_Config.m_ClDummy].m_NextWeapon;
				pDummyInput->m_PrevWeapon += m_aInputData[g_Config.m_ClDummy].m_PrevWeapon - m_aLastData[g_Config.m_ClDummy].m_PrevWeapon;
			}

			m_aInputData[!g_Config.m_ClDummy] = *pDummyInput;
		}

		if(g_Config.m_ClDummyControl)
		{
			CNetObj_PlayerInput *pDummyInput = &GameClient()->m_DummyInput;
			pDummyInput->m_Jump = g_Config.m_ClDummyJump;

			if(g_Config.m_ClDummyFire)
				pDummyInput->m_Fire = g_Config.m_ClDummyFire;
			else if((pDummyInput->m_Fire & 1) != 0)
				pDummyInput->m_Fire++;

			pDummyInput->m_Hook = g_Config.m_ClDummyHook;
			m_aInputData[!g_Config.m_ClDummy] = *pDummyInput;
		}

		// stress testing
		if(g_Config.m_DbgStress)
		{
			float t = Client()->LocalTime();
			mem_zero(&m_aInputData[g_Config.m_ClDummy], sizeof(m_aInputData[0]));

			m_aInputData[g_Config.m_ClDummy].m_Direction = ((int)t / 2) & 1;
			m_aInputData[g_Config.m_ClDummy].m_Jump = ((int)t);
			m_aInputData[g_Config.m_ClDummy].m_Fire = ((int)(t * 10));
			m_aInputData[g_Config.m_ClDummy].m_Hook = ((int)(t * 2)) & 1;
			m_aInputData[g_Config.m_ClDummy].m_WantedWeapon = ((int)t) % NUM_WEAPONS;
			m_aInputData[g_Config.m_ClDummy].m_TargetX = (int)(std::sin(t * 3) * 100.0f);
			m_aInputData[g_Config.m_ClDummy].m_TargetY = (int)(std::cos(t * 3) * 100.0f);
		}

		// check if we need to send input
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_Direction != m_aLastData[g_Config.m_ClDummy].m_Direction;
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_Jump != m_aLastData[g_Config.m_ClDummy].m_Jump;
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_Fire != m_aLastData[g_Config.m_ClDummy].m_Fire;
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_Hook != m_aLastData[g_Config.m_ClDummy].m_Hook;
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_WantedWeapon != m_aLastData[g_Config.m_ClDummy].m_WantedWeapon;
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_NextWeapon != m_aLastData[g_Config.m_ClDummy].m_NextWeapon;
		Send = Send || m_aInputData[g_Config.m_ClDummy].m_PrevWeapon != m_aLastData[g_Config.m_ClDummy].m_PrevWeapon;
		Send = Send || time_get() > m_LastSendTime + time_freq() / 25; // send at least 25 Hz
		Send = Send || (GameClient()->m_Snap.m_pLocalCharacter && GameClient()->m_Snap.m_pLocalCharacter->m_Weapon == WEAPON_NINJA && (m_aInputData[g_Config.m_ClDummy].m_Direction || m_aInputData[g_Config.m_ClDummy].m_Jump || m_aInputData[g_Config.m_ClDummy].m_Hook));
	}

	// Keep physical mouse/key state unchanged; only finalize the wire packet.
	if(MaybeLaserAutoUnfreeze() || LaserNeedsSend(g_Config.m_ClDummy))
		Send = true;

	// copy and return size
	m_aLastData[g_Config.m_ClDummy] = m_aInputData[g_Config.m_ClDummy];

	if(!Send)
		return 0;

	m_LastSendTime = time_get();
	mem_copy(pData, &m_aInputData[g_Config.m_ClDummy], sizeof(m_aInputData[0]));
	return sizeof(m_aInputData[0]);
}

CNetObj_PlayerInput CControls::NClientHeldInput(int Slot) const
{
	CNetObj_PlayerInput Input = m_aInputData[Slot];
	Input.m_PlayerFlags = PLAYERFLAG_PLAYING;
	Input.m_Direction = (m_aInputDirectionRight[Slot] != 0) - (m_aInputDirectionLeft[Slot] != 0);
	Input.m_TargetX = (int)m_aMousePos[Slot].x;
	Input.m_TargetY = (int)m_aMousePos[Slot].y;
	if(Input.m_TargetX == 0 && Input.m_TargetY == 0)
		Input.m_TargetX = 1;
	return Input;
}

bool CControls::BuildLaserShotWorld(CGameWorld &World, int Slot, int64_t Deadline, int Phase)
{
	CGameWorld &Base = GameClient()->m_GameWorld;
	// OnDirectInput fires BEFORE the intended tick, not at the already advanced
	// predicted end position. Reconstruct that launch state from known wire inputs.
	const int IntendedTick = Client()->PredGameTick(Slot);
	const int End = IntendedTick - 1 + Phase;
	if(End < Base.GameTick() || End - Base.GameTick() > 32 || Base.GameTick() <= 0)
		return false;
	World.CopyWorld(&Base, false);
	World.m_LocalClientId = Base.m_LocalClientId;
	World.m_WorldConfig.m_PredictEvents = false;
	World.m_WorldConfig.m_PredictWeapons = true;
	World.m_WorldConfig.m_PredictFreeze = 1;
	World.m_WorldConfig.m_PredictTiles = true;
	World.m_WorldConfig.m_PredictDDRace = true;
	World.m_PredictedEvents.clear();
	const int LocalId = GameClient()->m_aLocalIds[Slot];
	const int OtherId = GameClient()->m_aLocalIds[!Slot];
	for(int Tick = World.GameTick() + 1; Tick <= End; ++Tick)
	{
		if(time_get() >= Deadline)
			return false;
		CCharacter *pLocal = World.GetCharacterById(LocalId);
		CCharacter *pOther = GameClient()->PredictDummy() ? World.GetCharacterById(OtherId) : nullptr;
		if(!pLocal)
			return false;
		CNetObj_PlayerInput FutureInput = NClientHeldInput(Slot);
		if(FutureInput.m_Fire & 1) FutureInput.m_Fire = (FutureInput.m_Fire + 1) & INPUT_STATE_MASK;
		FutureInput.m_WantedWeapon = 0;
		FutureInput.m_NextWeapon = FutureInput.m_PrevWeapon = 0;
		const auto *pInput = Tick >= IntendedTick ? &FutureInput : (const CNetObj_PlayerInput *)Client()->GetInput(Tick, GameClient()->PredictionInputSwap());
		// Known past inputs may create projectiles. Unknown future ticks must not.
		if(Tick >= IntendedTick) World.m_WorldConfig.m_PredictWeapons = false;
		const auto *pOtherInput = pOther ? (const CNetObj_PlayerInput *)Client()->GetInput(Tick, GameClient()->PredictionInputSwap() ^ 1) : nullptr;
		const bool OtherFirst = pInput && pOtherInput && OtherId < LocalId;
		if(OtherFirst) pOther->OnDirectInput(pOtherInput);
		if(pInput) pLocal->OnDirectInput(pInput);
		if(pOtherInput && !OtherFirst) pOther->OnDirectInput(pOtherInput);
		GameClient()->ApplyPreInputs(Tick, true, World);
		World.m_GameTick = Tick;
		if(pInput) pLocal->OnPredictedInput(pInput);
		if(pOtherInput) pOther->OnPredictedInput(pOtherInput);
		GameClient()->ApplyPreInputs(Tick, false, World);
		World.Tick();
	}
	return World.GetCharacterById(LocalId) && time_get() < Deadline;
}

bool CControls::MaybeLaserAutoUnfreeze()
{
	const int Slot = g_Config.m_ClDummy;
	auto Fail = [&](ENLaserStatus Status) { m_aLaserStatus[Slot] = Status; return false; };
	if(!g_Config.m_ClLaserAutoUnfreeze) return Fail(ENLaserStatus::Disabled);
	if(m_aLaserInput[Slot].NeedsSend()) return Fail(ENLaserStatus::Pending);
	if(Client()->State() != IClient::STATE_ONLINE || GameClient()->m_Snap.m_SpecInfo.m_Active ||
		GameClient()->m_Chat.IsActive() || GameClient()->m_Menus.IsActive()) return Fail(ENLaserStatus::Paused);
	if(!g_Config.m_ClPredict || !g_Config.m_ClPredictFreeze) return Fail(ENLaserStatus::PredictionDisabled);
	if(g_Config.m_ClDummyCopyMoves || g_Config.m_ClDummyControl || g_Config.m_ClDummyHammer || g_Config.m_DbgStress)
		return Fail(ENLaserStatus::DummyMode);
	const CNetObj_PlayerInput &Held = m_aInputData[Slot];
	ObserveNInput(Slot, Held);
	if(Held.m_Fire & 1) return Fail(ENLaserStatus::ManualFire);
	if(NFeedbackAwaitingAck(m_aFeedback[Slot].m_Active, m_aFeedback[Slot].m_Committed, m_aFeedback[Slot].m_AttackTick))
		return Fail(ENLaserStatus::WaitingAck);
	CCharacter *pVisible = GameClient()->m_PredictedWorld.GetCharacterById(GameClient()->m_aLocalIds[Slot]);
	if(!pVisible || pVisible->GetActiveWeapon() != WEAPON_LASER) return Fail(ENLaserStatus::SelectLaser);
	if(pVisible->IsSuper() || pVisible->Core()->m_Invincible) return Fail(ENLaserStatus::SuperMode);
	// Weapon counters can remain nonzero forever; only a fresh change is a switch.
	if(Held.m_NextWeapon != m_aLastData[Slot].m_NextWeapon || Held.m_PrevWeapon != m_aLastData[Slot].m_PrevWeapon)
		return Fail(ENLaserStatus::WeaponSwitch);
	const int Tick = Client()->PredGameTick(Slot);
	const int Interval = g_Config.m_ClNClientOptimize ? g_Config.m_ClNClientSearchInterval : 1;
	const CNetObj_PlayerInput &Previous = m_aLaserSearchInput[Slot];
	const bool KeysChanged = Held.m_Direction != Previous.m_Direction || Held.m_Jump != Previous.m_Jump || Held.m_Hook != Previous.m_Hook;
	if(Tick <= 0 || Tick == m_aLaserLastSolveTick[Slot] ||
		(!KeysChanged && Tick > m_aLaserLastSolveTick[Slot] && Tick - m_aLaserLastSolveTick[Slot] < Interval))
		return false; // Keep the last real diagnostic between search ticks.
	m_aLaserLastSolveTick[Slot] = Tick;
	m_aLaserSearchInput[Slot] = Held;
	const bool Learn = g_Config.m_ClNClientLearn != 0;
	// Phase is only observed/logged: ordinary +-1 tick jitter is handled by the late-launch check in Verify.
	const int Phase = 0;
	const int Budget = Learn ? m_aLearning[Slot].Budget(g_Config.m_ClLaserAutoUnfreezeBudget) : g_Config.m_ClLaserAutoUnfreezeBudget;
	const int Samples = Learn ? m_aLearning[Slot].Angles(g_Config.m_ClLaserAutoUnfreezeSamples) : g_Config.m_ClLaserAutoUnfreezeSamples;
	const float Margin = Learn ? m_aLearning[Slot].HitMargin(g_Config.m_ClNClientStrict != 0) : 0.0f;
	const int64_t Start = time_get();
	const int64_t Deadline = Start + time_freq() * Budget / 1000;
	CGameWorld World;
	if(!BuildLaserShotWorld(World, Slot, Deadline, Phase))
	{
		if(Learn && time_get() >= Deadline) m_aLearning[Slot].SearchTimeout();
		return Fail(time_get() >= Deadline ? ENLaserStatus::BudgetExpired : ENLaserStatus::HistoryUnavailable);
	}
	const int RemainingMs = (int)((Deadline - time_get()) * 1000 / time_freq());
	if(RemainingMs < 1)
	{
		if(Learn) m_aLearning[Slot].SearchTimeout();
		return Fail(ENLaserStatus::BudgetExpired);
	}
	const int ClientId = GameClient()->m_aLocalIds[Slot];
	SLaserUnfreezeAim Aim;
	if(!FindLaserUnfreezeAim(World, ClientId, Held, Samples,
		RemainingMs, Aim, g_Config.m_ClNClientStrict, g_Config.m_ClNClientOptimize ? m_aLaserCachedAim[Slot] : ivec2(0, 0), &m_aLaserStatus[Slot], Margin))
	{
		if(Learn && m_aLaserStatus[Slot] == ENLaserStatus::BudgetExpired) m_aLearning[Slot].SearchTimeout();
		if(Learn && m_aLaserStatus[Slot] == ENLaserStatus::NoAngle) m_aLearning[Slot].NoAngle();
		return false;
	}
	m_aLaserCachedAim[Slot] = Aim.m_Target;
	if(!m_aLaserInput[Slot].Queue(Aim.m_Target.x, Aim.m_Target.y))
		return Fail(ENLaserStatus::Pending);
	if(m_aFeedback[Slot].m_Active) FinishNFeedback(Slot, "confirmed_superseded", Client()->GameTick(Slot));
	SShotFeedback &Feedback = m_aFeedback[Slot];
	Feedback.m_Active = true;
	Feedback.m_Id = ClientId;
	Feedback.m_BaseTick = Tick - 1;
	Feedback.m_AppliedPhase = Phase;
	Feedback.m_Held = Held;
	Feedback.m_PreviousAttack = GameClient()->m_Snap.m_aCharacters[ClientId].m_Cur.m_AttackTick;
	Feedback.m_Aim = std::move(Aim);
	// The replayed character's actual reload timer is authoritative. Do not
	// impose a guessed tune-zone cooldown that survives a death/reset.
	m_aLaserStatus[Slot] = ENLaserStatus::ShotQueued;
	return true;
}

void CControls::OnRender()
{
	FlushNFeedback();
	if(Client()->State() != IClient::STATE_ONLINE && Client()->State() != IClient::STATE_DEMOPLAYBACK)
		return;

	if(g_Config.m_ClAutoswitchWeaponsOutOfAmmo && !GameClient()->m_GameInfo.m_UnlimitedAmmo && GameClient()->m_Snap.m_pLocalCharacter)
	{
		// Keep track of ammo count, we know weapon ammo only when we switch to that weapon, this is tracked on server and protocol does not track that
		m_aAmmoCount[std::max(0, GameClient()->m_Snap.m_pLocalCharacter->m_Weapon % NUM_WEAPONS)] = GameClient()->m_Snap.m_pLocalCharacter->m_AmmoCount;
		// Autoswitch weapon if we're out of ammo
		if(m_aInputData[g_Config.m_ClDummy].m_Fire % 2 != 0 &&
			GameClient()->m_Snap.m_pLocalCharacter->m_AmmoCount == 0 &&
			GameClient()->m_Snap.m_pLocalCharacter->m_Weapon != WEAPON_HAMMER &&
			GameClient()->m_Snap.m_pLocalCharacter->m_Weapon != WEAPON_NINJA)
		{
			int Weapon;
			for(Weapon = WEAPON_LASER; Weapon > WEAPON_GUN; Weapon--)
			{
				if(Weapon == GameClient()->m_Snap.m_pLocalCharacter->m_Weapon)
					continue;
				if(m_aAmmoCount[Weapon] > 0)
					break;
			}
			if(Weapon != GameClient()->m_Snap.m_pLocalCharacter->m_Weapon)
				m_aInputData[g_Config.m_ClDummy].m_WantedWeapon = Weapon + 1;
		}
	}

	// update target pos
	if(GameClient()->m_Snap.m_pGameInfoObj && !GameClient()->m_Snap.m_SpecInfo.m_Active)
	{
		// make sure to compensate for smooth dyncam to ensure the cursor stays still in world space if zoomed
		vec2 DyncamOffsetDelta = GameClient()->m_Camera.m_DyncamTargetCameraOffset - GameClient()->m_Camera.m_aDyncamCurrentCameraOffset[g_Config.m_ClDummy];
		float Zoom = GameClient()->m_Camera.m_Zoom;
		m_aTargetPos[g_Config.m_ClDummy] = GameClient()->m_LocalCharacterPos + m_aMousePos[g_Config.m_ClDummy] - DyncamOffsetDelta + DyncamOffsetDelta / Zoom;
	}
	else if(GameClient()->m_Snap.m_SpecInfo.m_Active && GameClient()->m_Snap.m_SpecInfo.m_UsePosition)
	{
		m_aTargetPos[g_Config.m_ClDummy] = GameClient()->m_Snap.m_SpecInfo.m_Position + m_aMousePos[g_Config.m_ClDummy];
	}
	else
	{
		m_aTargetPos[g_Config.m_ClDummy] = m_aMousePos[g_Config.m_ClDummy];
	}
}

bool CControls::OnCursorMove(float x, float y, IInput::ECursorType CursorType)
{
	if(GameClient()->IsWorldPaused())
		return false;

	if(CursorType == IInput::CURSOR_JOYSTICK && g_Config.m_InpControllerAbsolute && GameClient()->m_Snap.m_pGameInfoObj && !GameClient()->m_Snap.m_SpecInfo.m_Active)
	{
		vec2 AbsoluteDirection;
		if(Input()->GetActiveJoystick()->Absolute(&AbsoluteDirection.x, &AbsoluteDirection.y))
		{
			m_aMousePos[g_Config.m_ClDummy] = AbsoluteDirection * GetMaxMouseDistance();
			GameClient()->m_Controls.m_aMouseInputType[g_Config.m_ClDummy] = CControls::EMouseInputType::ABSOLUTE;
		}
		return true;
	}

	float Factor = 1.0f;
	if(g_Config.m_ClDyncam && g_Config.m_ClDyncamMousesens)
	{
		Factor = g_Config.m_ClDyncamMousesens / 100.0f;
	}
	else
	{
		switch(CursorType)
		{
		case IInput::CURSOR_MOUSE:
			Factor = g_Config.m_InpMousesens / 100.0f;
			break;
		case IInput::CURSOR_JOYSTICK:
			Factor = g_Config.m_InpControllerSens / 100.0f;
			break;
		default:
			dbg_assert_failed("CControls::OnCursorMove CursorType %d", (int)CursorType);
		}
	}

	if(GameClient()->m_Snap.m_SpecInfo.m_Active && GameClient()->m_Snap.m_SpecInfo.m_SpectatorId < 0)
		Factor *= GameClient()->m_Camera.m_Zoom;

	m_aMousePos[g_Config.m_ClDummy] += vec2(x, y) * Factor;
	GameClient()->m_Controls.m_aMouseInputType[g_Config.m_ClDummy] = CControls::EMouseInputType::RELATIVE;
	ClampMousePos();
	return true;
}

void CControls::ClampMousePos()
{
	if(GameClient()->m_Snap.m_SpecInfo.m_Active && GameClient()->m_Snap.m_SpecInfo.m_SpectatorId < 0)
	{
		m_aMousePos[g_Config.m_ClDummy].x = std::clamp(m_aMousePos[g_Config.m_ClDummy].x, -201.0f * 32, (Collision()->GetWidth() + 201.0f) * 32.0f);
		m_aMousePos[g_Config.m_ClDummy].y = std::clamp(m_aMousePos[g_Config.m_ClDummy].y, -201.0f * 32, (Collision()->GetHeight() + 201.0f) * 32.0f);
	}
	else
	{
		const float MouseMin = GetMinMouseDistance();
		const float MouseMax = GetMaxMouseDistance();

		float MouseDistance = length(m_aMousePos[g_Config.m_ClDummy]);
		if(MouseDistance < 0.001f)
		{
			m_aMousePos[g_Config.m_ClDummy].x = 0.001f;
			m_aMousePos[g_Config.m_ClDummy].y = 0;
			MouseDistance = 0.001f;
		}
		if(MouseDistance < MouseMin)
			m_aMousePos[g_Config.m_ClDummy] = normalize_pre_length(m_aMousePos[g_Config.m_ClDummy], MouseDistance) * MouseMin;
		MouseDistance = length(m_aMousePos[g_Config.m_ClDummy]);
		if(MouseDistance > MouseMax)
			m_aMousePos[g_Config.m_ClDummy] = normalize_pre_length(m_aMousePos[g_Config.m_ClDummy], MouseDistance) * MouseMax;
	}
}

float CControls::GetMinMouseDistance() const
{
	return g_Config.m_ClDyncam ? g_Config.m_ClDyncamMinDistance : g_Config.m_ClMouseMinDistance;
}

float CControls::GetMaxMouseDistance() const
{
	float CameraMaxDistance = 200.0f;
	float FollowFactor = (g_Config.m_ClDyncam ? g_Config.m_ClDyncamFollowFactor : g_Config.m_ClMouseFollowfactor) / 100.0f;
	float DeadZone = g_Config.m_ClDyncam ? g_Config.m_ClDyncamDeadzone : g_Config.m_ClMouseDeadzone;
	float MaxDistance = g_Config.m_ClDyncam ? g_Config.m_ClDyncamMaxDistance : g_Config.m_ClMouseMaxDistance;
	return std::min(FollowFactor != 0.0f ? CameraMaxDistance / FollowFactor + DeadZone : MaxDistance, MaxDistance);
}


void CControls::ResetNLearning()
{
 for(int Slot=0; Slot<NUM_DUMMIES; ++Slot)
 {
  ++m_aFeedbackEpoch[Slot];
  m_aLearning[Slot].Reset(); m_aFeedback[Slot]=SShotFeedback();
  m_aLaserCachedAim[Slot]=ivec2(0,0);
 }
}
void CControls::OnMapLoad() { ResetNLearning(); }
void CControls::ObserveNInput(int Slot, const CNetObj_PlayerInput &Held)
{
 auto &F=m_aFeedback[Slot]; if(!F.m_Active) return;
 if((Held.m_Fire & 1) || Held.m_Fire!=F.m_Held.m_Fire) {F.m_Manual=true;F.m_InputChanged=true;}
 if(Held.m_Direction!=F.m_Held.m_Direction || Held.m_Jump!=F.m_Held.m_Jump || Held.m_Hook!=F.m_Held.m_Hook ||
  Held.m_NextWeapon!=F.m_Held.m_NextWeapon || Held.m_PrevWeapon!=F.m_Held.m_PrevWeapon ||
  Held.m_WantedWeapon!=F.m_Held.m_WantedWeapon) F.m_InputChanged=true;
 // Mouse changes matter if a future hook can be launched/teleported.
 if(Held.m_Hook && (Held.m_TargetX!=F.m_Held.m_TargetX || Held.m_TargetY!=F.m_Held.m_TargetY))
 {
  const vec2 A((float)Held.m_TargetX,(float)Held.m_TargetY), B((float)F.m_Held.m_TargetX,(float)F.m_Held.m_TargetY);
  if(length(A)>.01f && length(B)>.01f && dot(normalize(A),normalize(B))<.999f) F.m_InputChanged=true;
 }
}
void CControls::FinalizeLaserInput(CNetObj_PlayerInput &Input, int Connection)
{
 const bool Queued=m_aLaserInput[Connection].IsQueued();
 const bool Committed=m_aLaserInput[Connection].Finalize(Input);
 if(Committed)
 {
  m_aFeedback[Connection].m_Committed=true;
  NFeedbackLog(Connection,"sent",Client()->GameTick(Connection));
 }
 else if(Queued && m_aFeedback[Connection].m_Active)
  FinishNFeedback(Connection,"cancelled_manual",Client()->GameTick(Connection));
}
void CControls::NFeedbackLog(int Slot, const char *pEvent, int SnapTick, vec2 Observed)
{
 if(!g_Config.m_ClNClientFeedbackLog) return;
 const auto &F=m_aFeedback[Slot]; char aLine[512];
 bool HasPrediction=false;vec2 Predicted(0,0);float Error=-1;
 if(F.m_AttackTick>=0 && (str_comp(pEvent,"position_sample")==0 || str_comp(pEvent,"attack_observed")==0 || str_comp(pEvent,"early_thaw_observed")==0 || str_comp(pEvent,"still_frozen")==0))
 {
  const int ModelTick=F.m_Aim.m_LaunchTick+(SnapTick-F.m_AttackTick);
  for(const auto &Point:F.m_Aim.m_Forecast) if(Point.m_Tick==ModelTick)
  {HasPrediction=true;Predicted=Point.m_Pos;Error=distance(Predicted,Observed);break;}
 }
 str_format(aLine,sizeof(aLine),"%lld,%d,%d,%s,%d,%d,%d,%d,%d,%d,%d,%d,%.3f,%.3f,%d,%.3f,%.3f,%.3f,%d,%d,%d,%d\n",
  (long long)m_FeedbackSession,m_aFeedbackEpoch[Slot],Slot,pEvent,SnapTick,F.m_BaseTick,F.m_Aim.m_LaunchTick,F.m_AttackTick,F.m_Aim.m_ReturnTick,
  F.m_AppliedPhase,F.m_Aim.m_Target.x,F.m_Aim.m_Target.y,Observed.x,Observed.y,
  (int)HasPrediction,Predicted.x,Predicted.y,Error,(int)F.m_InputChanged,(int)F.m_Manual,(int)F.m_SawFreeze,(int)F.m_ExternalInfluence);
 if(m_FeedbackBuffer.size()+str_length(aLine) <= 16384) m_FeedbackBuffer.append(aLine);
}
void CControls::FlushNFeedback(bool Force)
{
 const int64_t Now=time_get();
 if(!Force && Now-m_LastFeedbackFlush<time_freq()) return;
 m_LastFeedbackFlush=Now;
 if(m_FeedbackBuffer.empty()) return;
 IOHANDLE File=Storage()->OpenFile("nclient-feedback-05.csv",IOFLAG_APPEND,IStorage::TYPE_SAVE);
 if(!File) {m_FeedbackBuffer.clear();return;}
 // Bound the log without deleting existing user data.
 const int64_t Size=io_length(File);
 if(Size+(int64_t)m_FeedbackBuffer.size()>1024*1024) {io_close(File);m_FeedbackBuffer.clear();return;}
 if(Size==0)
 {
  const char *pHeader="session,epoch,slot,event,snapshot_tick,base_launch_tick,model_launch_tick,attack_tick,return_tick,phase,aim_x,aim_y,observed_x,observed_y,has_prediction,predicted_x,predicted_y,position_error,input_changed,manual,freeze_seen,external_influence\n";
  io_write(File,pHeader,str_length(pHeader));
 }
 io_write(File,m_FeedbackBuffer.data(),m_FeedbackBuffer.size());
 io_close(File);m_FeedbackBuffer.clear();
}
void CControls::OnShutdown() { FlushNFeedback(true); }
void CControls::FinishNFeedback(int Slot, const char *pEvent, int SnapTick)
{
 if(!m_aFeedback[Slot].m_Active) return;
 if(g_Config.m_ClNClientLearn) m_aLearning[Slot].Unknown();
 NFeedbackLog(Slot,pEvent,SnapTick);m_aFeedback[Slot]=SShotFeedback();
}
void CControls::OnNewSnapshot()
{
 const int Slot=g_Config.m_ClDummy;
 auto &F=m_aFeedback[Slot]; if(!F.m_Active || !F.m_Committed) return;
 const int Tick=Client()->GameTick(Slot);
 if(Tick<=F.m_LastSnap) return;
 F.m_LastSnap=Tick;
 if(F.m_Id!=GameClient()->m_Snap.m_LocalClientId || !GameClient()->m_Snap.m_aCharacters[F.m_Id].m_Active)
 {FinishNFeedback(Slot,"lost_character",Tick);return;}
 const auto &Char=GameClient()->m_Snap.m_aCharacters[F.m_Id];
 if(!Char.m_HasExtendedData) {FinishNFeedback(Slot,"no_extended_snapshot",Tick);return;}
 const auto &Ext=Char.m_ExtendedData;
 if((Ext.m_Flags & (CHARACTERFLAG_SUPER | CHARACTERFLAG_INVINCIBLE)) || Ext.m_FreezeEnd==-1 || (Ext.m_Flags & CHARACTERFLAG_MOVEMENTS_DISABLED))
 {FinishNFeedback(Slot,"unsupported_freeze_or_super",Tick);return;}
 ObserveNInput(Slot,NClientHeldInput(Slot));
 const vec2 Pos((float)Char.m_Cur.m_X,(float)Char.m_Cur.m_Y);
 const int Attack=Char.m_Cur.m_AttackTick;
 for(int Id=0;Id<MAX_CLIENTS;++Id)
  if(Id!=F.m_Id && GameClient()->m_Snap.m_aCharacters[Id].m_Active) F.m_ExternalInfluence=true;
 // Conservative character-sized neighborhood, not just the center tile.
 for(int X=-1;X<=1;++X) for(int Y=-1;Y<=1;++Y)
 {
  const int Index=GameClient()->Collision()->GetPureMapIndex(Pos+vec2(X*14.0f,Y*14.0f));
  if(GameClient()->Collision()->GetTileIndex(Index)==TILE_UNFREEZE || GameClient()->Collision()->GetFrontTileIndex(Index)==TILE_UNFREEZE)
   F.m_ExternalInfluence=true;
 }
 if(F.m_AttackTick<0 && Attack!=F.m_PreviousAttack && Attack>=F.m_BaseTick-2 && Attack<=F.m_BaseTick+3)
 {
  F.m_AttackTick=Attack;
  // A physical manual press makes attribution ambiguous. Never train from it.
  if(Char.m_Cur.m_Weapon!=WEAPON_LASER) F.m_InputChanged=true;
  if(!F.m_Manual && Char.m_Cur.m_Weapon==WEAPON_LASER && g_Config.m_ClNClientLearn)
   F.m_PhaseObserved=m_aLearning[Slot].ObservePhase(Attack-F.m_BaseTick);
  NFeedbackLog(Slot,"attack_observed",Tick,Pos);
 }
 if(F.m_AttackTick<0)
 {
  if(Tick>F.m_BaseTick+25) FinishNFeedback(Slot,"no_attack_ack",Tick);
  return;
 }
 const int ExpectedReturn=F.m_AttackTick+(F.m_Aim.m_ReturnTick-F.m_Aim.m_LaunchTick);
 const bool Frozen=Ext.m_FreezeEnd>Tick;
 if(Frozen) F.m_SawFreeze=true;
 if(F.m_SawFreeze && !Frozen && F.m_PreviousFreezeEnd>Tick && Tick<=ExpectedReturn+6)
  F.m_ThawObserved=true; // Observed early thaw, NOT proof the own laser caused it.
 F.m_PreviousFreezeEnd=Ext.m_FreezeEnd;
 // Learn model error only at a matching server tick with unchanged held input.
 if(!F.m_InputChanged && !F.m_Manual && g_Config.m_ClNClientLearn)
 {
  const int ModelTick=F.m_Aim.m_LaunchTick+(Tick-F.m_AttackTick);
  for(const auto &Point:F.m_Aim.m_Forecast)
   if(Point.m_Tick==ModelTick)
   {
    m_aLearning[Slot].PositionError(distance(Pos,Point.m_Pos));
    NFeedbackLog(Slot,"position_sample",Tick,Pos);break;
   }
 }
 if(Tick<ExpectedReturn+6) return;
 const ENFeedbackOutcome Outcome=NFeedbackOutcome(F.m_InputChanged,F.m_Manual,F.m_ExternalInfluence,F.m_SawFreeze,F.m_ThawObserved,Frozen);
 if(Outcome==ENFeedbackOutcome::Unknown)
 {FinishNFeedback(Slot,"ambiguous_result",Tick);return;}
 if(g_Config.m_ClNClientLearn)
 {
  if(Outcome==ENFeedbackOutcome::EarlyThaw) m_aLearning[Slot].ThawObserved();
  else {m_aLearning[Slot].FrozenObserved();m_aLaserCachedAim[Slot]=ivec2(0,0);}
 }
 NFeedbackLog(Slot,Outcome==ENFeedbackOutcome::EarlyThaw ? "early_thaw_observed" : "still_frozen",Tick,Pos);
 F=SShotFeedback();
}
