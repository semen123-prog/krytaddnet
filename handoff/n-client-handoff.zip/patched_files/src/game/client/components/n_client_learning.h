// n-client 0.5: bounded session-local calibration, not a neural network.
#ifndef GAME_CLIENT_COMPONENTS_N_CLIENT_LEARNING_H
#define GAME_CLIENT_COMPONENTS_N_CLIENT_LEARNING_H
#include <algorithm>
#include <array>
#include <cmath>
enum class ENFeedbackOutcome { Unknown, EarlyThaw, StillFrozen };
inline ENFeedbackOutcome NFeedbackOutcome(bool Changed, bool Manual, bool External, bool SawFreeze, bool Thaw, bool Frozen)
{
 if(Changed || Manual || External || !SawFreeze) return ENFeedbackOutcome::Unknown;
 if(Thaw && !Frozen) return ENFeedbackOutcome::EarlyThaw;
 if(Frozen) return ENFeedbackOutcome::StillFrozen;
 return ENFeedbackOutcome::Unknown;
}
inline bool NFeedbackAwaitingAck(bool Active, bool Committed, int AttackTick)
{ return Active && Committed && AttackTick < 0; }
class CNClientLearning
{
 std::array<int,16> m_Phases{};
 int m_Count=0, m_Next=0;
 int m_Risk=0;
public:
 int m_ConfirmedShots=0, m_ObservedThaws=0, m_StillFrozen=0, m_Unknown=0;
 float m_PositionError=-1.0f;
 void Reset() { *this=CNClientLearning(); }
 bool ObservePhase(int Delta)
 {
  // Do not turn unbounded transport delay into an invented physical offset.
  if(Delta < -2 || Delta > 3) return false;
  m_Phases[m_Next]=Delta; m_Next=(m_Next+1)%16; m_Count=std::min(16,m_Count+1);
  ++m_ConfirmedShots; return true;
 }
 int Samples() const { return m_Count; }
 int Phase() const
 {
  if(m_Count<4) return 0;
  auto Values=m_Phases; std::sort(Values.begin(),Values.begin()+m_Count);
  const int Median=Values[m_Count/2];
  int Near=0; for(int i=0;i<m_Count;++i) if(std::abs(Values[i]-Median)<=1) ++Near;
  // At least 75% of samples must agree to within a tick.
  return Near*4>=m_Count*3 ? Median : 0;
 }
 // Timing calibration is independent of the user's CPU and angle caps.
 void SearchTimeout() {}
 void NoAngle() {}
 int Budget(int Base) const { return std::clamp(Base,2,12); }
 int Angles(int Base) const { return std::clamp(Base,180,1440); }
 void ThawObserved() {++m_ObservedThaws;m_Risk=std::max(0,m_Risk-1);}
 void FrozenObserved() {++m_StillFrozen;m_Risk=std::min(6,m_Risk+2);}
 void Unknown() {++m_Unknown;}
 float HitMargin(bool Strict) const
 {
  const float Spatial=m_PositionError<0 ? 0.0f : std::min(4.0f,m_PositionError*.2f);
  return std::max(6.0f,(Strict?12.0f:20.0f)-m_Risk-Spatial);
 }
 void PositionError(float Error)
 {
  if(!std::isfinite(Error) || Error<0 || Error>96) return;
  m_PositionError=m_PositionError<0 ? Error : .8f*m_PositionError+.2f*Error;
 }
};
#endif
