// n-client settings; Russian labels for the requested custom features.
#include "menus.h"
#include <engine/shared/config.h>
#include <engine/textrender.h>
#include <game/client/ui.h>
#include <game/client/gameclient.h>

void CMenus::RenderSettingsNClient(CUIRect MainView)
{
	CUIRect Row;
	MainView.HSplitTop(28.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, "n-client 0.6", 24.0f, TEXTALIGN_ML);
	MainView.HSplitTop(6.0f, nullptr, &MainView);
	auto Check = [&](int &Value, const char *pLabel) {
		MainView.HSplitTop(18.0f, &Row, &MainView);
		if(DoButton_CheckBox(&Value, pLabel, Value, &Row)) Value ^= 1;
		MainView.HSplitTop(2.0f, nullptr, &MainView);
	};
	Check(g_Config.m_ClLaserAutoUnfreeze, "Laser Auto Unfreeze");
	Check(g_Config.m_ClNClientLearn, "Адаптация по серверным результатам (не нейросеть)");
	Check(g_Config.m_ClNClientFeedbackLog, "Локальный журнал выстрелов nclient-feedback-05.csv");
	Check(g_Config.m_ClNClientStatus, "Показывать причину отказа / статус поиска");
	Check(g_Config.m_ClNClientPrediction, "Показывать линию движения по зажатым кнопкам");
	Check(g_Config.m_ClNClientStrict, "Строгая проверка выстрела (меньше случайных выстрелов)");
	Check(g_Config.m_ClNClientOptimize, "Оптимизация: кэш и ограничение частоты расчётов");
	auto Slider = [&](int &Value, const char *pLabel, int Min, int Max, const char *pSuffix) {
		MainView.HSplitTop(20.0f, &Row, &MainView);
		Ui()->DoScrollbarOption(&Value, &Value, &Row, pLabel, Min, Max, &CUi::ms_LinearScrollbarScale, 0u, pSuffix);
		MainView.HSplitTop(3.0f, nullptr, &MainView);
	};
	Slider(g_Config.m_ClNClientPredictionTicks, "Длина предикта", 8, 64, " тиков");
	Slider(g_Config.m_ClNClientPredictionAlpha, "Прозрачность линии", 10, 100, "%");
	Slider(g_Config.m_ClLaserAutoUnfreezeSamples, "Качество поиска угла", 180, 1440, "");
	Slider(g_Config.m_ClLaserAutoUnfreezeBudget, "Бюджет расчёта выстрела", 2, 12, " мс");
	Slider(g_Config.m_ClNClientSearchInterval, "Интервал поиска при оптимизации", 1, 6, " тиков");
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	MainView.HSplitTop(24.0f, &Row, &MainView);
	static CButtonContainer s_Preset;
	if(DoButton_Menu(&s_Preset, "Применить настройки поиска: 500 / 3 мс / 3 тика", 0, &Row))
	{
		g_Config.m_ClNClientOptimize = 1;
		g_Config.m_ClLaserAutoUnfreezeSamples = 500;
		g_Config.m_ClLaserAutoUnfreezeBudget = 3;
		g_Config.m_ClNClientSearchInterval = 3;
	}
	MainView.HSplitTop(20.0f, &Row, &MainView);
	static CButtonContainer s_ResetLearn;
	if(DoButton_Menu(&s_ResetLearn, "Сбросить адаптацию текущей карты", 0, &Row)) GameClient()->m_Controls.ResetNLearning();
	MainView.HSplitTop(20.0f, &Row, &MainView);
	Ui()->DoLabel(&Row, NLaserStatusText(GameClient()->m_Controls.NLaserStatus(g_Config.m_ClDummy)), 12.0f, TEXTALIGN_ML);
	MainView.HSplitTop(5.0f, nullptr, &MainView);
	const char *apNotes[] = {
		"Голубая линия — движение. Красная — ожидаемая заморозка.",
		"Прогноз предполагает, что текущие кнопки остаются зажатыми.",
		"Нужен выбранный лазер, cl_predict 1 и cl_predict_freeze 1.",
		"Обучение локальное, сбрасывается при смене карты/подключения.",
		"Выстрел до freeze. Новый хук запускается первым. Пинг влияет.",
	};
	for(const char *pNote : apNotes)
	{
		MainView.HSplitTop(16.0f, &Row, &MainView);
		Ui()->DoLabel(&Row, pNote, 12.0f, TEXTALIGN_ML);
	}
}
